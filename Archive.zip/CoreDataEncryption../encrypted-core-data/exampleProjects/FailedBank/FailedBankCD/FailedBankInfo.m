#import "FailedBankInfo.h"
#import "FailedBankDetails.h"


@implementation FailedBankInfo

@dynamic city;
@dynamic name;
@dynamic state;
@dynamic details;

@end
