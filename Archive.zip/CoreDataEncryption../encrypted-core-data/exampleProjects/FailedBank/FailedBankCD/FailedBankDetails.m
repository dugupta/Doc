#import "FailedBankDetails.h"
#import "FailedBankInfo.h"
#import "Tag.h"


@implementation FailedBankDetails

@dynamic closeDate;
@dynamic updateDate;
@dynamic zip;
@dynamic info;
@dynamic tags;

@end
