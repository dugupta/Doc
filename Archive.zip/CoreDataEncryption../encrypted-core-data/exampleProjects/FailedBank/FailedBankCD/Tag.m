#import "Tag.h"
#import "FailedBankDetails.h"


@implementation Tag

@dynamic name;
@dynamic detail;

@end
