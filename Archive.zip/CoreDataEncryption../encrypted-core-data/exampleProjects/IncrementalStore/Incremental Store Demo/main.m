//
//  main.m
//  Incremental Store Demo
//
//

#import <UIKit/UIKit.h>

#import "ISDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ISDAppDelegate class]));
    }
}
