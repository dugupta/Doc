//
//  ISDChildB.m
//  Incremental Store
//
//  Created by Richard Hodgkins on 31/08/2014.
//  Copyright (c) 2014 Caleb Davenport. All rights reserved.
//

#import "ISDChildB.h"


@implementation ISDChildB

@dynamic attributeB;
@dynamic multipleOneToMany;

@end
