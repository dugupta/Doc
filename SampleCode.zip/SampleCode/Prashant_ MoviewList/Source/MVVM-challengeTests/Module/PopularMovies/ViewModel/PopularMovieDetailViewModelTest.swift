//
//  PopularMovieDetailViewModelTest.swift
//  MVVM-coding-challengeTests
//
//  Created by Durgesh Lal on 12/8/20.
//

import XCTest
@testable import MVVMC

class PopularMovieDetailViewModelTest: XCTestCase {

    private var viewModel: PopularMovieDetailViewModel!
    
    override func setUpWithError() throws {
        viewModel = PopularMovieDetailViewModel(MockPopularMovieDetailDataManager("someId"))
    }
    
    func testTitle() {
        XCTAssertEqual(viewModel.title, "Jiu Jitsu")
    }
    func testGeners() {
        XCTAssertEqual(viewModel.genre, "Genre: Action, Fantasy, Science Fiction")
    }
    
    func testReleaseYear() {
        XCTAssertEqual(viewModel.releaseYear, "Release date: 2020-11-20")
    }
    
    func testPopularityScale() {
        XCTAssertEqual(viewModel.popularityScore, "Popularity score: 2267.77")
    }
    
    func testOverview() {
        XCTAssertEqual(viewModel.overView, "Overview:\nEvery six years, an ancient order of jiu-jitsu fighters joins forces to battle a vicious race of alien invaders. But when a celebrated war hero goes down in defeat, the fate of the planet and mankind hangs in the balance.")
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }
}
