//
//  MockPopularMoviesDataManager.swift
//  MVVM-coding-challengeTests
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
import Combine
@testable import MVVMC

struct MockPopularMoviesDataManager: PopularMoviesDataManaging {
    
    private var networkManager: NetworkManaging
    
    init(_ networkManager: NetworkManaging = MockNetworkManager()) {
        self.networkManager = networkManager
    }
    
    func moviesList() -> AnyPublisher<PopularMoviesResponse, Failure> {
        networkManager.request(url: "MoviesList", params: nil, callBack: callBack)
    }
    
    func fetchGenres() -> AnyPublisher<GenreResponse, Failure> {
        networkManager.request(url: "Genres", params: nil, callBack: callBack)
    }
}
