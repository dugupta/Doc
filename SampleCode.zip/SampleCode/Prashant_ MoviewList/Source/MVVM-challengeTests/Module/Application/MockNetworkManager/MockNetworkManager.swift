//
//  MockNetworkManager.swift
//  MVVM-coding-challengeTests
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
import Combine
@testable import MVVMC

extension Bundle {
    static var current: Bundle {
        class __ { }
        return Bundle(for: __.self)
    }
}

struct MockNetworkManager: NetworkManaging {
    
    private func jsonData(_ file: String) -> AnyPublisher<Data?, Never>? {
        let bundle = Bundle.current
        guard let path = bundle.path(forResource: file, ofType: "json") else { return nil }
        let data = try? Data(contentsOf: URL(fileURLWithPath: path), options: .uncachedRead)
        return AnyPublisher<Data?, Never>(data)
    }
    
    return defaultSession.dataTaskPublisher(for: urlRequest)
      .tryMap { response -> Data in
        guard let httpURLResponse = response.response as? HTTPURLResponse,
          httpURLResponse.statusCode == 200 else {
            throw Failure.statusCode
        }
        
        print("response \(httpURLResponse) data \(response.data), description : \(response)")
        return response.data
      }
      .decode(type: T.self, decoder: JSONDecoder())
      .mapError { Failure.map($0) }
      .eraseToAnyPublisher()
    
    func request<T: Decodable>(url: String, params: [String: String]? = nil) -> AnyPublisher<T, Failure> {
        return jsonData(url)
//        if let data = jsonData(url) {
//            let decoder = JSONDecoder()
//            let jsonData = try? decoder.decode(T.self, from: data)
//            callBack(.success, jsonData)
//        } else {
//            callBack(RequestStatus.failure(.badResponse), nil)
//        }
    }
    
//    func request<T>(url: String, params: [String : String]? = nil, callBack: @escaping (RequestStatus, T?) -> Void) where T : Decodable {
//        if let data = jsonData(url) {
//            let decoder = JSONDecoder()
//            let jsonData = try? decoder.decode(T.self, from: data)
//            callBack(.success, jsonData)
//        } else {
//            callBack(RequestStatus.failure(.badResponse), nil)
//        }
//    }
}
