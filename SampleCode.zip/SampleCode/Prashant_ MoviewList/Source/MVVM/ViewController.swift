//
//  ViewController.swift
//  wallmart-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

