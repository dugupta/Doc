//
//  AssetsRepository.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import UIKit

protocol ImageRepresentable:  RawRepresentable {
    var image: UIImage? { get }
}

extension ImageRepresentable {
    var image: UIImage? {
        guard let name = self.rawValue as? String else { return nil }
        return UIImage(named: name)
    }
}

enum Icon: String, ImageRepresentable {
    case popularMoviesPlaceholder = "moviePlaceholder"
}
