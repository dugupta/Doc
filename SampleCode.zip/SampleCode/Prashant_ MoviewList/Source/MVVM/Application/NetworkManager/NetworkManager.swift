//
//  NetworkManager.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
import Combine

enum BaseUrl: String {
    case fetchImage = "https://image.tmdb.org/t/p/w500/"
    case polularMovies = "https://api.themoviedb.org/3/"
    var url: String {
        return rawValue
    }
}

enum Failure: Error {
    case statusCode
    case decoding
    case badResponse
    case invalidURL
    case other(Error)
    
    static func map(_ error: Error) -> Failure {
        return (error as? Failure) ?? .other(error)
    }
}

// MARK: - Networking method
///
/// - Note: Struct must confirm to Codable while passing in Callback
/// - Parameters:
///   - url: Target url to be hit
///   - params: Parameters if any
///   - callBack: Callback with a RequestStatus and Codable Object

protocol NetworkManaging {
    func request<T: Decodable>(url: String, params: [String: String]?, callBack: @escaping (Result<T, Failure>) -> Void)
}

class NetworkManager: NetworkManaging {
    
    private func process<T: Decodable>(_ data: Data? = nil, urlResponse: URLResponse? = nil, error: Error? = nil, callBack: @escaping (Result<T, Failure>) -> Void) {
        guard error == nil else {
            DispatchQueue.main.async {
                callBack(.failure(.statusCode))
            }
            return
        }
        if let _data = data {
            let decoder = JSONDecoder()
            if let model = try? decoder.decode(T.self, from: _data) {
                DispatchQueue.main.async {
                    callBack(.success(model))
                }
            }
            return
        }
        DispatchQueue.main.async {
            callBack(.failure(.badResponse))
        }
    }
    
    func request<T: Decodable>(url: String, params: [String: String]?, callBack: @escaping (Result<T, Failure>) -> Void) {
        
        let defaultSession = URLSession(configuration: .default)
        
        var urlComponents = URLComponents(string: url)
        urlComponents?.queryItems = params?.map {
             URLQueryItem(name: $0, value: $1)
        }
        
        let url = urlComponents?.url // else { return Failure.invalidURL }
        let urlRequest = URLRequest(url: url!)
        
        var dataTask: URLSessionDataTask?
        
        dataTask = defaultSession.dataTask(with: urlRequest, completionHandler: { (data, response, error) in
            self.process(data, urlResponse: response, error: error, callBack: callBack)
        })
        dataTask?.resume()
    }
}
