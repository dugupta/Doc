//
//  AppFlowCoordinator.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import UIKit

//protocol FlowCoordinating {
//    func start()
//    func finish()
//}
//
//protocol AppFlowCoordinating: AnyObject, FlowCoordinating {
//    func coordinateToPopularMoviesListPage()
//    func coordinateToPopularMovieDetailPage(_ movieId: String)
//    func coordinateToMovieHomePage(_ homePageUrl: String, movieName: String?)
//}
//
//// MARK: - Application Flow Coordinator
/////
///// - Note: This is a flow Coordinator controlles the application flow, all in and pout should be executed from here
//
//class AppFlowCoordinator: AppFlowCoordinating {
//    
//    private var navigationController: UINavigationController?
//    
//    ///Starts a flow coordinator
//    required init(_ contex: UINavigationController?) {
//        self.navigationController = contex
//    }
//    
//    ///Will coordinate to Movie List Page
//    func coordinateToPopularMoviesListPage() {
//        let viewModel = PopularMoviesListViewModel()
//        let controller = PopularMoviesListViewController(viewModel, delegate: self)
//        navigationController?.setViewControllers([controller], animated: false)
//    }
//    
//    ///Will coordinate to Movie Detail Page
//    func coordinateToPopularMovieDetailPage(_ movieId: String) {
//        let dataManager = PopularMovieDetailDataManager(movieId)
//        let viewModel = PopularMovieDetailViewModel(dataManager)
//        let controller = PopularMovieDetailViewController(viewModel, delegate: self)
//        navigationController?.pushViewController(controller, animated: true)
//    }
//    
//    ///Will coordinate to Movie Home Web Page
//    func coordinateToMovieHomePage(_ homePageUrl: String, movieName: String? = nil) {
//        let viewModel = PopularMovieHomeViewModel(homePageUrl, title: movieName)
//        let controller = PopularMovieHomeViewController(viewModel) {
//            self.navigationController?.dismiss(animated: true, completion: nil)
//        }
//        let navController = UINavigationController(rootViewController: controller)
//        navigationController?.present(navController, animated: true, completion: nil)
//    }
//    
//    func start() {
//        coordinateToPopularMoviesListPage()
//    }
//  
//    func finish() {
//        navigationController = nil
//    }
//}
