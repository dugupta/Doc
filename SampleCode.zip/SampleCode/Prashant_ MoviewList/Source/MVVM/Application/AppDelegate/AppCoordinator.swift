//
//  AppCoordinator.swift
//  MVVMC
//
//  Created by Durgesh Lal on 9/1/21.
//

import Foundation
import UIKit

protocol Coordinator: AnyObject {
    var children: [Coordinator] { get set }
    var navigationController: UINavigationController { get set }
    func start()
}

class AppCoordinator: NSObject, Coordinator {
    
    var children: [Coordinator] = []
    
    var navigationController: UINavigationController
    
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let coordinator = MovieListCoordinator(navigationController)
        children.append(coordinator)
        coordinator.parent = self
        coordinator.start()
    }
    
    func childDidFinish(_ child: Coordinator?) {
        if let index = children.firstIndex(where: { $0 === child }) {
            children.remove(at: index)
        }
    }
}

class MovieListCoordinator: Coordinator {
    weak var parent: AppCoordinator?
    
    var children: [Coordinator] = []
    
    var navigationController: UINavigationController
    
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        coordinateToPopularMovieList()
    }
    
    func didFinishUserList() {
        parent?.childDidFinish(self)
    }
}

// MARK:- Private Functions
extension MovieListCoordinator {
    private func coordinateToPopularMovieList() {
        let viewModel = PopularMoviesListViewModel()
        let controller = PopularMoviesListViewController(viewModel, coordinator: self)
        navigationController.pushViewController(controller, animated: false)
    }
}
