//
//  PopularMoviesResponse.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation

class PopularMoviesResponse: Codable, ObservableObject {
    let page: Int?
    let totalPages: Int?
    let totalResults: Int?
    let results: [Movie]? 
    
    private enum CodingKeys : String, CodingKey {
        case totalPages = "total_pages", page, totalResults = "total_results", results
    }
    
    class Movie: Codable {
        let releaseDate: String?
        let popularity: Double?
        let genreIds: [Int]?
        let title: String?
        let posterImageUrl: String?
        let thumbnailImageUrl: String?
        let overview: String?
        let movieId: Int?
        
        private enum CodingKeys : String, CodingKey {
            case releaseDate = "release_date", popularity, genreIds = "genre_ids", title, posterImageUrl = "poster_path", thumbnailImageUrl = "backdrop_path", overview, movieId = "id"
        }
    }
}
