//
//  PopularMoviesViewModel.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Combine
import Foundation

class PopularMoviesListViewModel {
    
    var error: Failure = .invalidURL {
        didSet {
            switch error {
            case .decoding:
                break
            case .invalidURL:
                break
            case .statusCode:
                break
            case .other(_):
                break
            case .badResponse:
                break
            }
        }
    }
    var notify: (() -> Void)? = nil
    private var data: [PopularMovieViewModel] = [] {
        didSet {
            notify?()
        }
    }
    
    private var dataManager: PopularMoviesDataManaging
    required init(_ dataManager: PopularMoviesDataManaging = PopularMoviesDataManager()) {
        self.dataManager = dataManager
        self.fetchGenres()
        self.fetchPopularMoviesList()
    }
    
    lazy var screenTitle: String? = {
        "Popular movies"
    }()
}

// MARK: Table View Data Source
extension PopularMoviesListViewModel {
    var numberOfRows: Int {
        data.count
    }
    func itemAt(_ indexPath: Int) -> PopularMovieViewModel {
        data[indexPath]
    }
    
    func updateItem(_ item: PopularMovieViewModel) -> Int? {
        if let index = itemIndex(item) {
            data[index] = item
            return index
        }
        return nil
    }
    
    func itemIndex(_ item: PopularMovieViewModel) -> Int? {
        if let firstindex = data.firstIndex(of: item) {
            return firstindex
        }
        return nil
    }
    
    var moviesList: [PopularMovieViewModel]  {
        self.data
    }
    
    func movieIdAt(_ indexPath: Int) -> String? {
        if let id = data[indexPath].rawItem.movieId {
            return "\(id)"
        }
        return nil
    }
}

// MARK: - APi calls
extension PopularMoviesListViewModel {
    
    func fetchPopularMoviesList() {
        dataManager.moviesList { response in
            switch response {
            case .success(let model):
                print("Model is \(model)")
                self.data = (model.results?.map({ PopularMovieViewModel($0)}))!
            case .failure(_):
                break
            }
        }
    }
    
    func fetchGenres() {
        
    }
}
