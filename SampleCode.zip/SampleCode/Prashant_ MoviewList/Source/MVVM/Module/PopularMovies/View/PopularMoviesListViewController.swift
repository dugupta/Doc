//
//  PopularMoviesListViewController.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import UIKit
import Combine

enum MovieSection {
    case main
}

class PopularMoviesListViewController: UITableViewController {
    
    private var viewModel:PopularMoviesListViewModel
    private var coordinator: MovieListCoordinator?
 
    private func internalSetup() {
        title = viewModel.screenTitle
        view.backgroundColor = .white
    }
    
    private func configureTableView() {
        tableView.register(PopularMovieCell.self)
    }
   
    required init(_ viewModel: PopularMoviesListViewModel, coordinator: MovieListCoordinator? = nil) {
        self.viewModel = viewModel
        self.coordinator = coordinator
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.notify = {
            self.tableView.reloadData()
        }
        internalSetup()
        configureTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRows
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellViewModel = viewModel.itemAt(indexPath.row)
        let cell = tableView.dequeueReusableCell(forIndexPath: indexPath) as PopularMovieCell
        cell.configureWith(cellViewModel)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let movieId = viewModel.movieIdAt(indexPath.row) else { return }
       // delegate?.coordinateToPopularMovieDetailPage(movieId)
    }
}

class ImageLoader {
    
    private var loadedImages = [URL: UIImage]()
    private var runningRequests = [UUID: URLSessionDataTask]()
    
    func loadImage(_ url: URL, _ completion: @escaping (Result<UIImage, Error>) -> Void) -> UUID? {
        // 1
        if let image = loadedImages[url] {
            completion(.success(image))
            return nil
        }
        
        // 2
        let uuid = UUID()
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            // 3
            defer { self.runningRequests.removeValue(forKey: uuid) }
            
            // 4
            if let data = data, let image = UIImage(data: data) {
                self.loadedImages[url] = image
                completion(.success(image))
                return
            }
            
            // 5
            guard let error = error else {
                // without an image or an error, we'll just ignore this for now
                // you could add your own special error cases for this scenario
                return
            }
            
            guard (error as NSError).code == NSURLErrorCancelled else {
                completion(.failure(error))
                return
            }
            
            // the request was cancelled, no need to call the callback
        }
        task.resume()
        
        // 6
        runningRequests[uuid] = task
        return uuid
    }
    
    func cancelLoad(_ uuid: UUID) {
        runningRequests[uuid]?.cancel()
        runningRequests.removeValue(forKey: uuid)
    }
    
    
    
}
