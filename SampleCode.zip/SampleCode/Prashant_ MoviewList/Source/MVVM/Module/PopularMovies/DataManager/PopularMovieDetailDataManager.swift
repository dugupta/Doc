//
//  PopularMovieDetailDataManager.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import Combine

protocol PopularMovieDetailDataManaging {
    init(_ movieId: String, networkManager: NetworkManaging)
    // MARK: - Populare Movie Detail
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    //func moviesDetail() -> AnyPublisher<PopularMoviesDetailResponse, Failure>
}

struct PopularMovieDetailDataManager: PopularMovieDetailDataManaging {
    
    enum EndPoint {
        case moviesDetail
        var url: String {
            switch self {
            case .moviesDetail:
                return "\(BaseUrl.polularMovies.url)movie/%@?"
            }
        }
    }
    
    private var networkManager: NetworkManaging
    private var page: Int = 1
    private var isApiInprocess = false
    private var movieId: String
    
    init(_ movieId: String, networkManager: NetworkManaging = NetworkManager()) {
        self.movieId = movieId
        self.networkManager = networkManager
    }
    
//    func moviesDetail() -> AnyPublisher<PopularMoviesDetailResponse, Failure> {
//        networkManager.request(url: String(format: EndPoint.moviesDetail.url, movieId), params: nil)
//        
//    }
}
