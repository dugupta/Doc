//
//  PopularMoviesDataManager.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
import Combine

protocol PopularMoviesDataManaging {
    init(_ networkManager: NetworkManaging)
    // MARK: - Populare Movie List
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    mutating func moviesList(_  callBack: @escaping (Result<PopularMoviesResponse, Failure>) -> Void)
    // MARK: - Genre
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    
    func fetchGenres(_  callBack: @escaping (Result<GenreResponse, Failure>) -> Void)
}

struct PopularMoviesDataManager: PopularMoviesDataManaging {
    
    enum EndPoint {
        case moviesList
        case genre
        var url: String {
            switch self {
            case .moviesList:
                return "\(BaseUrl.polularMovies.url)movie/popular?"
            case .genre:
                return "\(BaseUrl.polularMovies.url)genre/movie/list?"
            }
        }
    }
    
    private var networkManager: NetworkManaging
    private var page: Int = 1
    private var isApiInprocess = false
    
    init(_ networkManager: NetworkManaging = NetworkManager()) {
        self.networkManager = networkManager
    }
    
    func moviesList(_  callBack: @escaping (Result<PopularMoviesResponse, Failure>) -> Void) {
        networkManager.request(url: EndPoint.moviesList.url, params: ["page" : "\(page)"], callBack: callBack)
    }
    
    func fetchGenres(_  callBack: @escaping (Result<GenreResponse, Failure>) -> Void) {
        networkManager.request(url: EndPoint.genre.url, params: nil, callBack: callBack)
    }
}
