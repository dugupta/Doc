# MVVM
 
### [Project Detail]

A Sample app to fetch popular movies list, get details and explore home page. This provides few details including Genre, Run time, popularity, release date, overview etc. 

Api Details: Using open source apis from https://www.themoviedb.org/ . A activation or Api key is needed to fetch any apis
      1. Fetch popular movie list: https://api.themoviedb.org/3/movie/popular?api_key=539208b89a9c50661fd4d0753c8fd252&language=en-US&page=2
      2. Fetch Genre: https://api.themoviedb.org/3/genre/movie/list?api_key=539208b89a9c50661fd4d0753c8fd252&language=en-US
      3. Fetch movie details: https://api.themoviedb.org/3/movie/590706?api_key=539208b89a9c50661fd4d0753c8fd252&language=en-US
      4. Fetch Image: https://image.tmdb.org/t/p/w500/kqjL17yufvn9OVLyXYpvtyrFfak.jpg
      
###  [Third Party Apis & Libraries]

1. Logger: A refrence is taken from a blog to disable print logs in PROD environment and enable only in DEBUG
   Reference : https://medium.com/@sauvik_dolui/developing-a-tiny-logger-in-swift-7221751628e6
   
   Implementation details can be found in Log.swift
   
2. ImageURLProtol: A refrence from developer.apple.com to better manage Download image and cache.
    
    Implementation details can be found in ImageUrlProtocol.swift
    
### Design Pattern used [MVVM-C]
MVVM Pattern is used as aroot design pattern to modularize the components so that the view models containg the presenattion logic are unit testable.
For unit testing, static json files are being used.

1. ### Model
Raw objects, basically replica of json with few changes in key per need basis with the help of CodingKey in Swift

2. ### View Model
Modified version of Model with all the presenation tweaks and business logic. Also responsible for communicating between UI and Model.

3. ### View/ View Controller
Underlying view or root views are connected to the view model through view controller that its hosted in.


# Flow Chart

App Delegate -> AppCoordinator 
                            Start the flow from app cordinator using start() method
                                    Popular Movie List Page
                                            Click any movie, come back to AppCoordinator
                            AppCoordinator
                                    Push Movie detail page
                                            Click movie home, come back to AppCoordinator
                            AppCoordinator
                                    Present movie home page
                                            Click cancel button, come back to AppCoordinator
                            AppCoordinator

### Simple UI controller flow
        UIViewController(ViewModel(DataManager(NetworkManager)))
        1. View Model needs a Datamanger to get raw model objects.
        2. Data Manager needs a network manager to fetch remote data, and call back to data manager
        3. Once get data from view model, view model will refine and notify controller to reload UI.
        
