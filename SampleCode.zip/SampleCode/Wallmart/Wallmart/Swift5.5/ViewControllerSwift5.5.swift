//
//  ViewControllerSwift5.5.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/29/21.
//

import UIKit
class ViewControllerSwift5: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //let race = Race()
        
        DispatchQueue.main.async {
           // race.add()
        }
//
//        DispatchQueue.main.async {
//            race.substract()
//        }
    }
}


actor Race {
    var numberOfParticipants: Int = 0
    
    func add() {
        numberOfParticipants += 1
    }
    
    func substract() {
        numberOfParticipants -= 1
    }
    
    func modify() {
        self.add()
    }
}
