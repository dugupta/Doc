//
//  Heap.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/29/21.
//

import Foundation

struct Heap<Element: Equatable> {
    
    var elements: [Element] = []
    let sort: (Element, Element) -> Bool
    
    init(sort: @escaping (Element, Element) -> Bool) {
        self.sort = sort
    }
    
    var isEmpty: Bool {
        return elements.isEmpty
    }
    
    var count: Int {
        return elements.count
    }
    
    func peek() -> Element? {
        return elements.first
    }
    
    func leftChildIndex(ofParentAt index: Int) -> Int {
        return (2 * index) + 1
    }
    
    func rightChildIndex(ofParentAt index: Int) -> Int {
        return (2 * index) + 2
    }
    
    func parentIndex(ofChildAt index: Int) -> Int {
        return (index - 1) / 2
    }
    
    mutating func remove() -> Element? {
        guard !isEmpty else { // 1
            return nil
        }
        elements.swapAt(0, count - 1) // 2
        defer {
            siftDown(from: 0) // 4
        }
        return elements.removeLast() // 3
    }
    
    mutating func siftDown(from index: Int) {
        var parent = index // 1
        while true { // 2
            let left = leftChildIndex(ofParentAt: parent) // 3
            let right = rightChildIndex(ofParentAt: parent)
            var candidate = parent // 4
            
            if left < count && sort(elements[left], elements[candidate]) {
                candidate = left // 5
            }
            if right < count && sort(elements[right], elements[candidate]) {
                candidate = right // 6
            }
            if candidate == parent {
                return // 7
            }
            elements.swapAt(parent, candidate) // 8
            parent = candidate
        }
    }
}

