//
//  BinaryTree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/30/20.
//

import Foundation

struct TestBinaryNode {
    
    var create: BinaryNode<Int> {
        let zero = BinaryNode<Int>(value: 0)
        let one = BinaryNode<Int>(value: 1)
        let five = BinaryNode<Int>(value: 5)
        let seven = BinaryNode<Int>(value: 7)
        let eight = BinaryNode<Int>(value: 8)
        let nine = BinaryNode<Int>(value: 9)
        seven.leftChild = one
        one.leftChild = zero
        one.rightChild = five
        seven.rightChild = nine
        nine.leftChild = eight
        return seven
    }
    
    
    func test() {
        var searchTree = BinarySearchTree<Int>()
        searchTree.insert(1)
        searchTree.insert(3)
        searchTree.insert(5)
        searchTree.insert(7)
        searchTree.insert(9)
        searchTree.insert(11)
        
        print("searchTree description\(searchTree.description)")
        print("I am here")
    }
    
}


class BinaryNode<Element> {
    
    var value: Element
    var leftChild: BinaryNode?
    var rightChild: BinaryNode?
    
    init(value: Element) {
        self.value = value
    }
    
    var tree: BinaryNode<Int> {
        let zero = BinaryNode<Int>(value: 0)
        let one = BinaryNode<Int>(value: 1)
        let five = BinaryNode<Int>(value: 5)
        let seven = BinaryNode<Int>(value: 7)
        let eight = BinaryNode<Int>(value: 8)
        let nine = BinaryNode<Int>(value: 9)
        seven.leftChild = one
        one.leftChild = zero
        one.rightChild = five
        seven.rightChild = nine
        nine.leftChild = eight
        return seven
    }
    // LEFT CHILD | ROOT | RIGHT CHILD
    func traverseInOrder(visit: (Element) -> Void) {
        leftChild?.traverseInOrder(visit: visit)
        visit(value)
        rightChild?.traverseInOrder(visit: visit)
    }
    
    // ROOT | LEFT CHILD | RIGHT CHILD
    func traversePreOrder(visit: (Element) -> Void) {
        visit(value)
        leftChild?.traversePreOrder(visit: visit)
        rightChild?.traversePreOrder(visit: visit)
    }
    
    // LEFT CHILD | RIGHT CHILD | ROOT
    func traversePostOrder(visit: (Element) -> Void) {
        leftChild?.traversePreOrder(visit: visit)
        rightChild?.traversePreOrder(visit: visit)
        visit(value)
    }
    
    
    func heightOfTheTree(_ root: TreeNode<Int>?) -> Int {
        guard let root = root else { return 0}
        var height = 0
        let left = heightOfTheTree(root.left)
        let right = heightOfTheTree(root.right)
        return max(left, right) + 1
    }
}


struct BinarySearchTree<Element: Comparable> {
  private(set) var root: BinaryNode<Element>?
  init() {}
}

extension BinarySearchTree {
    public mutating func insert(_ value: Element) {
        root = insert(from: root, value: value)
    }
    
    private func insert(from node: BinaryNode<Element>?, value: Element) -> BinaryNode<Element> {
        guard let node = node else {
            return BinaryNode(value: value)
        }
        if value < node.value {
            node.leftChild = insert(from: node.leftChild, value: value)
        } else {
            node.rightChild = insert(from: node.rightChild, value: value)
        }
        return node
    }
}

extension BinaryNode: CustomStringConvertible {
    var description: String {
        return diagram(for: self)
    }
    
    private func diagram(for node: BinaryNode?,
                         _ top: String = "",
                         _ root: String = "",
                         _ bottom: String = "") -> String {
        guard let node = node else {
            return root + "nil\n"
        }
        if node.leftChild == nil && node.rightChild == nil {
            return root + "\(node.value)\n"
        }
        return diagram(for: node.rightChild, top + " ", top + "┌──", top + "│ ")
            + root + "\(node.value)\n"
            + diagram(for: node.leftChild,
                      bottom + "│ ", bottom + "└──", bottom + "")
    }
}

extension BinarySearchTree: CustomStringConvertible {
    public var description: String {
        return root?.description ?? "empty tree"
    }
}
   

extension BinarySearchTree {
   
    func contains(_ value: Element) -> Bool {
        guard let root = root else {
            return false
        }
        var found = false
        root.traverseInOrder {
            if $0 == value {
                found = true
            }
        }
        return found
    }
}

extension BinarySearchTree {
    func containsWithWhileLoop(_ value: Element) -> Bool {
        var current = root
        while let node = current {
            if node.value == value { return true }
            if value < node.value {
                current = node.leftChild
            } else {
                current = node.rightChild
            }
        }
        return false
    }
}


extension BinarySearchTree {
    func optimizedContains(_ value: Element) -> Bool {
        guard let root = self.root else { return false }
        func left() -> Bool {
            guard let left = root.leftChild?.value else {
                return false
            }
            return optimizedContains(left)
        }
        guard let righChild = root.rightChild?.value else {
           return left()
        }
        if value < righChild {
            return left()
        } else {
            return optimizedContains(righChild)
        }
    }
}

extension BinaryNode {
    var min: BinaryNode {
        return leftChild?.min ?? self
    }
}

extension BinarySearchTree {
    //https://www.youtube.com/watch?v=gcULXE7ViZw&ab_channel=mycodeschool
    mutating func remove(_ value: Element) {
        root = remove(node: root, value: value)
    }
    
    private func remove(node: BinaryNode<Element>?, value: Element) -> BinaryNode<Element>? {
        guard let node = node else { return nil }
        if value == node.value {
            //Case 1: Leaf node | No child
            if node.leftChild == nil && node.rightChild == nil {
                return nil
            }
            //Case: Leaf node | One child
            if node.leftChild == nil {
                return node.rightChild
            }
            if node.rightChild == nil {
                return node.leftChild
            }
            node.value = node.rightChild!.min.value
            node.rightChild = remove(node: node.rightChild, value: node.value)
        } else if value < node.value {
            node.leftChild = remove(node: node.leftChild, value: value)
        } else {
            node.rightChild = remove(node: node.rightChild, value: value)
        }
        return node
    }
}


class Solution1 {
    func removeDuplicates(_ s: String, _ k: Int) -> String {
        var input = Array(s)
        var stack: [[Character : Int]] = []
        
        for (index, item) in input.enumerated() {
            if let last = stack.last {
                print("last \(last.keys)")
                if last.keys.first == item {
                    let value = last.values.first
                    if value == k - 1 {
                        stack.removeLast()
                    } else {
                        let newDict = [item : value! + 1]
                        stack[stack.count - 1] = newDict
                    }
                } else {
                    let value = [item : 1]
                    stack.append(value)
                }
            } else {
                let value = [item : 1]
                stack.append(value)
            }
        }
        
        print("last \(stack)")
        var result = ""
        for item in stack {
            for counter in 1...item.values.first! {
                result += "\(item.keys.first!)"
            }
        }
        print("result \(result)")
        return result
        let char: Character = "A"
        if char.isASCII && char.isNumber { }
        
        return ""
    }
}
