//
//  Node.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/18/21.
//

import Foundation

extension LinkedListNode {
    static func execute() {
        let node1 = Node(value: 1)
        let node2 = Node(value: 2)
        let node3 = Node(value: 3)
        node1.next = node2
        node2.next = node3
        print(node1)
    }
}

class LinkedListNode<Value> {
    var value: Value
    var next: LinkedListNode?
    init(value: Value, next: LinkedListNode? = nil) {
        self.value = value
        self.next = next
    }
}

extension LinkedListNode: CustomStringConvertible {
    var description: String {
        guard let next = next else {
            return "\(value)"
        }
        return "\(value) -> " + String(describing: next) + " "
    }
}



