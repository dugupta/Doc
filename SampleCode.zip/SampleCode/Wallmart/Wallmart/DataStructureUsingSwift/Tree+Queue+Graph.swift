//
//  Tree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation
import UIKit

struct Queue<Element> {
        
    var array: [Element] = []
    
    mutating func enqueue(_ element: Element) -> Bool {
        array.append(element)
        return true
    }
    mutating func dequeue() -> Element? {
        return isEmpty ? nil : array.removeFirst()
    }
    
    var isEmpty: Bool {
        return array.isEmpty
    }
    
    var peek: Element? {
        array.first
    }
}

func makeBeverageTree() -> TreeNode<String> {
    let tree = TreeNode<String>("Beverages")
    let hot = TreeNode<String>("hot")
    let cold = TreeNode<String>("cold")
    let tea = TreeNode<String>("tea")
    let coffee = TreeNode<String>("coffee")
    let chocolate = TreeNode<String>("cocoa")
    let blackTea = TreeNode<String>("black")
    let greenTea = TreeNode<String>("green")
    let chaiTea = TreeNode<String>("chai")
    let soda = TreeNode<String>("soda")
    let milk = TreeNode<String>("milk")
    let gingerAle = TreeNode<String>("ginger ale")
    let bitterLemon = TreeNode<String>("bitter lemon")
    tree.add(hot)
    tree.add(cold)
    hot.add(tea)
    hot.add(coffee)
    hot.add(chocolate)
    cold.add(soda)
    cold.add(milk)
    tea.add(blackTea)
    tea.add(greenTea)
    tea.add(chaiTea)
    soda.add(gingerAle)
    soda.add(bitterLemon)
    return tree
}

class TreeNode<T> {
    var left: TreeNode?
    var right: TreeNode?
    var value: T
    var children: [TreeNode] = []
    
    init(_ value: T) {
        self.value = value
    }
    
    func add(_ child: TreeNode) {
        children.append(child)
    }
}

//Depth-first traversal || DFS
extension TreeNode {
    func forEachDepthFirst(visit: (TreeNode) -> Void) {
        visit(self)
        children.forEach {
            $0.forEachDepthFirst(visit: visit)
        }
    }
}
//BFS
extension TreeNode {
    
    func forEachLevelOrder(visit: (TreeNode) -> Void) {
        visit(self)
        var queue = Queue<TreeNode>()
        children.forEach { _ = queue.enqueue($0) } //append
        while let node = queue.dequeue() { // dequeue is remove object at first index
            visit(node)
            node.children.forEach { _ = queue.enqueue($0) }
        }
    }
}

extension TreeNode where T: Equatable {
    func search(_ value: T) -> TreeNode? {
        var result: TreeNode?
        forEachLevelOrder { node in
            if node.value == value {
                result = node
            }
        }
        return result
    }
}


struct TestTreeNode {
    static func test() {
        let tree = makeBeverageTree()
        tree.forEachLevelOrder { print($0.value) }
    }
}
