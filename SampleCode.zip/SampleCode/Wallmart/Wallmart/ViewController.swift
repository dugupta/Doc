//
//  ViewController.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/25/20.
//

import UIKit
import Combine

class AppSettings:  ObservableObject {
    @Published var language = "English"
}

class Environment {
    static let updateChanged = Notification.Name("EnvironmentChangeUpdate")
    static let shared = Environment()
    
    private var sinks  = [AnyCancellable]()
    
    var values = [Any]()
    
    private init() { }
    
    
    func register<T: ObservableObject>(_ value: T) {
        values.append(value)
        
        let sink = value.objectWillChange.sink { _ in
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: Self.updateChanged, object: value)
            }
        }
        sinks.append(sink)
    }
}


protocol GlobalUpdating {
    func update()
}

extension GlobalUpdating {
    func registerForUpdate() {
        update()
    }
}

@propertyWrapper struct Global<ObjectType: ObservableObject> {
    var wrappedValue: ObjectType

    init() {
        if let value = Environment.shared.values.first(where: { $0 is ObjectType }) as? ObjectType {
            self.wrappedValue = value
        } else {
            fatalError("Missing Type in Environment")
        }
            
    }
}


class SecondViewController: UIViewController, GlobalUpdating {
    
    @Global var appSettings: AppSettings
    
    func update() {
        //MemberwiseStruct().access
        print("Value of app Settings in second view controller is \(appSettings.language)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerForUpdate()
    }
    
}

class SolutionLowercase {
    
    func buddyStrings(_ stringOne: String, _ stringTwo: String) -> Bool {
        if stringOne.length != stringTwo.length || stringOne.isEmpty || stringTwo.isEmpty {
            return false
        }
        
        
        if stringOne == stringTwo {
            
        }
        
        
        let memory: NSMutableDictionary = NSMutableDictionary()
        var count = 0
       // var unmatchedIndex = 0
        for (index, char) in stringOne.enumerated() {
            if char == stringTwo[stringTwo.index(stringTwo.startIndex, offsetBy: index)] {
                continue
            } else {
                memory[index] = index
                count += 1
            }
        }
        
//        if count == 2 {
//            let values = memory.allValues
//            let firstIndex: Int = values[0] as! Int
//            let secondIndex: Int = values[1] as! Int
//            if stringOne[firstIndex] == stringTwo[secondIndex] && stringOne[secondIndex] == stringTwo[firstIndex] {
//                return true
//            }
//        } else if count == 0 {
//            if stringOne.length == 2 && stringTwo.length == 2 {
//                return stringOne == String(stringTwo.reversed())
//            } else {
//                return true
//            }
//        }
        return false
    }
   
}




class ViewController: UIViewController, GlobalUpdating {
    //[2,3,1,1,4]
    func checkSubarraySum(_ nums: [Int] =  [23,2,4,6,7], _ k: Int = 6) -> Bool {
           var map : [Int: Int] = [0 : -1]
           var sum = 0
           
           for (index, item) in nums.enumerated() {
               sum += item
               
               if k != 0 { sum = sum % k }
               
               if let existingIndex = map[sum] {
                   if index - existingIndex > 1 {
                       return true
                   }
               } else {
                   map[sum] = index
               }
           }
           return false
    }
    func jump(_ nums: [Int] = [2,3,1,1,4]) -> Int {
        let count = nums.count
        if count == 1 { return 0 }
        var jumpArray: [Int] = Array(repeating: 0, count: count)
        var stepsICanJump: Int = nums.first!
        var maxPositionIAm: Int = 0
        var numberOfMinJump: Int = 1
        
        for index in 0..<nums.count {
            if stepsICanJump < index {
                numberOfMinJump += 1
                stepsICanJump = maxPositionIAm
            }
            
            maxPositionIAm = max(maxPositionIAm, nums[index] + index)
            jumpArray[index] = numberOfMinJump
        }
        
        return jumpArray.last!
    }
    
    @Global var appSettings: AppSettings
    
    func update() {
        print("Value of app Settings in ViewController controller is \(appSettings.language)")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerForUpdate()
        checkSubarraySum()
        
        let second = SecondViewController()
        
        print("Value from second view controller = \(second.appSettings.language)")
        
        appSettings.language = "Hindi"
        
        print("Value from second view controller after change = \(second.appSettings.language)")
        
        /*
        self.jump([2,3,1,1,4])
   
        var array = [2,0,6,6]
        
//        let zero = array.filter({ $0 == 0})
//        if zero.count == 4 {
//            return "00:00"
//        }
        var indexOne: Int = 0
        var indexTwo: Int = 0
        var largest: Int = 0
        for (index, object) in array.enumerated() {
            for (innerIndex, _) in array.enumerated() {
                if index == innerIndex { continue }
                let hour: Int! = Int("\(array[index])\(array[innerIndex])")
                if hour > largest && hour < 24 {
                    largest = hour
                    indexOne = index
                    indexTwo = innerIndex
                }
            }
        }
        if (indexOne + indexTwo) > 0 {
            if indexOne > indexTwo {
                array.remove(at: indexOne)
                array.remove(at: indexTwo)
            } else {
                array.remove(at: indexTwo)
                array.remove(at: indexOne)
            }
            array = array.sorted().reversed()
            var min = "\(array[0])\(array[1])"
            if Int(min) ?? 0 > 59 {
                array = array.reversed()
                min = "\(array[0])\(array[1])"
            }
            let h = largest < 10 ? "0\(largest)" : "\(largest)"
            if Int(h) ?? 0 > 23 || Int(min) ?? 0 > 50 {
            }
            print("\(h):\(min)")
        }
        
        
        
        print("Condition pass \(SolutionLowercase().buddyStrings("aaaaaaabc", "aaaaaaacb"))")
        print("Matrix one \(self.numberOfUniquePath(1, columns: 1))")
        print("Matrix two \(self.numberOfUniquePath(2, columns: 2))")
        print("Matrix three \(self.numberOfUniquePath(3, columns: 3))")
        print("Matrix four \(self.numberOfUniquePath(2, columns: 3))")
        print("Matrix five \(self.numberOfUniquePath(3, columns: 2))")
        print("Matrix six \(self.numberOfUniquePath(4, columns: 4))")
        print("Matrix seven \(self.numberOfUniquePath(3, columns: 4))")
        print("Matrix eight \(self.numberOfUniquePath(2, columns: 4))")
        print("Matrix nine \(self.numberOfUniquePath(4, columns: 3))")
        print("Matrix ten \(self.numberOfUniquePath(4, columns: 2))")
        print("Matrix eleven \(self.numberOfUniquePath(4, columns: 4))")
        
        print("Number of hits \(numberOfHit(start: 1))")
        let all = allSubString("civilwartestingwhetherthatnaptionoranynartionsoconceivedandsodedicatedcanlongendureWeareqmetonagreatbattlefiemldoftzhatwarWehavecometodedicpateaportionofthatfieldasafinalrestingplaceforthosewhoheregavetheirlivesthatthatnationmightliveItisaltogetherfangandproperthatweshoulddothisButinalargersensewecannotdedicatewecannotconsecratewecannothallowthisgroundThebravelmenlivinganddeadwhostruggledherehaveconsecrateditfaraboveourpoorponwertoaddordetractTgheworldadswfilllittlenotlenorlongrememberwhatwesayherebutitcanneverforgetwhattheydidhereItisforusthelivingrathertobededicatedheretotheulnfinishedworkwhichtheywhofoughtherehavethusfarsonoblyadvancedItisratherforustobeherededicatedtothegreattdafskremainingbeforeusthatfromthesehonoreddeadwetakeincreaseddevotiontothatcauseforwhichtheygavethelastpfullmeasureofdevotionthatweherehighlyresolvethatthesedeadshallnothavediedinvainthatthisnationunsderGodshallhaveanewbirthoffreedomandthatgovernmentofthepeoplebythepeopleforthepeopleshallnotperishfromtheearth")
        var longest = ""
        for pelindrome in all {
            if pelindrome.isPalindrome {
                if pelindrome.count > longest.count {
                    longest = pelindrome
                }
            }
        }
        print("Longesnt pelindrome is \(longest)")
         */
    }
}


extension ViewController {
    func allSubString(_ string: String = "babad") -> [String] {
        var array: [String] = []
        func all(_ string: String = "babad") {
            var pelindrome = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                pelindrome += String(char)
                array.append(pelindrome)
            }
            all(String(string.dropFirst()))
        }
        all(string)
        return array
    }
}



extension ViewController {
    
    func numberOfUniquePath(_ rows: Int, columns: Int) -> Int {
        var matrix: [[Int]] = []
        
        for _ in 0..<rows {
            var items: [Int] = []
            for _ in 0..<columns {
                items.append(0)
            }
            matrix.append(items)
        }
        
        for row in 0..<rows {
            for column in 0..<columns {
                if row == 0 || column == 0 {
                    matrix[row][column] = 1
                } else {
                    matrix[row][column] = matrix[row - 1][column] + matrix[row][column - 1]
                }
            }
        }
        return matrix[rows - 1][columns - 1]
    }
}

extension ViewController {
    func binarySearch(in numbers: [Int], for value: Int) -> Int? {
        var left = 0
        var right = numbers.count - 1

        while left <= right {

            let middle = Int(floor(Double(left + right) / 2.0))

            if numbers[middle] < value {
                left = middle + 1
            } else if numbers[middle] > value {
                right = middle - 1
            } else {
                return middle
            }
        }

        return nil
    }
}

extension ViewController {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let node1 = Node(value: 1)
        let node2 = Node(value: 2)
        let node3 = Node(value: 3)
        node1.next = node2
        node2.next = node3
        print(node1)
    }
}

class Node<Value> {
    var value: Value
    var next: Node?
    init(value: Value, next: Node? = nil) {
        self.value = value
        self.next = next
    }
}

extension Node: CustomStringConvertible {
    var description: String {
        guard let next = next else {
            return "\(value)"
        }
        return "\(value) -> " + String(describing: next) + " "
    }
}

struct LinkedList<Value> {
    var head: Node<Value>?
    var tail: Node<Value>?
    init() {}
    
    var isEmpty: Bool {
        head == nil
    }
    
    //push: Adds a value at the front of the list.
    mutating func push(_ value: Value) {
        head = Node(value: value, next: head)
        if tail == nil {
            tail = head
        }
    }
    
    //append: Adds a value at the end of the list.
    mutating func append(_ value: Value) {
        guard !isEmpty else {
            push(value)
            return
        }
        tail!.next = Node(value: value)
        tail = tail!.next
    }
    
    func node(at index: Int) -> Node<Value>? {
        var currentNode = head
        var currentIndex = 0
        while currentNode != nil && currentIndex < index {
            currentNode = currentNode!.next
            currentIndex += 1
        }
        return currentNode
    }
    
    @discardableResult
    mutating func insert(_ value: Value,
                                after node: Node<Value>) -> Node<Value>  {
        guard tail !== node else {
            append(value)
            return tail!
        }
        node.next = Node(value: value, next: node.next)
        return node.next!
    }
    
    //pop: Removes the value at the front of the list.
    @discardableResult
    mutating func pop() -> Value? {
        defer {
            head = head?.next
            if isEmpty {
                tail = nil
            }
        }
        return head?.value
    }
    
    //removeLast: Removes the value at the end of the list.
    @discardableResult
    mutating func removeLast() -> Value? {
        guard let head = head else {
            return nil
        }
        guard head.next != nil else {
            return pop()
        }
        var prev = head
        var current = head
        while let next = current.next {
            prev = current
            current = next
        }
        prev.next = nil
        tail = prev
        return current.value
    }
    
    //remove(at:): Removes a value anywhere in the list.
    @discardableResult
    mutating func remove(after node: Node<Value>) -> Value {
        defer {
            if node.next === tail {
                tail = node
            }
            node.next = node.next?.next
        }
        return node.next!.value
    }
}

struct TestLinkdeList {
    static func test() {
        var list = LinkedList<Int>()
        list.push(3)
        list.push(2)
        list.push(1)
        list.push(5)
        list.push(7)
        list.push(0)
        list.push(10)
        
        let node = list.node(at: 5)
        
        print("Node is \(node)")
    }
}

extension LinkedList: CustomStringConvertible {
    var description: String {
        guard let head = head else {
            return "Empty list"
        }
        return String(describing: head)
    }
}

//https://www.careercup.com/question?id=5728764059713536
// N number of balloons
extension UIViewController {
    
    func numberOfHit(_ objects: [Int] = [5, 4, 3, 3, 2, 2, 1, 1, 1], start: Int) -> Int {
        var balloons = objects
        if balloons.isEmpty { return 0 }
        var indexes: [Int] = []
        for (index, balloon) in balloons.enumerated() {
            guard !indexes.isEmpty else {
                indexes.append(balloon)
                continue
            }
            if balloons[index - 1] == balloon { continue }
            if balloons[index - 1] - 1 == balloon {
                indexes.append(balloon)
            } else {
               break
            }
        }
        //Remove all the object and call again
        for object in indexes {
            if let index = balloons.firstIndex(of: object) {
                balloons.remove(at: index)
            }
        }
        _ = numberOfHit(balloons, start: start + 1)
        return start
    }
    
}


