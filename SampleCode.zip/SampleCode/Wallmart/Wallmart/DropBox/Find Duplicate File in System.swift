//
//  Find Duplicate File in System.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/14/21.
//

import Foundation

struct FindDuplicateFileInTheSystem {
    func findDuplicate(_ paths: [String] = ["root/a 1.txt(abcd) 2.txt(efgh)","root/c 3.txt(abcd)","root/c/d 4.txt(efgh)","root 4.txt(efgh)"]) -> [[String]] {
        var data: [String: [(directory:String,filename:String)]] = [:]
        for path in paths {   //data: Key is filecontents, Val is array of files + (dir)
            let items = path.components(separatedBy:" ")
            for i in 1..<items.count {
                var file = items[i].components(separatedBy:"(")
                let tuple = (directory:items[0],filename:file[0])
                data[String(file[1].dropLast()), default:[] ].append(tuple)   //dropLast removes ')'
            }
        }
        return data.values.map{$0.map{ $0.directory + "/" + $0.filename }}.filter{$0.count > 1}
    }
}
//[  ["root/a/2.txt", "root/c/d/4.txt", "root/4.txt"],  ["root/a/1.txt","root/c/3.txt"]  ]

