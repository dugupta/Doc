//
//  Robot Bounded In Circle.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/2/21.
//

import Foundation
/*
 ///https://leetcode.com/problems/robot-bounded-in-circle/
 */


struct RobotBoundedInCircle {
    func isRobotBounded(_ instructions: String = "GGLLGG") -> Bool {
        var x = 0
        var y = 0
        var d = 0
        let direction = [(0,1), (0,1), (0,-1), (0,-1)]
        let input = Array(instructions)
        for item in input {
            switch item {
            case Character("G") :
                x += direction[abs(d%4)].0
                y += direction[abs(d%4)].1
            case Character("L") :
                d -= 1
            default:
                d += 1
            }
        }
        return (x == 0 && y == 0) || d%4 != 0
        /*
        
        var input = Array(instructions)
        var dirX = 0
        var dirY = 1
        
        var x = 0
        var y = 0
        
        for item in input {
            switch item {
            case Character("G") :
                x += dirX
                y += dirY
            case Character("L") :
                let temp = dirX
                dirX = -dirY
                dirY = temp
            default:
                let temp = dirY
                dirY = -dirX
                dirX = temp
            }
        }
        return (x == 0 && y == 0) || (dirX != 0 || dirY != 1)
 */
    }
}
