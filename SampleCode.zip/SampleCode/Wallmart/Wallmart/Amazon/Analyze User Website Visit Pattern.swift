//
//  Analyze User Website Visit Pattern.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/21/21.
//

import Foundation


struct AnalyzeUserWebsiteVisitPattern {
    struct User {
            let userName: String
            let timeStamp: Int
            let website: String
        }
        
        func getSequence(_ arr: [String], _ index: Int, _ curr: [String], _ result: inout Set<[String]>) {
            if curr.count == 3 {
                result.insert(curr)
                return
            }
            //guard index < arr.count else { return }
            for i in index..<arr.count {
                getSequence(arr, i + 1, curr + [arr[i]], &result)
            }
        }
        // This is the original func
        func mostVisitedPattern(_ username: [String] = ["joe","joe","joe","james","james","james","james","mary","mary","mary"], _ timestamp: [Int] = [1,2,3,4,5,6,7,8,9,10], _ website: [String] = ["home","about","career","home","cart","maps","home","home","about","career"]) -> [String] {
            
            var users: [User] = []
            for (index, item) in username.enumerated() {
                users.append(User(userName: username[index], timeStamp: timestamp[index], website: website[index]))
            }
            
            var sortedUser = users.sorted(by: { $0.timeStamp < $1.timeStamp })
            
            var userPathDic: [String : [String]] = [:]
            
            for user in sortedUser {
                userPathDic[user.userName, default: []].append(user.website)
            }
            //userPathDic ["james": ["home", "cart", "maps", "home"], "joe": ["home", "about", "career"], "mary": ["home", "about", "career"]]

            var pathFreqDic = [[String] : Int]()
            
            var maxCounter = 0
            
            for (user, path) in userPathDic {
                var pathSet = Set<[String]>()
                getSequence(path,0, [], &pathSet)
                guard pathSet.count > 0 else { continue }
                let pathArray = Array(pathSet)
                
                for path in pathArray {
                    pathFreqDic[path, default: 0] += 1
                    maxCounter = max(maxCounter, pathFreqDic[path]!)
                }
            }
            
            var arr = [[String]]()
            
            for (path, freq) in pathFreqDic {
                if freq == maxCounter {
                    arr.append(path)
                }
            }
            
            arr.sort{ (arr1, arr2) -> Bool in
                    for i in 0..<3 {
                         guard arr1[i] != arr2[i] else { continue }
                        return arr1[i] < arr2[i]
                    }
                    return true
            }
            
            
            return arr[0]
        }
}
