//
//  Minimum Cost to Connect Sticks.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/2/21.
//

import Foundation


struct MinimumCostConnectSticks {
    func binarySearch(_ dp: inout [Int], _ target: Int) {
        var low = 0
        var high = dp.count - 1
        
        while low <= high {
            
            let mid =  Int(floor(Double(low + high) / 2))
            
            if dp[mid] >= target {
                high = mid - 1
            } else {
                low = mid + 1
            }
        }
        dp.insert(target, at: low)
    }
    
    
    func connectSticks(_ sticks: [Int] = [3354,4316,3259,4904,4598,474,3166,6322,8080,9009]) -> Int {
        if sticks.count == 1 { return 0 }
        var input = sticks.sorted(by: < )
        print("Input is: \(input)")
        var result = 0
        while input.count > 1 {
            let first = input.removeFirst()
            let second = input.removeFirst()
            let sum  = first + second
            result += sum
            print("Input is Before binay search: \(input), sum is: \(sum)")
            binarySearch(&input, sum)
            print("Input is After  binay search: \(input), sum is: \(sum)")
        }
        
        print("Input is: \(input), result is: \(result)")
        
        return result
    }
}
