//
//  AppDelegate.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/25/20.
//

import UIKit

struct MemberwiseStruct {
    var lastName: String
    var firstName: String?
    
    fileprivate let access: String? = nil
}

extension MemberwiseStruct {
    init() {
        self.lastName = ""
        
        var numbers = [1, 2, 3, 4, 5]
        numbers.insert(100, at: 3)
        numbers.insert(200, at: numbers.startIndex)
    }
}


@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    
    func checkingMemberswiseStruct() {
        print("Compile")
        
    }
    
    func pivotIndex(_ nums: [Int] = [2, -2, -3, 3]) -> [Int] {
        var right = nums.reduce(0) { result, item in result + item }
        
        print("Right is \(right)")
        var left = 0
        var result: [Int] = []
        for index in 0..<nums.count {
            right -= nums[index]
            if left == right {
                print("I am here")
                result.append(index)
            }
            left += nums[index]
        }
        print("index \(result)")
        return result
    }
    
    
    public func solution(_ A : inout [Int], _ B : inout [Int]) -> Int {
       let first = pivotIndex(A)
        let second = pivotIndex(A)

        return first.filter(second.contains).count
    }
    
    func minWindow(_ s: String = "ADOBECODEBANC", _ t: String = "ABC") -> String {
            var cacheT : [Character: Int] = [:]
            var cacheS : [Character: Int] = [:]
            for item in t {
                cacheT[item, default: 0] += 1
            }
            var array = Array(s)
            var returnValue: [Character] = []
            var result: [Character] = []
            
            for (index, item) in array.enumerated() {
                if let found = cacheT[item] {
                    result.append(item)
                    cacheS[item, default: 0] += 1
                    
                    if cacheT == cacheS {
                        print("cacheT\(cacheT) & cacheS\(cacheS)")
                        if returnValue.count == 0 || result.count < returnValue.count {
                            returnValue = result
                        }
                        print("result \(result) and cacheS \(cacheS)")
                        
                        let value = result.removeFirst()
                        cacheS[value] = cacheS[value]! - 1
                        
                        if cacheS[value] == 0 {
                            cacheS[value] = nil
                        }
                        
                        for item in result {
                            if let found = cacheT[item] {
                                break
                            } else {
                                result.removeFirst()
                            }
                        }
                    }
                    
                } else {
                    if result.count > 0 && returnValue.count == 0 {
                        result.append(item)
                    }
                }
               
            }
            return String(returnValue)
        }
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        minWindow()
        AnalyzeUserWebsiteVisitPattern().mostVisitedPattern()
        GraphBipartite().isBipartite()
        AccountsMerge().accountsMerge()
        ValidWordAbbreviation().validWordAbbreviation()
        FindDuplicateFileInTheSystem().findDuplicate()
        pivotIndex()
        MinimumCostConnectSticks().connectSticks()
        RobotBoundedInCircle().isRobotBounded()
        RemoveDuplicateLetters().removeDuplicateLetters()
        ConstructBinaryTreefromInorderandPostorderTraversal().buildTree()
        MissingRange().findMissingRanges()
        ExclusiveTimeofFunctions().exclusiveTime()
        NumberofVisiblePeopleinaQueue().canSeePersonsCount()
        JumpGame().jump()
        BestTimetoBuyandSellStockIII().maxProfit()
        FreqStack.test()
        MakingFileNamesUnique().getFolderNames()
        TestBinaryNode().test()
        TestTreeNode.test()
        TestLinkdeList.test()
        ValidParenthesisString().checkValidString()
        TopKFrequentWords().topKFrequent()
        // This is a working solution
        print("abcd".subStrings())
        HitCounter.test()
        HouseRobberII().rob()
        MinimumInitialEnergytoFinishTasks().minimumEffort()
        MakingALargeIsland().largestIsland()
        MaxAreaOfIsland().maxAreaOfIsland()
        ValidNumber().isNumber()
        RemoveInvalidParentheses().removeInvalidParentheses()
        KthMissingPositiveNumber().findKthPositive()
        
        LongestSubstringWithoutRepeatingCharacters().lengthOfLongestSubstringWithDict()
        
        let node = makeBeverageTree()
        _ = node.forEachDepthFirst(visit: { node in
            print("Current node value is \(node.value)")
            //print("Current node left is \(node.left)")
            //print("Current node right is \(node.right)")
            //print("Current node children is \(node.children)")
        })
        print("********")
        node.forEachLevelOrder { node in
            print("Current node forEachLevelOrder value is \(node.value)")
        }
        
        LowestCommonAncestorofDeepestLeaves.test()
        
        SmallestSubsequenceOfDistinctCharacters().removeDuplicateLetters()
        LinkedListNode<Any>.execute()
        ProductofArrayExceptSelf().productExceptSelf()
        ContinuousSubarraySum().checkSubarraySum()
        SubarraySumEqualsK().subarraySum()
        BuildingsWithAnOceanView().findBuildings()
        AddStrings().addStrings()
        KClosestPointstoOrigin().kClosest()
        ValidPalindrome2().validPalindrome()
        VerifyingAlienDictionary().isAlienSorted()
        MinimumRemoveToMakeValidParentheses().minRemoveToMakeValid()
        let newMember = MemberwiseStruct(lastName: "Gupta")
        print(newMember)
        
        TrappingRainWater().trap([0,1,0,2,1,0,1,3,2,1,2,1])
        let names = ["Taylor", "Paul", "Adele"]
        let count = names.reduce("") {
            let first = $0
            let last = $1
            print("First is \(first)")
            print("Last is \(last)")
            return ($0 + $1)
        }
        print(count)
        
        
        struct MyStruct {
            var abc: String = "initila value"
            
            mutating func changeValue() {
                abc = "some other value" //Compile time error: Cannot assign to property: 'self' is immutable. Mark method 'mutating' to make 'self' mutable.
            }
        }
        
        
        var testOne = MyStruct()
        print(testOne)
        
        print(testOne.changeValue())
        
        print(testOne)
        
        
        UniquePath().uniquePaths(4, 5)
        Environment.shared.register(AppSettings())
        
        ShortestDistance().shortestDistance(["a","c","b","b","a"], "a", "b")
        
        //        //Generate Parentheses
                let parentheses = GenerateParentheses()
                print(parentheses.generateParenthesis(3))
        //
        //
        //        //Insert Delete & Get Random in order 1
        //
        //        let insertDeleteGetRandom = RandomizedCollection()
        //
        //        //Degree of an array
        //        let degree = DegreeOfAnArray()
        //        degree.findShortestSubArray([1,2,2,3,1])
        //        /*
        //         ["RandomizedCollection","insert","insert","insert","getRandom","remove","getRandom"]
        //         [[],[1],[1],[2],[],[1],[]]
        //
        //
        //         ["RandomizedCollection","remove","remove","insert","getRandom","remove","insert"]
        //         [[],[0],[0],[0],[],[0],[0]]
        //         */
        //
        //        let letterCombinationOfPhoneNumber = LetterCombinationsofaPhoneNumber()
        //        letterCombinationOfPhoneNumber.letterCombinations("234")
        //
        //        let binarySearch = SearchInRotatedSortedArray()
        //        binarySearch.binarySearch(in: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], for: 6)
        //
        let searchInTwoDMatrix = SearchTwoDMatrix()
        searchInTwoDMatrix.searchMatrix([[1,4,7,11,15],[2,5,8,12,19],[3,6,9,16,22],[10,13,14,17,24],[18,21,23,26,30]], 5)
        //
        //        let coinChnage = CoinChange()
        //        coinChnage.coinChange([1, 2, 5, 10], 11)
        //
        //        let floodFill = NewFunction()
        //        floodFill.floodFill([[1,1,1],[1,1,0],[1,0,1]], 1, 1, 2)
        //
                let lruCache = LRUCache(3)
                lruCache.test()
        //
        //        let spiralMatrix = SpiralMatrix()
        //        spiralMatrix.spiralOrder([[7],[9],[6]])
        //
                let generateParantheses = GenerateParentheses()
                generateParantheses.generateParenthesisUsingBackTrack(3)
        //
        //        let minimumWindow = MinimumWindowSubstring()
        //        minimumWindow.minWindow("ADOBECODEBANC", "ABC")
        //
        //        let compress = StringCompression()
        //        var chars: [Character] = ["a","a","b","b","c","c","c"]
        //        compress.compress(&chars)
        //
        //        let nearestPalindrome = FindTheClosestPalindrome()
        //        nearestPalindrome.test()
        //
        //        MeetingScheduler().test()
        return true
    }
    
    // MARK: UISceneSession Lifecycle
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
}



import Foundation

class UsersListViewModel {
    private let alertPresenter: AlertPresenter
    private let usersService: UsersListService
    var updateLoadingState: ((LoadingState) -> Void)?
    weak var delegate: UsersListViewModelDelegate?
    private let errorTitle = "Error!"
    private let errorMessage = "We were not able to fetch users list. Do you want to try again?\n(Error code: %d)"

    init(alertPresenter: AlertPresenter,
         usersService: UsersListService) {
        self.alertPresenter = alertPresenter
        self.usersService = usersService
    }
    
    func fetchUsers() {
        self.updateLoadingState?(LoadingState.loading)
        self.usersService.fetchUsers { [weak self] response in
            guard let wealSelf = self else { return }
            wealSelf.updateLoadingState?(LoadingState.normal)
            switch response {
            case .failure(let error):
                let errorMessage = String(format: wealSelf.errorMessage, error.code)
                wealSelf.alertPresenter.presentDecisionAlert(title: wealSelf.errorTitle, message: errorMessage) {
                    wealSelf.fetchUsers()
                } onNo: {
                    wealSelf.delegate?.viewModelCloseList(self!)
                }

            case .success(let users):
                let sortedUser = users.sorted { $0.name < $1.name }
                wealSelf.delegate?.viewModel(wealSelf, didFetchUsersList: sortedUser)
            }
        }
    }
}



struct User {
    let name: String
}

struct NetworkError: Error {
    public let code: Int
}

enum LoadingState {
    case loading
    case normal
}

protocol AlertPresenter {
    func presentDecisionAlert(title: String, message: String, onYes: @escaping () -> (), onNo: @escaping () -> ())
}

protocol UsersListService {
    func fetchUsers(_ completion: @escaping (Result<[User], NetworkError>) -> ())
}

protocol UsersListViewModelDelegate: class {
    func viewModel(_ viewModel: UsersListViewModel, didFetchUsersList usersList: [User])
    func viewModelCloseList(_ viewModel: UsersListViewModel)
}


class Solution {
   
    func findCircleNum(_ matrix: [[Int]]) -> Int {
        
        if matrix.count == 0 {
            return 0
        }
        
        var result = 0
        
        var visited = Array(repeating:false, count: matrix.count)
        
        for index in 0..<matrix.count {
            if(!visited[index]) {
                dfsHelper(index, &visited, matrix)
                result += 1
            }
        }
        return result
    }
    
    
    func dfsHelper(_ index:Int, _ visited:inout [Bool], _ matrix:[[Int]]) {
        visited[index] = true
        for j in 0..<matrix[0].count {
            if(index == j) {
                continue
            }
            if(!visited[j] && matrix[index][j] == 1) {
                visited[j] = true
                dfsHelper(j, &visited, matrix)
            }
        }
    }
}


class Solution {
    func myPow(_ x: Double, _ n: Int) -> Double {
        let x = n < 0 ? 1/x : x
        return powHelper(x,n)
        
    }
    
    private func powHelper(_ x: Double, _ n: Int) -> Double {
        if n == 0 {
            return 1
        }

        let result = powHelper(x, n/2)
        
        if n % 2 == 0 {
            return result * result
        }
        
        return result * result * x
    }
}

