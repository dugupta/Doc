//
//  3Sum.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation
//https://leetcode.com/problems/3sum/
struct ThreeSum {
    
    func threeSum(_ nums: [Int]) -> [[Int]] {
        let input = nums.sorted()
        
        var retValue: Set<[Int]> = []
        for (indexOne, valueOne) in nums.enumerated() {
            for (indexTwo, valueTwo) in nums.enumerated() {
                for (indexThree, valueThree) in nums.enumerated() {
                    print("valueOne + valueTwo + valueThree \(valueOne + valueTwo + valueThree)" )
                    if valueOne + valueTwo + valueThree == 0 && indexOne != indexTwo && indexOne != indexThree && indexTwo != indexThree {
                        let sorted = [valueOne, valueTwo, valueThree].sorted()
                        retValue.insert(sorted)
//                        if retValue.contains(sorted) { continue }
//                        retValue.append(sorted)
                    }
                }
            }
        }
        return Array(retValue)
    }
}
