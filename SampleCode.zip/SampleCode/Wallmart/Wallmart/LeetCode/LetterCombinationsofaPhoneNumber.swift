//
//  LetterCombinationsofaPhoneNumber.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation
// Letter Combination Phone Number
struct LetterCombinationsofaPhoneNumber {
    func mapIntToLetter(index: Int) -> String {
        let mapping = ["0", "1", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"]
        return mapping[index]
    }
    
    func letterCombinations(_ digits: String) -> [String] {
        //return letterCombinationsUsingRecurssion(digits, result: [])
        var result = [String]()
        
        for char in digits {
            let letters = mapIntToLetter(index: Int(String(char))!)
            if result.count == 0 {
                result = letters.map { String($0) }
                continue
            }
            var newResult = [String]()
            for letter in letters {
                for existStr in result {
                    newResult.append("\(existStr)\(letter)")
                }
            }
            result = newResult
        }
        return result
    }
    
    func letterCombinationsUsingRecurssion(_ digits: String, result: [String]) -> [String] {
        var result: [String] = result
        
        if digits.isEmpty { return result }
        var cacheResult: [String] = []
        let letters = mapIntToLetter(index: Int(String(digits.first!))!)
        if result.count == 0 {
            result = letters.map { String($0) }
            let newDidit = String(digits.dropFirst())
            return letterCombinationsUsingRecurssion(newDidit, result: result)
        }
        for char in letters {
            for existStr in result {
                cacheResult.append("\(existStr)\(char)")
            }
        }
        result = cacheResult
        let newDidit = String(digits.dropFirst())
        return letterCombinationsUsingRecurssion(newDidit, result: result)
    }
}
