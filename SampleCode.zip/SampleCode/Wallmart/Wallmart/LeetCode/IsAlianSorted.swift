//
//  IsAlianSorted.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/5/21.
//

import Foundation
//https://leetcode.com/problems/verifying-an-alien-dictionary/

class IsAlianSorted {
    
    func isAlienSorted(_ words: [String], _ order: String) -> Bool {
        
        var scale: [Character: Int] = [:]
        order.enumerated().forEach {
            scale[$0.element] = $0.offset
        }

        for i in 0..<words.count-1 {
            let l = words[i]
            let r = words[i+1]
            let minCount = min(l.count, r.count)
            for idx in 0..<minCount {
                if let lVal = scale[l[idx]], let rVal = scale[r[idx]] {
                    if lVal < rVal {
                        if r == words.last { return true }
                        break
                    } else if rVal < lVal {
                        return false
                    }
                }
            }
            
            if l.count > minCount { return false }
        }
        return true
    }
}

extension String {
    public subscript(index: Int) -> Character {
        let idx = self.index(self.startIndex, offsetBy: index)
        return self[idx]
    }
}

func isAlienSorted(_ words: [String], _ order: String) -> Bool {
    var dict = [Character:Int]()
    let arr = Array(order)
    for i in 0..<arr.count{
        dict[arr[i]] = i
    }
    for i in 0..<words.count-1{
        let first = words[i]
        let second = words[i+1]
        let len = min(first.count, second.count)
        var flag = 0
        for j in 0...len{
            flag = j
            if(j == len){
                break;
            }
            let a = Array(first)[j]
            let b = Array(second)[j]
            if a != b{
                if(dict[a]! > dict[b]!){
                    return false
                }else{
                    break
                }
            }
        }
        if flag == len && first.count > second.count{
            return false
        }
    }
    return true
}
