//
//  UniquePaths M*N Grid.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/unique-paths/
struct UniquePath {
    
    func uniquePaths(_ m: Int, _ n: Int) -> Int {
        var matrix: [[Int]] = []
        
        for _ in 0..<m {
            var items: [Int] = []
            for _ in 0..<n {
                items.append(0)
            }
            matrix.append(items)
        }
        
        print("matrix is \(matrix)")
        
        for row in 0..<m {
            for column in 0..<n {
                if row == 0 || column == 0 {
                    matrix[row][column] = 1
                } else {
                    matrix[row][column] = matrix[row - 1][column] + matrix[row][column - 1]
                }
            }
        }
        print("Unique paths \(matrix[m - 1][n - 1])")
        return matrix[m - 1][n - 1]
    }
}
