//
//  MergeKSortedLists.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation
// Merge K Sorted List
struct MergeKSortedList {
    func mergeTwoLists(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
        if l1 == nil {
            return l2
        } else if l2 == nil {
            return l1
        } else if (l1?.val ?? 0 < l2?.val ?? 0) {
            l1?.next = mergeTwoLists(l1?.next, l2)
            return l1
        } else {
            l2?.next = mergeTwoLists(l2?.next, l1)
            return l2
        }
    }
    
    func mergeKLists(_ lists: [ListNode?]) -> ListNode? {
        var lists = lists
        if lists.count == 0 {
            return nil
        } else if lists.count == 1 {
            return lists.first!
        } else {
            let result: ListNode? = mergeTwoLists(lists[0], lists[1])
            lists.remove(at: 0)
            lists.remove(at: 0)
            lists.insert(result, at: 0)
            return mergeKLists(lists)
        }
    }
}



// Merge K Sorted List
struct AnotherSolution {
    func mergeTwoList(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
        if l1 == nil {
            return l2
        } else if l2 == nil {
            return l1
        } else if (l1?.val ?? 0 < l2?.val ?? 0) {
            l1?.next = mergeTwoList(l1?.next, l2)
            return l1
        } else {
            l2?.next = mergeTwoList(l2?.next, l1)
            return l2
        }
    }
    
    func mergeKLists(_ lists: [ListNode?]) -> ListNode? {
	        if lists.count == 0 {
            return nil
        } else if lists.count == 1 {
            return lists.first!
        } else {
            func partition(_ list:[ListNode?], _ start:Int, _ end:Int) -> ListNode? {
                if(start == end) {
                    return list[start]
                }
                if(start < end) {
                    let middle = (start + end)/2
                    let l1 = partition(list, start,middle)
                    let l2 = partition(list, middle + 1,end)
                    return mergeTwoList(l1,l2)
                }
                return nil
            }
            
            return partition(lists, 0, lists.count - 1)
        }
    }
}


struct MergeKSortedListOptimized {
    func mergeKLists(_ lists: [ListNode?]) -> ListNode? {
        var twoDimenstionalArray: [[Int]] = []
        for node in lists {
            var objects: [Int] = []
            var nodeValue = node
            objects.append(nodeValue!.val)
            while nodeValue != nil {
                objects.append((node?.next!.val)!)
                nodeValue = node?.next
            }
            twoDimenstionalArray.append(objects)
        }
        
//        let dummyNode: ListNode()
//        for outerValue in twoDimenstionalArray {
//            for innerValue in outerValue {
//                
//            }
//        }
        return nil
    }
}
