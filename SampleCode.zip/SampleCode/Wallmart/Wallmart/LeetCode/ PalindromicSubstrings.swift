//
//   PalindromicSubstrings.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//
//https://leetcode.com/problems/palindromic-substrings/
//"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
import Foundation

extension String {

    var length: Int {
        return count
    }

    subscript (i: Int) -> String {
        return self[i ..< i + 1]
    }

    func substring(fromIndex: Int) -> String {
        return self[min(fromIndex, length) ..< length]
    }

    func substring(toIndex: Int) -> String {
        return self[0 ..< max(0, toIndex)]
    }

    subscript (r: Range<Int>) -> String {
        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
                                            upper: min(length, max(0, r.upperBound))))
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
        return String(self[start ..< end])
    }
}

public extension String {
    var isPalindrome: Bool {
        return self == String(self.reversed())
    }
    
    func palindrome() -> Bool {
        return self == String(self.reversed())
    }
}

struct PalindromicSubstrings {
    func allSubString(_ string: String = "babad") -> [String] {
        var array: [String] = []
        func all(_ string: String = "babad") {
            var tempString = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                tempString += String(char)
                array.append(tempString)
            }
            all(String(string.dropFirst()))
        }
        all(string)
        return array
        
        /*
         var array: [String] = []
         
         var start = 0
         while start < string.count {
             print("Outer loop iteration ", start)
             var end = start + 1
             var newString: String = String(string[string.index(string.startIndex, offsetBy: start)])
             array.append(newString)
             while end < string.count {
                 newString = newString + String(string[string.index(string.startIndex, offsetBy: end)])
                 array.append(newString)
                 end += 1
             }
             start += 1
         }

         */
    }
    
    func countSubstrings(_ s: String) -> Int {
        let subStrings = allSubString(s)
        var retValue: Int = 0
        for checkTsring in subStrings {
            if checkTsring.isPalindrome {
                retValue += 1
            }
        }
        return retValue
    }
}


extension PalindromicSubstrings {
    func stringArray(_ string: String) -> [String] {
        var array: [String] = []
        func all(_ string: String = "babad") {
            var tempString = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                tempString += String(char)
                array.append(tempString)
            }
            all(String(string.dropFirst()))
        }
        all(string)
        return array
    }
}


struct OptimizedPelidromeStrings {
    func countSubstrings(_ s: String) -> Int {
        var result = 0
        var start = 0
        while start < s.count {
            var end = start
            while end < s.count {
                result += isPalindrome(s, start: start, end: end) ? 1 : 0
                end += 1
            }
            start += 1
        }
        return result
    }
}

func isPalindrome(_ palindrome: String, start: Int, end: Int) -> Bool {
    var newStart = start
    var newEnd = end
    while newStart < newEnd {
        if palindrome[palindrome.index(palindrome.startIndex, offsetBy: newStart)] != palindrome[palindrome.index(palindrome.startIndex, offsetBy: newEnd)] {
            return false
        }
        newStart = newStart + 1
        newEnd = newEnd - 1
    }
    return true
}


func allSubStringWithWhileLoop(_ string: String) -> [String] {
    "".subStrings()
    var array: [String] = []
    var start = 0
    while start <= string.count {
        var end = start + 1
        var newString: String = String(string[string.index(string.startIndex, offsetBy: start)])
        array.append(newString)
        while end < string.count {
            newString = newString + String(string[string.index(string.startIndex, offsetBy: end)])
            array.append(newString)
            end += 1
        }
        start += 1
    }
    
   /*
    func all(_ string: String = "babad") {
        var tempString = ""
        if string.count == 1 {
            array.append(string)
            return
        }
        for char in string {
            tempString += String(char)
            array.append(tempString)
        }
        all(String(string.dropFirst()))
    }
    all(string)
 */
    return array
}

//All Substring || AllSubstrings
//https://www.youtube.com/watch?v=TC065bIoVds&ab_channel=VivekTechWaves
extension String {
    // This is a working solution
    // "abcd"
    //["a", "ab", "abc", "abcd", "b", "bc", "bcd", "c", "cd", "d"]
    
    func subStrings() -> [String] {
        var result: [String] = []
        let arrayString = Array(self)
        let length = arrayString.count
        for outerIndex in 0..<length {
            for innerIndex in outerIndex..<length {
                let string = String(arrayString[outerIndex...innerIndex])
                result.append(string)
            }
        }
        return result
    }
}

