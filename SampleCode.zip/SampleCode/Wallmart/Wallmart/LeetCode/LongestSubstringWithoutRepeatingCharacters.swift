//
//  LongestSubstringWithoutRepeatingCharacters.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation
//https://leetcode.com/problems/longest-substring-without-repeating-characters/

/*
 
 Input: s = "abcabcbb"
 Output: 3
 Explanation: The answer is "abc", with the length of 3.
 Example 2:

 Input: s = "bbbbb"
 Output: 1
 Explanation: The answer is "b", with the length of 1.
 Example 3:

 Input: s = "pwwkew"
 Output: 3
 Explanation: The answer is "wke", with the length of 3.
 Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
 Example 4:

 Input: s = ""
 Output: 0
 
 */

/*
extension String {
    var isUnique: Bool {
        let set: NSMutableSet = NSMutableSet()
        for char in self {
            set.add(char)
        }
        return set.count == self.count
    }
}
struct LongestSubstringWithoutRepeatingCharacters {
    
    func allSubString(_ string: String = "babad") -> [String] {
        var array: [String] = []
        func all(_ string: String = "babad") {
            var tempString = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                tempString += String(char)
                array.append(tempString)
            }
            all(String(string.dropFirst()))
        }
        all(string)
        return array
    }
   
    
    func lengthOfLongestSubstring(_ s: String) -> Int {
        if s.count == 0 || s.count == 1 { return s.count }
        let all = allSubString(s)
        var longest = ""
        for string in all {
            if string.isUnique {
                if string.count > longest.count {
                    longest = string
                }
            }
        }
        return longest.count
    }
}
*/

struct LongestSubstringWithoutRepeatingCharacters {
    func lengthOfLongestSubstringWithArray(_ s: String = "abcabcbb") -> Int {
        let arrayString = Array(s)
        var longest: [Character] = []
        var result: [Character] = []
        for char in arrayString {
            if result.contains(char) {
                if result.count >= longest.count {
                    longest = result
                }
                if let index = result.firstIndex(of: char) {
                    result = Array(result[(index + 1)...])
                }
                
                result.append(char)
                
            } else {
                result.append(char)
            }
        }
        return max(longest.count, result.count)
    }
    
    func lengthOfLongestSubstring(_ s: String) -> Int {
        var longest = ""
        var subString = ""
        for (index, value) in s.enumerated() {
            if subString.contains(value) {
                if subString.length >= longest.length {
                    longest = subString
                }
                subString = String(subString[subString.index(after: subString.firstIndex(of: value)!)...])
                subString.append(value)
                
            } else {
                subString.append(value)
            }
        }
        
        return max(subString.count, longest.count)
    }
    
    func lengthOfLongestSubstringWithDict(_ s: String = "abcabcbb") -> Int {
            var longest = 0, startIndex = 0
            var charMap: [Character: Int] = [:]

            for (index, char) in s.enumerated() {
                if let foundIndex = charMap[char] {
                    startIndex = max(foundIndex+1, startIndex)
                }
                longest = max(longest, index - startIndex + 1)
                charMap[char] = index
            }
            return longest
        
    }
    
    func lengthOfLongestSubstringOptimized(_ s: String) -> Int {
        var longest = ""
        var result = ""
        for char in s {
            if result.contains(char) {
                if result.count > longest.count {
                    longest = result
                    result = ""
                }
            } else {
                result.append(char)
            }
        }
        
        return max(longest.count, result.count)
        
        /*
        let charString = Array(s)
        var longest = ""
        var subString = ""
        for (index, value) in s.enumerated() {
            if subString.contains(value) {
                if subString.length >= longest.length {
                    longest = subString
                }
                subString = String(charString[index...]) //String(subString[subString.index(after: subString.firstIndex(of: value)!)...])
                subString.append(value)
                for innerChar in subString {
                    if innerChar == value {
                        subString = String(subString.dropFirst())
                        subString.append(value)
                        break
                    } else {
                        subString = String(subString.dropFirst())
                    }
                }
            } else {
                subString.append(value)
            }
        }
        
        return max(subString.count, longest.count)
 */
    }
}

/*
public class Node {
    public var val: Int
    public var left: Node?
    public var right: Node?
    public var parent: Node?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
        self.parent = nil
    }
}

class Solution {
    
    func lowestCommonAncestor(_ p: Node?,_ q: Node?) -> Node? {
        var array: [Int: Node] = [:]
        var counter = 1
        var retValue: Node? = nil
        p?.traverse {
            print("Priniting for p \($0?.val)")
            if let node = $0 {
                 array[node.val] =  node
            }
        }
        
        var current = q
        while let value = current {
            if array[value.val] != nil {
                return value
            } else {
                current = current?.parent
            }
        }
        
        print("Let resturn something")
        return retValue
    }
}

extension Node {
    func traverse(visit: (Node?) -> Void) {
        visit(self)
        parent?.traverse(visit: visit)
    }
}
*/
