//
//   ContainerWithMostWater.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation

struct ContainerWithMostWater {
    
    func maxArea(_ height: [Int] = [1,8,6,2,5,4,8,3,7]) -> Int {
        let height = [1,8,6,2,5,4,8,3,7]
        var highest: Int = 0
        for (outerIndex, outerValue) in height.enumerated() {
            for (innerIndex, innerValue) in height.enumerated() {
                let minValue = min(outerValue, innerValue)
                let volume = (innerIndex - outerIndex) * minValue
                print("volume\(volume)")
                if volume > highest {
                    highest = volume
                }
            }
        }
        return highest
    }
    
    func maxAreaOptimized(_ height: [Int] = [1,8,6,2,5,4,8,3,7]) -> Int {
        var start = 0
        var end = height.count - 1
        var maximumWater  = 0
        
        while start < end {
            let minumumHeight = min(height[start], height[end])
            if minumumHeight * (end - start) > maximumWater {
                maximumWater = minumumHeight * (end - start)
            }
            if height[start] < height[end] {
                start = start + 1
            } else {
                end = end - 1
            }
        }
        return maximumWater
    }
}
