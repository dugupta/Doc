//
//  FindTheSmallestDivisorGivenThreshold.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import Foundation

struct FindTheSmallestDivisorGivenThreshold {
    func smallestDivisor(_ nums: [Int], _ threshold: Int) -> Int {
        if nums.isEmpty { return 0 }
        var minimum = nums.max()!
        for value in 1...nums.max()! {
            var result = 0
            for (index, innerValue) in nums.enumerated() {
                result = result + divide(innerValue, divider: value)
                if result > threshold {
                    break
                } else {
                    if index == nums.count - 1 {
                        minimum = min(minimum, value)
                    }
                }
            }
        }
        return minimum
    }
    
    func divide(_ divide: Int, divider: Int) -> Int {
        //return Int(ceil(Double(divide)/Double(divider)))
        var value = divide / divider
        if divide % divider != 0 {
            value = value + 1
        }
        return value
    }
    
    func smallestDivisorOptimized(_ nums: [Int], _ threshold: Int) -> Int {
        
        // Determine maximum and minimum threshold
        var left = 1
        var right = nums.max()!
        
        // Use doubles instead of ints
        let nums = nums.map { Double($0) }
        let threshold = Double(threshold)
        
        // Binary Search
        while left < right {
            let mid = left + (right - left) / 2
            let result = nums.reduce(0.0) {
                $0 + ceil($1 / Double(mid))
            }
            
            if result <= threshold {
                right = mid
            } else {
                left = mid + 1
            }
        }
        
        return Int(left)
    }
}


