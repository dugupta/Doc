//
//  SparseMatrixMultiplication.swift
//  Wallmart
//
//  Created by Durgesh Lal on 1/12/21.
//

import Foundation

struct SparseMatrixMultiplication {
    func multiply(_ A: [[Int]], _ B: [[Int]]) -> [[Int]] {
        // B.rows.count must equal A.cols.count
        
        // preallocate a 2D array of size [A rows][B cols]
        var AB: [[Int]] = [[Int]](repeating: [Int](repeating: 0, count:B[0].count), count: A.count)
        /*
         for value in A {
         var innerArray : [Int] = []
         for innerValue in B[0] {
         innerArray.append(0)
         }
         AB.append(innerArray)
         }
         */
        // iterate through A in row / col order
        for arow in 0..<A.count {
            for acol in 0..<A[0].count {
                // if we have a zero, AB preset will not change
                if A[arow][acol] != 0 {
                    // B.rows == A.cols, so just iterate B.cols
                    for bcol in 0..<B[0].count {
                        // invert B' using acol for B.row
                        AB[arow][bcol] += A[arow][acol] * B[acol][bcol]
                    }
                }
            }
        }
        
        return AB
    }
}
