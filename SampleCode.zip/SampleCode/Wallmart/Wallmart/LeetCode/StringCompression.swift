//
//  StringCompression.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import Foundation
//https://leetcode.com/problems/string-compression/
struct StringCompression {
    //Input: chars = ["a","a","a","b","b","a","a"]
    //"a","a","b","b","c","c","c"
    func compress(_ chars: inout [Character]) -> Int {
        
        /*
        if chars.isEmpty || chars.count == 1 {
            return chars.count
        }
        var cache: [Character] = []
        var counter = 1
        for index in chars.indices {
            if index == chars.count - 1 {
                cache.append(chars[index])
                if counter > 1 {
                    cache = cache + Array("\(counter)")
                }
            } else {
                if chars[index] == chars[index + 1] {
                    counter = counter + 1
                } else {
                    cache.append(chars[index])
                    if counter > 1 {
                        cache = cache + Array("\(counter)")
                    }
                    counter = 1
                }
            }
        }
        chars = cache
        return cache.count
 */
        
        //Input: chars = ["a","a","a","b","b","a","a"]
        //"a","a","b","b","c","c","c"
        
        if chars.isEmpty || chars.count == 1 {
            return chars.count
        }
        
        var unique: [Character] = [chars.first!]
        var counter = 0
        for index in chars.indices {
            if index == 0 || unique.last == chars[index] {
                counter += 1
                if index == chars.count - 1 {
                    if counter > 1 {
                        unique.append(contentsOf: "\(counter)")
                    }
                    print("Last")
                }
                continue
            } else {
                if counter > 1 {
                    unique.append(contentsOf: "\(counter)")
                }
                unique.append(chars[index])
                counter = 1
            }
        }
        
        chars = unique
        return unique.count
    }
}
