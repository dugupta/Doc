//
//  Search2DMatrix.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation
//https://leetcode.com/problems/search-a-2d-matrix-ii/
struct SearchTwoDMatrix {
    func searchMatrix(_ matrix: [[Int]], _ target: Int) -> Bool {
        
        func found(_ start: Int, end: Int, array: [Int], target: Int) -> Bool {
            if start > end { return false }
            var start = start
            var end = end
            let mid = Int(floor(Double(start + end) / 2.0))
            if array[mid] == target { return true }
            else {
                if target > array[mid] {
                    start = mid + 1
                } else {
                    end = mid - 1
                }
            }
            return found(start, end: end, array: array, target: target)
        }
        
        for outerArray in matrix {
            print("outerArray is \(outerArray)")
            if found(0, end: outerArray.count - 1, array: outerArray, target: target) { return true }
            else {
                continue
            }
//            var start = 0
//            var end = outerArray.count - 1
//            while start <= end {
//                let mid = Int(floor(Double(start + end) / 2.0))
//                if outerArray[mid] == target {
//                    return true
//                }
//
//                if outerArray[mid] > target {
//                    end = mid - 1
//                } else {
//                    start = mid + 1
//                }
//            }
        }
        return false
        /*
        for outerArray in matrix {
            for object in outerArray {
                if object == target { return true }
            }
        }
        return false
 */
     /*
        for outerArray in matrix {
            //Binary Search
            var left = 0
            var right = outerArray.count - 1
            while left <= right {
                let mid = Int(floor(Double(right + left) / 2.0))
                if outerArray[mid] == target {
                    return true
                }
                if outerArray[mid] > target {
                    right = mid - 1
                } else {
                    left = mid + 1
                }
            }
        }
        return false
 */
        /*
        var row = matrix.count - 1
        var column = 0
        
        while row >= 0 && column <= matrix[0].count {
            if matrix[row][column] == target { return true }
            else {
                if matrix[row][column] > target {
                    row -= 1
                } else {
                    column += 1
                }
            }
        }
        return false
 */
    }
}

