//
//  VerifyingAnAlienDictionary.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation

struct VerifyingAnAlienDictionary {
    func isAlienSorted(_ words: [String], _ order: String) -> Bool {
        var map:[Character : Int] = [:]
        let arr = Array(order)
        for i in 0..<order.count{
            map[arr[i]] = i
        }
        var retValue = true
        for (w1, w2) in zip(words, words.dropFirst()) {
            
            for index in 0..<min(w1.count, w2.count) {
                if w1[w1.index(w1.startIndex, offsetBy: index)] == w2[w2.index(w2.startIndex, offsetBy: index)] {
                    continue
                } else {
                    let first = map[w1[w1.index(w1.startIndex, offsetBy: index)]]
                    let second = map[w2[w2.index(w2.startIndex, offsetBy: index)]]
                    retValue = first! < second!
                }
            }
            if (w1.count > w2.count) { retValue = false }
        }
        return retValue
    }
    
    func isAlienSortedCharacter(_ words: [String], _ order: String) -> Bool {
        let newWords = words.map({ Array($0) })
        var map:[Character : Int] = [:]
        let arr = Array(order)
        for i in 0..<order.count{
            map[arr[i]] = i
        }
        var retValue = true
        for (w1, w2) in zip(newWords, newWords.dropFirst()) {
            
            for index in 0..<min(w1.count, w2.count) {
                if w1[index] == w2[index] {
                    continue
                } else {
                    let first = map[w1[index]]
                    let second = map[w2[index]]
                    retValue = first! < second!
                    break
                }
            }
            if (w1.count > w2.count) { retValue = false }
        }
        return retValue
    }
}
