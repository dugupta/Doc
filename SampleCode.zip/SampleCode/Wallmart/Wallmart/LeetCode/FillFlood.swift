//
//  FillFlood.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation
//https://leetcode.com/problems/flood-fill/
struct FillFlood {
    
    struct Index: ExpressibleByArrayLiteral {
        let row: Int
        let column: Int
        
        init(arrayLiteral elements: Int...) {
            self.row = elements.first ?? 0
            self.column = elements.last ?? 0
        }
    }
    
    func floodFillIteration(_ image: [[Int]], _ startRow: Int, _ startColumn: Int, _ newColor: Int) -> [[Int]] {
        var retValue = image
        let currentColor = image[startRow][startColumn]
        if currentColor == newColor { return image }
        let neighbours = validNeighbours(image, startRow: startRow, startColumn: startColumn, color: currentColor, newColor: newColor)
       
        return dfs(image, startRow: startRow, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
    }
    
    private func validNeighbours(_ image: [[Int]], startRow: Int, startColumn: Int, color: Int, newColor: Int) -> [Index] {
        var retValue: [Index] = []
        if image[startRow][startColumn] == color {
            //retValue[startRow][startColumn] = newColor
            
            if startRow >= 1 {
                retValue.append(Index(arrayLiteral: startRow - 1, startColumn))
            }
            
            if startColumn >= 1 {
                retValue.append(Index(arrayLiteral: startRow, startColumn - 1))
            }
            
            if startRow + 1 < image.count {
                retValue.append(Index(arrayLiteral: startRow + 1, startColumn))
            }
            
            if let count = image.first?.count {
                if startColumn + 1 < count {
                    retValue.append(Index(arrayLiteral: startRow, startColumn + 1))
                }
            }
        }
        return retValue
    }
 
    //[[1,1,1],[1,1,0],[1,0,1]]
    //startRow = 1, startColumn = 1, newColor = 2
    //Output: [[2,2,2],[2,2,0],[2,0,1]]
    func floodFill(_ image: [[Int]], _ startRow: Int, _ startColumn: Int, _ newColor: Int) -> [[Int]] {
        let currentColor = image[startRow][startColumn]
        if currentColor == newColor { return image }
        return dfs(image, startRow: startRow, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
    }
    
    private func dfs(_ image: [[Int]], startRow: Int, startColumn: Int, currentColor: Int, newColor: Int) -> [[Int]] {
        var retValue = image
        if retValue[startRow][startColumn] == currentColor {
            retValue[startRow][startColumn] = newColor
            
            if startRow >= 1 {
                retValue = dfs(retValue, startRow: startRow - 1, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
            }
            
            if startColumn >= 1 {
                retValue = dfs(retValue, startRow: startRow, startColumn: startColumn - 1, currentColor: currentColor, newColor: newColor)
            }
            
            if startRow + 1 < image.count {
                retValue = dfs(retValue, startRow: startRow + 1, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
            }
            
            if let count = image.first?.count {
                if startColumn + 1 < count {
                    retValue = dfs(retValue, startRow: startRow, startColumn: startColumn + 1, currentColor: currentColor, newColor: newColor)
                }
            }
        }
        return retValue
    }
}


struct NewFunction {
    func floodFill(_ image: [[Int]], _ startRow: Int, _ startColumn: Int, _ newColor: Int) -> [[Int]] {
        let currentColor = image[startRow][startColumn]
        if currentColor == newColor { return image }
        return fill(image, startRow: startRow, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
    }
    
    private func fill(_ image: [[Int]], startRow: Int, startColumn: Int, currentColor: Int, newColor: Int) -> [[Int]] {
        var retValue = image
        /*
        let rows = grid.count
        let column = grid.first?.count ?? 0
        if indexOne < 0 || indexTwo < 0 || indexOne >= rows || indexTwo >= column || grid[indexOne][indexTwo] == "0" {
            return 0
        }
        
        */
        if startRow < 0 || startColumn < 0 || startRow >= retValue.count  || startColumn >= retValue[0].count || retValue[startRow][startColumn] != currentColor {
            return retValue
        }
        
        retValue[startRow][startColumn] = newColor
        
        retValue = fill(retValue, startRow: startRow - 1, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
        retValue = fill(retValue, startRow: startRow + 1, startColumn: startColumn, currentColor: currentColor, newColor: newColor)
        retValue = fill(retValue, startRow: startRow, startColumn: startColumn - 1, currentColor: currentColor, newColor: newColor)
        retValue = fill(retValue, startRow: startRow, startColumn: startColumn + 1, currentColor: currentColor, newColor: newColor)
       
        return retValue
    }
}
