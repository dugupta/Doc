//
//  HouseRobber.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/house-robber/
struct HouseRobber {
    //Input: nums = [1,2,3,1]
    
    func rob(_ nums: [Int]) -> Int {
        print("nums: \(nums)")
        var prevMax = 0
        var currentMax = 0
        for value in nums {
            print("Value: \(value)")
            let temp = currentMax
            print("temp: \(temp)")
            currentMax = max(prevMax + value, currentMax)
            print("currentMax: \(currentMax)")
            prevMax = temp
            print("prevMax: \(prevMax)")
        }
        return currentMax
    }
}


class Solution {
    func rob(_ nums: [Int]) -> Int {
        var nums = nums
        if nums.count <= 2 {
            return nums.max() ?? 0
        }
        nums[2] += nums[0]
        
        for i in 3..<nums.count {
            nums[i] += max(nums[i - 2], nums[i - 3])
        }
        return nums.max() ?? 0
    }
}


