//
//  AddTwoNumbers.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation
//https://leetcode.com/problems/add-two-numbers/

public class ListNode {
    var val: Int
    var next: ListNode?
    init() {
        self.val = 0
        self.next = nil
    }
    
    init(_ val: Int) {
        self.val = val
        self.next = nil
    }
    init(_ val: Int, _ next: ListNode?) {
        self.val = val
        self.next = next
    }
}


struct AddTwoumbers {
    func addTwoNumbers(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
        var p = l1
        var q = l2
        let dummyHead: ListNode = ListNode(0)
        var current = dummyHead
        var carry: Int = 0
        while p != nil || q != nil {
            let x: Int = p?.val ?? 0
            let y: Int = q?.val ?? 0
            let sum: Int = carry + x + y
            carry = sum / 10
            current.next = ListNode(sum % 10)
            if let next = current.next {
                current = next
            }
            if (p != nil) { p = p?.next }
            if (q != nil) { q = q?.next }
        }
        if (carry > 0) {
            current.next = ListNode(carry)
        }
        return dummyHead.next
    }
}


/*
 public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
     ListNode dummyHead = new ListNode(0);
     ListNode p = l1, q = l2, curr = dummyHead;
     int carry = 0;
     while (p != null || q != null) {
         int x = (p != null) ? p.val : 0;
         int y = (q != null) ? q.val : 0;
         int sum = carry + x + y;
         carry = sum / 10;
         curr.next = new ListNode(sum % 10);
         curr = curr.next;
         if (p != null) p = p.next;
         if (q != null) q = q.next;
     }
     if (carry > 0) {
         curr.next = new ListNode(carry);
     }
     return dummyHead.next;
 }
 */

