//
//  FindTheClosestPalindrome.swift
//  Wallmart
//
//  Created by Durgesh Lal on 1/12/21.
//

import Foundation

//https://leetcode.com/problems/find-the-closest-palindrome/

class FindTheClosestPalindrome {
    /*
     func isPalindrome(_ palindrome: String, start: Int, end: Int) -> Bool {
     var newStart = start
     var newEnd = end
     while newStart < newEnd {
     if palindrome[palindrome.index(palindrome.startIndex, offsetBy: newStart)] != palindrome[palindrome.index(palindrome.startIndex, offsetBy: newEnd)] {
     return false
     }
     newStart = newStart + 1
     newEnd = newEnd - 1
     }
     return true
     }
     */
    func nearestPalindromic(_ n: String) -> String {
        guard let number = Int(n) else { return "" }
        let lowerDifference = number - lower(n)
        let upperDifference = upper(n) - number
        
        if n.count == 1 { return "\(number - 1)"}
        
        if lowerDifference == upperDifference {
            return "\(lower(n))"
        }
        
        if lowerDifference < upperDifference {
            return "\(lower(n))"
        } else {
            return "\(upper(n))"
        }
    }
    
    func lower(_ number: String) -> Int {
        guard var integerNumber = Int(number) else { return 0 }
        if "\(integerNumber)".isPalindrome {
            integerNumber -= 1
        }
        while ("\(integerNumber)".isPalindrome) == false {
            integerNumber -= 1
        }
        return integerNumber
    }
    
    func upper(_ number: String) -> Int {
        guard var integerNumber = Int(number) else { return 0 }
        if "\(integerNumber)".isPalindrome {
            integerNumber += 1
        }
        while ("\(integerNumber)".isPalindrome) == false {
            integerNumber += 1
        }
        return integerNumber
    }
    
    func test() {
        let object = FindTheClosestPalindrome()
        object.nearestPalindromic("1213")
    }
}
