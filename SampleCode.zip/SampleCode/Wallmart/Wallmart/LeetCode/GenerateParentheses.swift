//
//  GenerateParentheses.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation
//https://leetcode.com/problems/generate-parentheses/
struct GenerateParentheses {
    func helper(arr: inout [String], str: String, n: Int, m: Int) {
        if m == 0 && n == 0 {
            arr.append(str)
            return
        }
        if m > 0 {
            helper(arr: &arr, str: str + ")", n: n, m: m-1)
        }
        if n > 0 {
            helper(arr: &arr, str: str + "(", n: n-1, m: m+1)
        }
    }
    
    func generateParenthesis(_ n: Int = 3) -> [String] {
        var arr: [String] = []
        helper(arr: &arr, str: "", n: n, m: 0)
        return arr
    }
    
    func generateParenthesisUsingBackTrack(_ n: Int = 3) -> [String] {
            var arr: [String] = []
            backTrack(&arr, "", 0, 0, n)
            return arr
        }
        
        func backTrack(_ ansArray: inout [String], _ currentString: String, _ open: Int, _ close: Int, _ max: Int) {
            if currentString.count == max * 2 {
                ansArray.append(currentString)
                return
            }
            
            if open < max {
                backTrack(&ansArray, currentString + "(", open + 1, close, max)
            }
            
            if close < open {
                backTrack(&ansArray, currentString + ")", open, close + 1, max)
            }
        }
    
    /*
    // Not working
    func allSubString(_ string: String) -> [String] {
        var array: [String] = []
        func all(_ string: String) {
            var tempString = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                tempString += String(char)
                array.append(tempString)
            }
            all(String(string.dropFirst()))
        }
        all(string)
        return array
    }
    
    func isValidParenthesis(_ string: String) -> Bool {
        
        let parString = string
        var stack: [Character] = []
        for char in parString {
            if char == "(" {
                stack.append(char)
            } else {
                if !stack.isEmpty { stack.removeLast() }
            }
        }
        return stack.isEmpty
    }
    
    
    func generateParenthesesBruteForce(_ n: Int) -> [String] {
        var arr: [String] = []
        var string: String = ""
        for _ in 1...n {
            string = string + "()"
        }
        
        let array = allSubString(string)
        for item in array {
            if isValidParenthesis(item) {
                arr.append(item)
            }
        }
        return arr
    }
    */
}
