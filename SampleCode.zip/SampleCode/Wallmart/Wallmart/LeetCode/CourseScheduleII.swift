//
//  CourseScheduleII.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import Foundation
//https://leetcode.com/problems/course-schedule-ii/
struct CourseScheduleII {
    func findOrder(_ numCourses: Int, _ prerequisites: [[Int]]) -> [Int] {
        return [1]
    }
}
