//
//  SearchInRotatedSortedArray.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/search-in-rotated-sorted-array/solution/
struct SearchInRotatedSortedArray {
    func search(_ nums: [Int], _ target: Int) -> Int {
        //return nums.firstIndex(of: target) ?? -1
        //[4,5,6,7,0,1,2]
        var left = 0
        var right = nums.count - 1;
        while (left < right) {
            let mid =  Int(floor(Double(left + right) / 2.0))
            if (nums[mid] == target) { return mid }
            if nums[mid] > nums[right] {
                left = mid + 1
            } else {
                right = mid
            }
        }
        
        let start = left
        left = 0
        right = nums.count - 1
        
        if target >= nums[start] && target <= nums[right] {
            //Serach right side
            left = start
            right = nums.count - 1
        } else {
            //Search left sied
            left = 0
            right = start
        }
       
        // Binary search
        while left <= right  {
            let mid = Int(floor(Double(left + right) / 2.0))
            if nums[mid] == target { return mid }
            if nums[mid] > target {
                right = mid - 1
            } else {
                left = mid + 1
            }
        }
        
        return -1;
    }
}
//Binary search is different than above
extension SearchInRotatedSortedArray {
    
    func binarySearch(in numbers: [Int], for value: Int) -> Int? {
        var left = 0
        var right = numbers.count - 1

        while left <= right {
            let middle =  Int(floor(Double(left + right) / 2.0))

            if numbers[middle] < value {
                left = middle + 1
            } else if numbers[middle] > value {
                right = middle - 1
            } else {
                return middle
            }
        }

        return nil
    }
}
