//
//  ReverseLinkedList.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation

struct ReverseLinkedList {
    
    func reverseList(_ head: ListNode?) -> ListNode? {
        var head = head
        var stack: [Int] = []
        guard let value = head?.val else { return nil }
        stack.append(value)
        while head != nil {
            if let value = head?.next?.val {
                stack.append(value)
            }
            head = head?.next
        }
        //Create a linkedList
        if stack.count == 0 { return nil }
        let newHead: ListNode? = ListNode(stack.last!)
        var dummyHead = newHead
        for (index, object) in stack.reversed().enumerated() {
            if index == 0 { continue }
            let newNode = ListNode(object)
            dummyHead?.next = newNode
            dummyHead = dummyHead?.next
        }
        return newHead
    }
}
