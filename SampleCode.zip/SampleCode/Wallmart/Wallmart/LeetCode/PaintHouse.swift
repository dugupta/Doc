//
//  PaintHouse.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import Foundation
//https://leetcode.com/problems/paint-house/submissions/
struct PaintHouse {
    func minCost(_ costs: [[Int]]) -> Int {
        if costs.isEmpty == true{
            return 0
        }
        var lastR = costs[0][0]
        var lastB = costs[0][1]
        var lastG = costs[0][2]
        
        for i in 1..<costs.count{
            let curR = min(lastB, lastG) + costs[i][0]
            let curB = min(lastR, lastG) + costs[i][1]
            let curG = min(lastB, lastR) + costs[i][2]
            
            lastR = curR
            lastB = curB
            lastG = curG
        }
        
        return min(min(lastR, lastB),lastG)
    }
    
    /*
     for painting each house we have three colors to choose from. Since two hoses next to each other have to be in different color, we can optimize paint cost for just two houses by assuming the second is red, take the min cost of first house painted as green or blue. Same for assuming the second one being green and blue.

     when we successfully calc the cost for first two, we can add a third one and take the same steps, and so on.


     */
    func minCostTwo(_ costs: [[Int]]) -> Int {
        var prevOpt = [0, 0, 0]
        for cost in costs {
            var currentOpt = [0, 0, 0]
            for color in 0..<3 {
                currentOpt[color] = min(prevOpt[(color + 1)%3], prevOpt[(color + 2)%3]) + cost[color]
            }
            prevOpt = currentOpt
        }
        return prevOpt.min()!
    }
    
    func minCostThree(_ costs: [[Int]]) -> Int {
        var dp = [0,0,0]
        
        for i in 0..<costs.count {
            var t = [0,0,0]
            t[0] = costs[i][0] + min(dp[1],dp[2])
            t[1] = costs[i][1] + min(dp[0],dp[2])
            t[2] = costs[i][2] + min(dp[1],dp[0])
            
            dp[0] = t[0];
            dp[1] = t[1];
            dp[2] = t[2];
        }
        
        return dp.min()!
    }
    
    func minimumCost(_ costs: [[Int]]) -> Int {
        guard costs.first != nil else {
            return 0
        }
        let initial = [0, 0, 0]
        let summation = costs.reduce(initial) { (accumulator, element)  in
            let redCost = element[0] + min(accumulator[1], accumulator[2])
            let greenCost = element[1] + min(accumulator[0], accumulator[2])
            let blueCost = element[2] + min(accumulator[0], accumulator[1])
            return [redCost, greenCost, blueCost]
        }
        return summation.sorted { $0 < $1 }.first ?? 0
    }
}
