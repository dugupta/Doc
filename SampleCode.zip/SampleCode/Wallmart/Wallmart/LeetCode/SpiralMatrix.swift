//
//  SpiralMatrix.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation
/*
struct SpiralMatrix {
    func spiralOrder(_ matrix: [[Int]]) -> [Int] {
        var result: [Int] = []
        travel(matrix, result: &result)
        return result
    }
    
    func travel(_ matrix: [[Int]], result: inout [Int]) {
        if matrix.count == 0 {
            return
        }
        var cache = matrix
        var linear: [Int] = []
        for (index, value) in matrix.enumerated() {
            if index == 0 {
                result = result + value
                cache.remove(at: 0)
            } else if index == matrix.count - 1 {
                result = result + value.reversed()
                cache.removeLast()
            } else {
                guard let firstIndex = cache.firstIndex(of: value) else {
                    continue
                }
                if let last = value.last {
                    result.append(last)
                    cache[firstIndex].removeLast()
                }
                if value.count == 1 { continue }
                if let first = value.first {
                    linear.insert(first, at: 0)
                    cache[firstIndex].removeFirst()
                }
            }
        }
        result = result + linear
        travel(cache, result: &result)
    }
}
*/

struct SpiralMatrix {
    func spiralOrder(_ matrix: [[Int]]) -> [Int] {
        var result: [Int] = []
        travel(matrix, result: &result)
        print("Result is \(result)")
        return result
    }
    
    func travel(_ matrix: [[Int]], result: inout [Int]) {
        if matrix.count == 0 {
            return
        }
        var cache = matrix
        var linear: [Int] = []
        
        linear = linear + cache.first!
        cache.remove(at: 0)
        var rightArray: [Int] = []
        var leftArray: [Int] = []
        var bottom: [Int] = []
        if let last = cache.last {
            bottom = last
            cache.remove(at: cache.count - 1)
        }
        if cache.count == 1 && cache[0].count == 1 {
            linear.append(cache[0][0])
            linear.append(contentsOf: bottom)
            cache.remove(at: 0)
            travel(cache, result: &result)
        }
        
        for (index, rest) in cache.enumerated() {
            if let frist = rest.first {
                leftArray.append(frist)
                cache[index].remove(at: 0)
            }
            if let last = cache[index].last {
                rightArray.append(last)
                cache[index].remove(at: cache[index].count - 1)
            }
        }
        
        linear = linear + rightArray
        linear = linear + bottom.reversed()
        linear = linear + leftArray
        
        //travel(cache, result: &linear)
        
        result = result + linear
        travel(cache, result: &result)
    }
}
