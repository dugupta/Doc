//
//  KthLargestElement.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation

struct KthLargestElement {
    func findKthLargest(_ nums: [Int], _ k: Int) -> Int {
        let sorted = nums.sorted(by: { $0 > $1 })
        if sorted.count >= k {
            return sorted[k - 1]
        }
        return 0
    }
    
   
}

class ShortestDistance {
    func shortestDistance(_ wordsDict: [String], _ word1: String, _ word2: String) -> Int  {
        var firstIndex = wordsDict.lastIndex(of: word1)
        var lastIndex = wordsDict.firstIndex(of: word2)
        var difference = max(firstIndex!, lastIndex!) - min(firstIndex!, lastIndex!)
        
        firstIndex = wordsDict.lastIndex(of: word2)
        lastIndex = wordsDict.firstIndex(of: word1)
        
        let new = max(firstIndex!, lastIndex!) - min(firstIndex!, lastIndex!)
        
        return min(difference, new)
    }
}
