//
//  BestTimeBuySellStock.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/best-time-to-buy-and-sell-stock/
//[7,1,5,3,6,4]
struct BestTimeBuySellStock {
    func maxProfit(_ prices: [Int]) -> Int {
        var profit = 0
        for buyIndex in 0..<prices.count {
            for sellIndex in buyIndex+1..<prices.count {
                if prices[sellIndex] - prices[buyIndex] > profit {
                    profit = prices[sellIndex] - prices[buyIndex]
                }
            }
        }
        
        return profit
    }
}
