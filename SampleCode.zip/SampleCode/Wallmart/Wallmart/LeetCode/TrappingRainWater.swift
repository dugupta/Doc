//
//  TrappingRainWater.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation

//https://leetcode.com/problems/trapping-rain-water/
/*
 Do as directed in question. For each element in the array, we find the maximum level of water it can trap after the rain, which is equal to the minimum of maximum height of bars on both the sides minus its own height.
 */

struct TrappingRainWater {
    func trap(_ height: [Int]) -> Int {
        var result = 0
        for (outerIndex, outerValue) in height.enumerated() {
            let firstArray = Array(height[0..<outerIndex])
            var secondArray: [Int] = []
            if outerIndex != height.count - 1 {
                secondArray = Array(height[(outerIndex + 1)...(height.count - 1)])
            }
            //secondArray = [height[0]...height[outerIndex-1]
//            for (index, value) in height.enumerated() {
//                if index == outerIndex { continue }
//                if index > outerIndex {
//                    //Objects at Right of the elements
//                    secondArray.append(value)
//                } else {
//                    //Objects at left of the elements
//                    firstArray.append(value)
//                }
//            }
            print("firstArray \(firstArray) and secondArray\(secondArray)")
            let leftMax = firstArray.max()
            let rightMax = secondArray.max()
            let minimum = min(leftMax ?? 0, rightMax ?? 0)
            let total = minimum - outerValue
            if total > 0 {
                result = result + total
            }
        }
        return result
    }
}


//struct TrappingRainWater {
//    func trap(_ height: [Int]) -> Int {
//        var result = 0
//        for (index, value) in height.enumerated() {
//            result = result + trap(height, start: index)
//        }
//        return result
//    }
//
//    func trap(_ height: [Int], start: Int) -> Int {
//        if height[start] == 0 { return 0}
//        var result = 0
//        for index in (start + 1)..<height.count {
//            if height[index] >= height[start] {
//                return result
//            } else {
//                result += 1
//            }
//        }
//        return 0
//    }
//}


