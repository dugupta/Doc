//
//  ParString.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation

struct ParString { }
//https://leetcode.com/problems/valid-parentheses/
extension ParString {
    
    func isParString(_ string: String) -> Bool {
        let parString = string
        var stack: [Character] = []
        for (_, char) in parString.enumerated() {
            if stack.isEmpty {
                stack.append(char)
            } else {
                let last = stack.last
                if last == char.inverse {
                    if "\(last!)\(char)".isClosed {
                        stack.removeLast()
                    } else {
                        stack.append(char)
                    }
                } else {
                    stack.append(char)
                }
            }
        }
        return stack.isEmpty
    }
}

extension String {
    func counter() -> String {
        switch self {
        case "(":
            return ")"
        case ")":
            return "("
            
        case "{":
            return "}"
        case "}":
            return "{"
            
        case "[":
            return "]"
        case "]":
            return "["
            
        default:
            return ""
        }
    }
    
    var isClosed: Bool {
        switch self {
        case "()", "{}", "[]":
            return true
        default:
            return false
        }
    }
}


extension Character {
    var inverse: Character {
        switch self {
        case "(":
            return ")"
        case ")":
            return "("
            
        case "{":
            return "}"
        case "}":
            return "{"
            
        case "[":
            return "]"
        case "]":
            return "["
            
        default:
            return "A"
        }
    }
}


