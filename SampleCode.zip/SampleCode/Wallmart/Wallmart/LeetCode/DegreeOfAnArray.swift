//
//  DegreeOfAnArray.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/degree-of-an-array/
/*
 Input: nums = [1,2,2,3,1]
 Output: 2
 Explanation:
 The input array has a degree of 2 because both elements 1 and 2 appear twice.
 Of the subarrays that have the same degree:
 [1, 2, 2, 3, 1], [1, 2, 2, 3], [2, 2, 3, 1], [1, 2, 2], [2, 2, 3], [2, 2]
 The shortest length is 2. So return 2.
 */
struct DegreeOfAnArray {
    
    func findShortestSubArray(_ nums: [Int]) -> Int {
        if nums.isEmpty { return 0 }
        var cache: [Int: Int] = [:]
        for (index, key) in nums.enumerated() {
            print("Index is \(index) value is \(key)")
            if let count = cache[key] {
                cache[key] = count + 1
            } else {
                cache[key] = 1
            }
        }
        print("cache \(cache)")
        let array = cache.sorted(by: { $0.value > $1.value })
        let maxCount = array.first?.value
        var max: [Int] = []
        for (key, found) in array.enumerated() {
            if found.value == maxCount {
                max.append(found.key)
            } else {
                break
            }
        }
        
        print("Max \(max)")
        var minimum: Int = nums.count
        for item in max {
            let firstIndex = nums.firstIndex(of: item) ?? 0
            let lastIndex = nums.lastIndex(of: item) ?? 0
            let margin = lastIndex - firstIndex
            if margin < minimum {
                minimum = margin
            }
        }
        return minimum + 1
    }
}
