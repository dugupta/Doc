//
//  CoinChange.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/30/20.
//

import Foundation
//Coin Change Problem
//[1, 2, 5, 10], 11
struct CoinChange {
    func coinChange(_ coins: [Int], _ amount: Int) -> Int {
        guard amount > 0 else { return 0 }
        let coins = coins.sorted()
        print("Sorted cojns \(coins)")
        var minAmounts = Array(repeating: -1, count: amount + 1)
        minAmounts[0] = 0
        print("Min array \(minAmounts)")
        
        for i in 1...amount {
            for coin in coins {
                if coin > i {
                    break
                }
                print("minAmounts[i - coin] \(minAmounts[i - coin])")
                if minAmounts[i - coin] == -1 {
                    continue
                }
                
                if minAmounts[i] == -1 {
                    minAmounts[i] = minAmounts[i - coin] + 1
                } else {
                    minAmounts[i] = min(minAmounts[i - coin] + 1, minAmounts[i])
                }
            }
        }
        return minAmounts[amount]
    }
    
    
    func coinChangeOptimized(_ coins: [Int], _ amount: Int) -> Int {
        guard amount > 0 else { return 0 }
        
        var solutions = Array(repeating: amount + 1, count: amount + 1)
        let sortedCoins = coins.sorted()
        
        solutions[0] = 0
        
        for currentAmount in 1...amount {
            for coin in sortedCoins where coin <= currentAmount {
                solutions[currentAmount] = min(solutions[currentAmount], 1 + solutions[currentAmount - coin])
            }
        }
        
        return solutions[amount] > amount ?  -1 : solutions[amount]
    }
    
}
