//
//  MiddleofTheLinkedList.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation

struct MiddleOfTheLinkedList {
    func middleNode(_ head: ListNode?) -> ListNode? {
        var stack: [ListNode] = []
        guard var head = head else { return nil }
        if head.next == nil { return head }
        var counter: Int = 1
        while head.next != nil {
            stack.append(head)
            head = head.next!
            counter += 1
        }
        stack.append(head)
        if counter == 2 { return stack.last }
        return stack[counter / 2 ]
    }
}
