//
//  TwoSum.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation
//https://leetcode.com/problems/two-sum/
struct TwoSum {
    
    func twoSum(_ nums: [Int], _ target: Int) -> [Int] {
        for (outerIndex, outerValue) in nums.enumerated() {
            for (innerIndex, innerValue) in nums.enumerated() {
                if outerIndex != innerIndex && outerValue + innerValue == target {
                    return [outerIndex, innerIndex]
                }
            }
        }
        return[]
    }
    
    func twoSumUsingDisctionary(_ nums: [Int], _ target: Int) -> [Int] {
        var memory: [Int : Int] = [:]
        for (outerIndex, outerValue) in nums.enumerated() {
            memory[outerValue] = outerIndex
        }
        for (index, value) in nums.enumerated() {
            let complement = target - value
            if let found = memory[complement] {
                if index != found {
                    return [index, found]
                }
            }
        }
        return[]
    }
    
//    func twoSumUsingFilter(_ nums: [Int], _ target: Int) -> [Int] {
//        let result = nums.filter({ ($0 + $1) == target })
//    }
}
