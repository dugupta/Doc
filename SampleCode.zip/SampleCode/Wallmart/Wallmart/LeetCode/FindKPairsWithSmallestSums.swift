//
//  FindKPairsWithSmallestSums.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation
//https://leetcode.com/problems/find-k-pairs-with-smallest-sums/
struct FindKPairsWithSmallestSums {
    
    struct Pair {
        let value: Int
        let pair: [Int]
    }
    
    func kSmallestPairs(_ nums1: [Int], _ nums2: [Int], _ k: Int) -> [[Int]] {
        if nums1.isEmpty || nums2.isEmpty || k == 0 { return [] }
        var retValue: [Pair] = []
        for (_, valueOne) in nums1.enumerated() {
            for (_, valueTwo) in nums2.enumerated() {
                retValue.append(Pair(value: valueOne + valueTwo, pair: [valueOne, valueTwo]))
            }
        }
        let sortedPair = retValue.sorted(by: { $0.value < $1.value })
        var returnValue: [[Int]] = []
        for index in 0..<k {
            if index + 1 > sortedPair.count { break }
            returnValue.append(sortedPair[index].pair)
        }
        return returnValue
    }
}
