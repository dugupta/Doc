//
//  NumberOfIslands.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import UIKit
import Foundation
import SwiftUI
///https://leetcode.com/problems/number-of-islands/

struct NumberOfIslands {
    func numIslands(_ grid: [[Character]]) -> Int {
        var maximum: Int = 0
        var newGrid = grid
        for (indexOne, _) in grid.enumerated() {
            for (indexTwo, _) in grid[indexOne].enumerated() {
                if newGrid[indexOne][indexTwo] == "1" {
                    if isIland(&newGrid, indexOne: indexOne, indexTwo: indexTwo) {
                        maximum = maximum + 1
                    }
                }
            }
        }
        return maximum
    }
    
    private func isIland(_ grid: inout [[Character]], indexOne: Int, indexTwo: Int) -> Bool {
        return area(&grid, indexOne: indexOne, indexTwo: indexTwo) >= 1
    }
    
    private func area(_ grid: inout [[Character]], indexOne: Int, indexTwo: Int) -> Int {
        //Exit condition
        //Check for border
        //Check for water
        let rows = grid.count
        let column = grid.first?.count ?? 0
        if indexOne < 0 || indexTwo < 0 || indexOne >= rows || indexTwo >= column || grid[indexOne][indexTwo] == "0" {
            return 0
        }
        // Now we have a number
        // Find left, Right, Top and bottom and change 1 to zero to avoid going back and check that grid again
        // First make grid value to zero
        grid[indexOne][indexTwo] = "0"
        let left = area(&grid, indexOne: indexOne, indexTwo: indexTwo - 1)
        let right = area(&grid, indexOne: indexOne, indexTwo: indexTwo + 1)
        let top = area(&grid, indexOne: indexOne - 1, indexTwo: indexTwo)
        let bottom = area(&grid, indexOne: indexOne + 1, indexTwo: indexTwo)
        
        return left + right + top + bottom + 1
    }
}


func findLeastNumOfUniqueInts(_ arr: [Int], _ k: Int) -> Int {
    var memory:[Int : Int] = [:]
    
    for item in arr {
        memory[item, default: 0] += 1
    }
    
    let sorted = memory.sorted(by: { $0.value < $1.value})
    
    var counter = k
    for item in sorted {
        if counter >= item.value {
            memory[item.key] = 0
            counter -= item.value
        } else {
            memory[item.key] = item.value - counter
            counter -= item.value - counter
            break
        }
    }
    print("sorted \(sorted)")
    let filter = memory.filter({ $0.value > 0 })
    
    return 1
}


class Solutionss {
    
    private func dfs(_ grid: [[Int]], _ visited: inout [[Bool]],_ result: inout [[Int]],  indexOne: Int, indexTwo: Int) {
        
        if grid[indexOne][indexTwo] == 1 && !visited[indexOne][indexTwo] ==  false {
            result.append([indexOne, indexTwo])
            visited[indexOne][indexTwo] = true
        }
        
        //Exit condition
        //Check for border
        //Check for water
        let rows = grid.count
        let column = grid.first?.count ?? 0
        if indexOne < 0 || indexTwo < 0 || indexOne >= rows || indexTwo >= column || grid[indexOne][indexTwo] == 0 {
            
        } else {
            dfs(grid, &visited, &result, indexOne: indexOne, indexTwo: indexTwo - 1)
            dfs(grid, &visited, &result, indexOne: indexOne, indexTwo: indexTwo + 1)
            dfs(grid, &visited, &result, indexOne: indexOne - 1, indexTwo: indexTwo)
            dfs(grid, &visited, &result, indexOne: indexOne + 1, indexTwo: indexTwo)
        }
    }
    
    
    
    func shortestBridge(_ grid: [[Int]]) -> Int {
        //[1,1,1,1,1]
        //[1,0,0,0,1]
        //[1,0,1,0,1]
        //[1,0,0,0,1]
        //[1,1,1,1,1]
        if grid.count == 0 { return -1 }
        var first: [[Int]] = []
        var second: [[Int]] = []
        var visited = Array(repeating: Array(repeating: false, count:grid[0].count, count: grid.count))
        var row = grid.count
        var column = grid[0].count
        for indexOne in 0..<row {
            for indextTwo in 0..<column {
                if grid[indexOne][indextTwo] == 1 && visited[indexOne][indextTwo] == false {
                    if first.count == 0 {
                        dfs(grid, &visited, &first, indexOne: indexOne, indexTwo: indexTwo )
                    } else if secound.count == 0 && first.count > 0 {
                        dfs(grid, &visited, &second, indexOne: indexOne, indexTwo: indexTwo )
                        
                    }
                }
                }
            }
        }
}


