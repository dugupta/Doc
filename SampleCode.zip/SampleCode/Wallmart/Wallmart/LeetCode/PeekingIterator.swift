//
//  PeekingIterator.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/peeking-iterator/
/*
 Assume that the iterator is initialized to the beginning of the list: [1,2,3].

 Call next() gets you 1, the first element in the list.
 Now you call peek() and it returns 2, the next element. Calling next() after that still return 2.
 You call next() the final time and it returns 3, the last element.
 Calling hasNext() after that should return false.
 */
class PeekingInterator {
    private var storage: [Int] = []
    
    init(_ arr: IndexingIterator<Array<Int>>) {
        self.storage = Array(arr)
    }
    
    func next() -> Int {
        return storage.removeFirst()
    }
    
    func peek() -> Int {
        return storage.first ?? 0
    }
    
    func hasNext() -> Bool {
        return !storage.isEmpty
    }
}
