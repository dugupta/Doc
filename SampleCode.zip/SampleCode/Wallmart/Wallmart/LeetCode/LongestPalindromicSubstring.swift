//
//  LongestPalindromicSubstring.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/6/20.
//

import Foundation


class FindLongestPalindrom {
    func longestPalindrome(_ inputString: String) -> String {
        if inputString.count < 2 { return inputString }
        var start = 0
        var end = 0
        let word = Array(inputString)
        for i in 0..<word.count - 1 {
            let len1 = checkSubString(i, i, word)
            let len2 = checkSubString(i, i+1, word)
            let len = max(len1, len2)
            
            if len > (end - start) {
                start = i - ((len - 1) / 2)
                end = i + (len / 2)
            }
        }
        return String(word[start..<end + 1])
    }
    
    func checkSubString(_ i: Int, _ j: Int, _ inputString: [Character]) -> Int {
        var left = i
        var right = j
        while (left >= 0 && right < inputString.count && inputString[left] == inputString[right] ) {
            left -= 1
            right += 1
        }
        
        return right - left - 1
    }
}

struct LongestPalindromicSubstring {
    
    func longestPalindrome(_ string: String) -> String {
        if string.isEmpty { return "" }
        
        var start = 0
        var end = 0
        
        for index in string.indices {
            //let len1: Int = expand(string!, left: index, right: index)
        }
        return ""
    }
    
    func expand(_ string: String, left: Int, right: Int) -> Int {
        if string == nil || left > right { return 0 }
        var leftIndex = left
        var rightIndex = right
        
//        while leftIndex >= 0 && rightIndex < string.count && string[leftIndex] == string[rightIndex] {
//            leftIndex += 1
//            rightIndex -= 1
//            
//        }
       return leftIndex + rightIndex + 1
    }
    /*
    func longestPalindrome(_ string: String) -> String {
        var array: [String] = []
        func all(_ string: String = "babad") {
            var pelindrome = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                pelindrome += String(char)
                if pelindrome.isPalindrome {
                    array.append(pelindrome)
                }
                
            }
            all(String(string.dropFirst()))
        }
        all(string)
        var longest = ""
        for pelindrome in array {
            if pelindrome.count > longest.count {
                longest = pelindrome
            }
        }
        return longest
    }
 */
}
