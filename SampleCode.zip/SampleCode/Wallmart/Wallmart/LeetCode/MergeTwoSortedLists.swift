//
//  MergeTwoSortedLists.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation
//https://leetcode.com/problems/merge-two-sorted-lists/
struct MergeTwoSrtedList {
    func mergeTwoLists(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
        if l1 == nil {
            return l2
        } else if l2 == nil {
            return l1
        } else if (l1?.val ?? 0 < l2?.val ?? 0) {
            l1?.next = mergeTwoLists(l1?.next, l2)
            return l1
        } else {
            l2?.next = mergeTwoLists(l2?.next, l1)
            return l2
        }
    }
}
