//
//  JumpGame.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

class JumpGameTwo {
    func validPalindrome(_ s: String) -> Bool {
        var count = 0
        return modify(s, count: &count)
    }
    
    func modify(_ string: String, count: inout Int) -> Bool {
        var arrayString = Array(string)
        for index in 0..<arrayString.count / 2 {
            let end = arrayString.count - (1 + index)
            if arrayString[index] == arrayString[end] {
                continue
            } else {
                count += 1
                if count > 1 {
                    return false
                }
                if arrayString[index] == arrayString[end - 1] {
                    arrayString.remove(at: end)
                } else {
                    arrayString.remove(at: index)
                }
                let modifiedString = String(arrayString)
                return modify(modifiedString, count: &count)
            }
        }
        return true
    }
    
    /*
    func validPalindrome(_ s: String) -> Bool {
        let input = s
        if input == String(s.reversed()) { return true }
        var iterate = Array(input)
        for (index, _) in iterate.enumerated() {
             var string = iterate
            string.remove(at: index)
            if String(string) == String(String(string).reversed()) {
                return true
            }
        }
        return false
    }
    */
}

import Foundation
//Input: nums = [2,3,1,1,4]  true
//Input: nums = [3,2,1,0,4] false
//https://leetcode.com/problems/jump-game-ii/
class JumpGame {
    func jump(_ nums: [Int] = [2,3,1,1,4]) -> Int {
        let n = nums.count
        if n < 2 { return 0 }
        var maxJump = nums[0]
        var maxSteps = nums[0]
        var jump = 1
        
        for index in 0..<nums.count {
            if maxSteps < index {
                jump += 1
                maxSteps = maxJump
            }
            maxJump = max(maxJump, nums[index] + index)
        }
        return jump
    }
    
    func bruteForce(_ nums: [Int]) -> Int {
        let n = nums.count
        if n < 2 { return 0 }
        var maxPos = nums[0]
        var maxSteps = nums[0]
        var jump = 1
        
        for index in 0..<nums.count {
            if maxSteps < index {
                jump += 1
                maxSteps = maxPos
            }
            maxPos = max(maxPos, nums[index] + index)
        }
        return jump
    }
    
    
    func greedy(_ nums: [Int] = [1,2]) -> Int {
        let n = nums.count
        if n < 2 { return 0 }
        var jump = 0
        var index = 0
        while index != nums.count {
            var subArray: [Int] = []
            if nums[index] + index >= nums.count {
                subArray = Array(nums[(index + 1)..<nums.count])
            } else {
                subArray = Array(nums[(index + 1)...(nums[index] + index)])
            }
            if subArray.count == 0 { return  jump}
            var high = 0
            for (newIndex, item) in subArray.enumerated() {
                if nums[index] + item > high {
                    high = nums[index] + item
                    index = index + newIndex + 1
                }
            }
            jump += 1
        }
        return jump
    }
}
