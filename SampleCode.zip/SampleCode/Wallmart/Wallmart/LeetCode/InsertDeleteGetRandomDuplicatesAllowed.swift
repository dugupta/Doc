//
//  InsertDeleteGetRandomDuplicatesAllowed.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation

//https://leetcode.com/problems/insert-delete-getrandom-o1-duplicates-allowed/submissions/
class InsertDeleteGetRandomDuplicatesAllowed {
  
}

/*
 ["RandomizedCollection","insert","insert","insert","getRandom","remove","getRandom"]
 [[],[1],[1],[2],[],[1],[]]
 */
//Insert Delete & Get Random in order 1
class RandomizedCollection {
    private var map: [Int: Set<Int>] = [:]
    private var list: [Int] = []

    /** Inserts a value to the collection. Returns true if the collection did not already contain the specified element. */
    func insert(_ val: Int) -> Bool {
        let newInsert = (map[val] == nil)
        map[val, default: []].insert(list.count)
        list.append(val)
        return newInsert
    }
    
    /** Removes a value from the collection. Returns true if the collection contained the specified element. */
    func remove(_ val: Int) -> Bool {
        if map[val] != nil {
            let idx = map[val]!.first!
            map[val]!.remove(idx)
            if map[val]!.isEmpty {
                map[val] = nil
            }

            let last = list.removeLast()
            let lastIdx = list.count
            if lastIdx != idx {
                list[idx] = last
                map[last]!.remove(lastIdx)
                map[last]!.insert(idx)
            }
            return true
        }
        return false
    }
    
    /** Get a random element from the collection. */
    func getRandom() -> Int {
        return list.randomElement()!
    }
}
