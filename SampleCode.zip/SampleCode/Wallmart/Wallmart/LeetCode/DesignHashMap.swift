//
//  DesignHashMap.swift
//  Wallmart
//
//  Created by Durgesh Lal on 1/12/21.
//

import Foundation

class DesignHashMap {
    
    struct Pair {
        let key: Int
        var value: Int
    }
    
    private var map: [Pair] = []
    /** Initialize your data structure here. */
    init() { }
    
    /** value will always be non-negative. */
    func put(_ key: Int, _ value: Int) {
        let existingValue = map.firstIndex(where: { $0.key == key })
        if existingValue == nil {
            let item = Pair(key: key, value: value)
            map.append(item)
        } else {
            map[existingValue!].value = value
        }
    }
    
    /** Returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key */
    func get(_ key: Int) -> Int {
        let existingValue = map.firstIndex(where: { $0.key == key })
        if existingValue == nil {
            return -1
        }
        return map[existingValue!].value
    }
    
    /** Removes the mapping of the specified value key if this map contains a mapping for the key */
    func remove(_ key: Int) {
        let existingValue = map.firstIndex(where: { $0.key == key })
        if existingValue != nil {
            map.remove(at: existingValue!)
        }
    }
}
