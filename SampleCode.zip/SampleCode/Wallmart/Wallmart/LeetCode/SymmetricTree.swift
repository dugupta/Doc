//
//  SymmetricTree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/6/20.
//

import Foundation
//https://leetcode.com/problems/symmetric-tree/
class SymmetricTree {
    
    func isSymmetric(_ root: TreeNode<Int>?) -> Bool {
        return isSymmetric(root, nodeTwo: root)
    }
    
    func isSymmetric(_ nodeOne: TreeNode<Int>?, nodeTwo: TreeNode<Int>?) -> Bool {
        if nodeOne == nil && nodeTwo == nil { return true }
        if nodeOne == nil || nodeTwo == nil { return false }
        return  nodeOne?.value == nodeTwo?.value && isSymmetric(nodeOne?.left, nodeTwo: nodeTwo?.right) && isSymmetric(nodeTwo?.left, nodeTwo: nodeOne?.right)
    }
}
