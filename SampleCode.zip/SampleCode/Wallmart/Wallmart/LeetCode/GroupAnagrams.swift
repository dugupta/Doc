//
//  GroupAnagrams.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/group-anagrams/
struct GroupAnagrams {
    
    private func isValidAngrams(_ one: String, two: String) -> Bool {
        return one.sorted() == two.sorted()
    }
    
    func groupAnagrams(_ strs: [String]) -> [[String]] {
        //Input: strs = ["eat","tea","tan","ate","nat","bat"]
        var cache: [[Character] : [String]] = [:]
        
        for item in strs {
            let key = item.sorted()
            if let found = cache[key] {
                var new = found
                new.append(item)
                cache[key] = new
            } else {
                cache[key] = [item]
            }
        }
      //  let allValues = cache.values
        return Array(cache.values)
    }
}
