//
//  MinStack.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/29/20.
//

import Foundation
//https://leetcode.com/problems/min-stack/
class MinStack {

    /** initialize your data structure here. */
    var stack: [Int]
    var minStack: [Int]
    
    init() {
        stack = []
        minStack = []
    }
    
    func push(_ x: Int) {
        stack.append(x)
        
        if minStack.isEmpty || x <= minStack.last! {
            minStack.append(x)
        }
    }
    
    func pop() {
        if stack.isEmpty { return }
        let value = stack.removeLast()
        if let last = minStack.last, last == value {
            minStack.removeLast()
        }
    }
    
    func top() -> Int {
        return stack.isEmpty ? -1 : stack.last!
    }
    
    func getMin() -> Int {
        return minStack.isEmpty ? -1 : minStack.last!
    }
}


