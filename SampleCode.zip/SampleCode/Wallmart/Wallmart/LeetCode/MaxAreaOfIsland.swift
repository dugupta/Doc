//
//  MaxAreaOfIsland.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import Foundation

//https://leetcode.com/problems/max-area-of-island/
/*
 Input: grid = [[0,0,1,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,1,1,0,1,0,0,0,0,0,0,0,0],[0,1,0,0,1,1,0,0,1,0,1,0,0],[0,1,0,0,1,1,0,0,1,1,1,0,0],[0,0,0,0,0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,0,0,0,0,0,0,1,1,0,0,0,0]]
 Output: 6
 Explanation: The answer is not 11, because the island must be connected 4-directionally.
 */
struct MaxAreaOfIsland {
    func maxAreaOfIsland(_ grid: [[Int]] = [[0,0,1,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,1,1,0,1,0,0,0,0,0,0,0,0],[0,1,0,0,1,1,0,0,1,0,1,0,0],[0,1,0,0,1,1,0,0,1,1,1,0,0],[0,0,0,0,0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,0,0,0,0,0,0,1,1,0,0,0,0]]) -> Int {
        var maximum: Int = 0
        var newGrid = grid
        for (indexOne, _) in grid.enumerated() {
            for (indexTwo, _) in grid[indexOne].enumerated() {
                if newGrid[indexOne][indexTwo] == 1 {
                    maximum = max(maximum, gridArea(&newGrid, indexOne: indexOne, indexTwo: indexTwo))
                }
            }
        }
        return maximum
    }
    
    private func gridArea(_ grid: inout [[Int]], indexOne: Int, indexTwo: Int) -> Int {
        //Exit condition
        //Check for border
        //Check for water
        let rows = grid.count
        let column = grid.first?.count ?? 0
        if indexOne < 0 || indexTwo < 0 || indexOne >= rows || indexTwo >= column || grid[indexOne][indexTwo] == 0 {
            return 0
        }
        // Now we have a number
        // Find left, Right, Top and bottom and change 1 to zero to avoid going back and check that grid again
        // First make grid value to zero
        grid[indexOne][indexTwo] = 0
        let left = gridArea(&grid, indexOne: indexOne, indexTwo: indexTwo - 1)
        let right = gridArea(&grid, indexOne: indexOne, indexTwo: indexTwo + 1)
        let top = gridArea(&grid, indexOne: indexOne - 1, indexTwo: indexTwo)
        let bottom = gridArea(&grid, indexOne: indexOne + 1, indexTwo: indexTwo)
        
        return left + right + top + bottom + 1
    }
}
