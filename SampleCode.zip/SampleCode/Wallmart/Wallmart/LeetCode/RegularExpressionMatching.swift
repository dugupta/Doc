//
//  RegularExpressionMatching.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/1/20.
//

import Foundation

struct RegularExpressionMatching {
    
    func isMatch(_ s: String, _ p: String) -> Bool {
        return true
//        if p.isEmpty { return s.isEmpty }
//        let firstMatch = !s.isEmpty && (p[0] == s[0] || p[0] == ".")
//
//        if p.length >= 2 && p[1] == "*" {
//            return (isMatch(s, p.substring(fromIndex: 2)) || (firstMatch && isMatch(s.substring(fromIndex: 1), p)))
//        } else {
//            return firstMatch && isMatch(s.substring(fromIndex: 1), p.substring(fromIndex: 1))
//        }
    }
}
