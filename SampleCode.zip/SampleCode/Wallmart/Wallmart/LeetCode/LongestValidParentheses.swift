//
//  LongestValidParentheses.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation

struct LongestValidParentheses {
    
    func allSubString(_ string: String) -> [String] {
        var array: [String] = []
        func all(_ string: String) {
            var tempString = ""
            if string.count == 1 {
                array.append(string)
                return
            }
            for char in string {
                tempString += String(char)
                array.append(tempString)
            }
            all(String(string.dropFirst()))
        }
        all(string)
        return array
    }
    
    func isValidParenthesis(_ string: String) -> Bool {
        
        let parString = string
        var stack: [Character] = []
        for (_, char) in parString.enumerated() {
            if stack.isEmpty {
                stack.append(char)
            } else {
                let last = stack.last
                if last == char.inverse {
                    if "\(last!)\(char)".isClosed {
                        stack.removeLast()
                    } else {
                        stack.append(char)
                    }
                } else {
                    stack.append(char)
                }
            }
        }
        return stack.isEmpty
    }
    
    func longestValidParenthesesBruteForce(_ s: String) -> Int {
        if s.isEmpty { return 0 }
        let substring = allSubString(s)
        var longest = ""
        for string in substring {
            if isValidParenthesis(string) {
                if string.count > longest.count {
                    longest = string
                }
            }
        }
        return longest.count
    }
    
    func longestValidParentheses(_ s: String) -> Int {
        return longestValidParenthesesBruteForce(s)
    }
    
    func longestValidParenthesesUsingStack(_ s: String) -> Int {
        
        return 0
    }
}
