//
//  VerifyPreorderSequenceBinarySearchTree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation
//https://leetcode.com/problems/verify-preorder-sequence-in-binary-search-tree/submissions/
//https://www.geeksforgeeks.org/check-if-a-given-array-can-represent-preorder-traversal-of-binary-search-tree/
struct VerifyPreorderSequenceBinarySearchTree {
    //[5,2,6,1,3]
    func verifyPreorder(_ preorder: [Int]) -> Bool {
        var stack: [Int] = []
        var root: Int = -1
        for value in preorder {
            if root > value { return false }
            print("Stack is \(stack)")
            print("Value is \(value)")
            while (!stack.isEmpty && value > stack.last ?? 0) {
                if let last = stack.last {
                    print("Last value is \(last)")
                    root = last
                }
                stack.removeLast()
            }
            stack.append(value)
        }
        return true
        
        
        /*
        
        var travel: [Int] = []
        if preorder.isEmpty { return true }
        var tree = BinarySearchTree<Int>()
        for value in preorder {
            let node = BinaryNode(value: value)
            tree.insert(value)
        }

        if let root = tree.root {
            root.traversePreOrder { (value) in
                travel.append(value)
            }
        }
        return travel == preorder
 */
    }
    
}
