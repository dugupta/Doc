//
//  LRUCache.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/1/20.
//

import Foundation
//https://leetcode.com/problems/lru-cache/
/*
 Input
 ["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]
 [[2], [1, 1], [2, 2], [1], [3, 3], [2], [4, 4], [1], [3], [4]]
 Output
 [null, null, null, 1, null, -1, null, -1, 3, 4]

 */
class LRUCache {
    
    private var capacity: Int
    private var cache: [Int: Int] = [:]
    private var leastCashTrack: [Int: Int] = [:]
    private var count = 0
    
    init(_ capacity: Int) {
        self.capacity = capacity
    }
    
    func get(_ key: Int) -> Int {
        if let value = cache[key] {
            count += 1
            leastCashTrack[key] = count
            return value
        }
        return -1
    }
    
    func put(_ key: Int, _ value: Int) {
        // Track the page first using leastCashTrack
        count += 1
        leastCashTrack[key, default: 0] = count
        
        // If first time or less than capacity
        if cache[key] != nil  || cache.count < capacity {
            cache[key] = value
            return
        }
        
        if let minItem = leastCashTrack.min(by: { $0.value < $1.value }) {
            cache.removeValue(forKey: minItem.key)
            leastCashTrack.removeValue(forKey: minItem.key)
        }
        cache[key] = value
    }
    
    func test() {
        let cache = LRUCache(2)
        cache.get(2)
        cache.put(2, 6)
        cache.get(1)
        cache.put(1, 5)
        cache.put(1, 2)
        cache.get(1)
        cache.get(2)
        /*
        cache.put(2, 1)
        // cache is {1=1}
        cache.put(2, 2) // cache is {1=1, 2=2}
        var object = cache.get(1)    // return 1
        print("Get \(object)")
        cache.put(3, 3) // LRU key was 2, evicts key 2, cache is {1=1, 3=3}
        object = cache.get(2)    // returns -1 (not found)
        print("Get \(object)")
        cache.put(4, 4) // LRU key was 1, evicts key 1, cache is {4=4, 3=3}
        object = cache.get(1)    // return -1 (not found)
        print("Get \(object)")
        object = cache.get(3)    // return 3
        print("Get \(object)")
        object = cache.get(4)
        print("Get \(object)")
 */
    }
}


