//
//  Implement Trie (Prefix Tree).swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/3/20.
//

import Foundation

class Trie {

    var stack: [String] = []
    /** Initialize your data structure here. */
    init() {
        
    }
    
    /** Inserts a word into the trie. */
    func insert(_ word: String) {
        if search(word) { return }
        stack.append(word)
    }
    
    /** Returns if the word is in the trie. */
    func search(_ word: String) -> Bool {
        if stack.firstIndex(of: word) != nil {
            return true
        }
        return false
    }
    
    /** Returns if there is any word in the trie that starts with the given prefix. */
    func startsWith(_ prefix: String) -> Bool {
        if stack.first(where: { $0.contains(prefix) }) != nil {
            return true
        } else {
            return false
        }
    }
}


class TrieTwo {

    private let root: Node
    
    /** Initialize your data structure here. */
    init() {
        root = Node(nil, nil)
    }
    
    /** Inserts a word into the trie. */
    func insert(_ word: String) {
        guard !word.isEmpty else {
          return
        }
        var currentNode = root
        for character in word.lowercased() {
          if let childNode = currentNode.children[character] {
            currentNode = childNode
          } else {
            currentNode.add(character: character)
            currentNode = currentNode.children[character]!
          }
        }
        guard !currentNode.isTerminating else {
          return
        }
        currentNode.isTerminating = true
    }
    
    /** Returns if the word is in the trie. */
    func search(_ word: String) -> Bool {
        return hasWord(word, true)
    }
    
    /** Returns if there is any word in the trie that starts with the given prefix. */
    func startsWith(_ prefix: String) -> Bool {
        return hasWord(prefix, false)
    }
    
    private func hasWord(_ word: String, _ shouldBeTerminating: Bool) -> Bool {
        var current = root
        for i in 0..<word.count {
            let character = word[word.index(word.startIndex, offsetBy: i)]
            if let child = current.children[character] {
                current = child
            } else {
                return false
            }
        }
        if shouldBeTerminating {
            return current.isTerminating
        }
        return true
    }
    
    class Node {
        var value: Character?
        weak var parent: Node?
        var children: [Character:Node] = [:]
        var isTerminating = false
        
        init(_ value: Character?,_  parent: Node?) {
            self.value = value
            self.parent = parent
        }
        
        func add(character: Character) {
            guard children[character] == nil else { return }
            children[character] = Node(character, self)
        }
    }
}


