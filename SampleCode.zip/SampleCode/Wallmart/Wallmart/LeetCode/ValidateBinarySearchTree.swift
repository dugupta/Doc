//
//  ValidateBinarySearchTree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/2/20.
//

import Foundation
//
//public class TreeNode {
//    var val: Int
//    var left: TreeNode?
//    var right: TreeNode?
//    init() { self.val = 0; self.left = nil; self.right = nil; }
//    init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
//    init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
//        self.val = val
//        self.left = left
//        self.right = right
//    }
//}

struct ValidateBinarySearchTree {
    
    func isValid(_ root: BinaryNode<Int>?, lower: Int?, upper: Int?) -> Bool {
        if root == nil { return true }
        let rootValue = root?.value
        if lower != nil && rootValue ?? -1 <= lower ?? -1 { return false }
        if upper != nil && rootValue ?? -1 >= upper ?? -1 { return false }
        if !isValid(root?.rightChild, lower: rootValue, upper: upper) { return false }
        if !isValid(root?.leftChild, lower: lower, upper: rootValue) { return false }
        return true
    }
    
    func isValidBST(_ root: BinaryNode<Int>?) -> Bool {
        if root == nil { return true }
        if root?.leftChild ==  nil && root?.rightChild == nil { return true }
        return isValid(root, lower: nil, upper: nil)
    }
}
