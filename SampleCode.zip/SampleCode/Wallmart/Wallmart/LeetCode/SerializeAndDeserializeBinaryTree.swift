//
//  SerializeAndDeserializeBinaryTree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 12/4/20.
//

import Foundation
//https://leetcode.com/problems/serialize-and-deserialize-binary-tree/solution/
struct SerializeAndDeserializeBinaryTree {
    
    func serialize(_ root: BinaryNode<Int>?) -> String {
        guard let root = root else {
            return "X"
        }
        let result = "\(root.value)|\(serialize(root.leftChild))|\(serialize(root.rightChild))"
        print("Result is  \(result)")
        return result
    }
    
    func deserialize(_ data: String) -> BinaryNode<Int>? {
        var dataSplit = data.split(separator:"|").map { return String($0) }
        print("Data Split \(dataSplit)")
        var index = 0
        return deserializeHelper(&dataSplit, &index)
    }
    
    func deserializeHelper(_ arr: inout [String], _ index: inout Int) -> BinaryNode<Int>? {
        if index > arr.count - 1 { return nil }
        print("Index \(index)")
        let first = arr[index]
        print("first \(first)")
        guard first != "X" else { return nil }
        let node = BinaryNode(value: Int(first)!)
        print("node \(index)")
        index += 1
        node.leftChild = deserializeHelper(&arr, &index)
        print("leftChild \(node.leftChild?.value)")
        index += 1
        node.rightChild = deserializeHelper(&arr, &index)
        print("leftChild \(node.rightChild?.value)")
        return node
    }
    
    /*
    
    func serialize(_ root: TreeNode<String>?) -> String {
        var result: String = ""
        root?.forEachDepthFirst(visit: { (node) in
            print("Visit: \(node)")
            result = result + node.value + " | "
            print("Result : \(result)")
            
        })
        return result
    }
    
    func deserialize(_ data: String) -> TreeNode<String>? {
        print("Data \(data)")
        return nil
    }
 */
}
