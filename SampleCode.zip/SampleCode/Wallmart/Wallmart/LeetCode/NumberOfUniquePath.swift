//
//  NumberOfUniquePath.swift
//  Wallmart
//
//  Created by Durgesh Lal on 11/28/20.
//

import Foundation
//https://leetcode.com/problems/unique-paths/
struct NumberOfUniquePath {
    
    func numberOfUniquePath(_ rows: Int, columns: Int) -> Int {
        var matrix: [[Int]] = []
        
        for _ in 0..<rows {
            var items: [Int] = []
            for _ in 0..<columns {
                items.append(0)
            }
            matrix.append(items)
        }
        
        for row in 0..<rows {
            for column in 0..<columns {
                if row == 0 || column == 0 {
                    matrix[row][column] = 1
                } else {
                    matrix[row][column] = matrix[row - 1][column] + matrix[row][column - 1]
                }
            }
        }
        return matrix[rows - 1][columns - 1]
    }
}
