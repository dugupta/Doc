//
//  Top K Frequent Words.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/23/21.
//

import Foundation
//https://leetcode.com/problems/top-k-frequent-words/
/*
 
 Example 1:

 Input: words = ["i","love","leetcode","i","love","coding"], k = 2
 Output: ["i","love"]
 Explanation: "i" and "love" are the two most frequent words.
 Note that "i" comes before "love" due to a lower alphabetical order.
 Example 2:

 Input: words = ["the","day","is","sunny","the","the","the","sunny","is","is"], k = 4
 Output: ["the","is","sunny","day"]
 Explanation: "the", "is", "sunny" and "day" are the four most frequent words, with the number of occurrence being 4, 3, 2 and 1 respectively.

 */
struct TopKFrequentWords {
    func topKFrequent(_ words: [String] = ["i","love","leetcode","i","love","coding"], _ k: Int = 3) -> [String] {
        //0 is count, 1 is index
        /*
         // Commented code is a working copy
        var wordTable: [String: Int] = [String: Int]()
        for word in words {
            let value = wordTable[word] ?? 0
            wordTable[word] = value + 1
        }
//        let sortedTuple = wordTable.sorted { (val0, val1) -> Bool in
//            return val0.value > val1.value || (val0.value == val1.value && val0.key < val1.key)
//        }
        let sortedTuple = wordTable.sorted(by: { ($0.value > $1.value) || ($0.value == $1.value && $0.key < $1.key) })
        let keys = sortedTuple.map { $0.key }
        return Array(keys.prefix(k))
        
        */
        typealias Value = (Int, Int)
        
        var memory: [String: Value] = [:]
        
        for (index, word) in words.enumerated() {
            if let value = memory[word] {
                var count = value.0
                count += 1
                memory[word] = (count, value.1)
            } else {
                memory[word] = (1, index)
            }
        }
        
        //var sorted = memory.sorted(by:{ $0.value.0 > $1.value.0 })
        
        var sorted = memory.sorted(by: { $0.value.1 < $1.value.1})
        sorted = sorted.sorted(by:{ $0.value.0 > $1.value.0 })
        
        print("sorted value \(sorted)")
        var result: [String] = []
        for index in 0..<k {
            print("object at index is \(sorted[index].key)")
            result.append(sorted[index].key)
        }
        return result
    }
}
