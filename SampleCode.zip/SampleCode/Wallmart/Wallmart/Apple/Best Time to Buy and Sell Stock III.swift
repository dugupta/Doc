//
//  Best Time to Buy and Sell Stock III.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/31/21.
//

import Foundation

struct BestTimetoBuyandSellStockIII {
    func maxProfit(_ prices: [Int] = [1,2,3,4,5]) -> Int {
        //[7,2,4,1,5,3,6,4]
        var buy = prices[0]
        var sell = 0
        var maxProfit = 0
        var secondMax = 0
        for price in prices {
            if price < buy {
                buy = price
            } else {
                let profit = price - buy
                if maxProfit == 0 {
                    maxProfit = max(maxProfit, profit)
                    buy = price
                } else {
                    if profit > maxProfit {
                        secondMax = max(maxProfit, secondMax)
                        maxProfit = profit
                     } else {
                        secondMax = max(secondMax, profit)
                    }
                }
            }
        }
        return maxProfit + secondMax
    }
}
