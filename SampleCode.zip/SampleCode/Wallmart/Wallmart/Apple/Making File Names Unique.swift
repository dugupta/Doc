//
//  MakingFileNamesUnique.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/22/21.
//

import Foundation
/*
 ///https://leetcode.com/problems/making-file-names-unique/
 Example 1:

 Input: names = ["pes","fifa","gta","pes(2019)"]
 Output: ["pes","fifa","gta","pes(2019)"]
 Explanation: Let's see how the file system creates folder names:
 "pes" --> not assigned before, remains "pes"
 "fifa" --> not assigned before, remains "fifa"
 "gta" --> not assigned before, remains "gta"
 "pes(2019)" --> not assigned before, remains "pes(2019)"
 Example 2:

 Input: names = ["gta","gta(1)","gta","avalon"]
 Output: ["gta","gta(1)","gta(2)","avalon"]
 Explanation: Let's see how the file system creates folder names:
 "gta" --> not assigned before, remains "gta"
 "gta(1)" --> not assigned before, remains "gta(1)"
 "gta" --> the name is reserved, system adds (k), since "gta(1)" is also reserved, systems put k = 2. it becomes "gta(2)"
 "avalon" --> not assigned before, remains "avalon"
 Example 3:

 Input: names = ["onepiece","onepiece(1)","onepiece(2)","onepiece(3)","onepiece"]
 Output: ["onepiece","onepiece(1)","onepiece(2)","onepiece(3)","onepiece(4)"]
 Explanation: When the last folder is created, the smallest positive valid k is 4, and it becomes "onepiece(4)".
 Example 4:

 Input: names = ["wano","wano","wano","wano"]
 Output: ["wano","wano(1)","wano(2)","wano(3)"]
 Explanation: Just increase the value of k each time you create folder "wano".
 Example 5:

 Input: names = ["kaido","kaido(1)","kaido","kaido(1)"]
 Output: ["kaido","kaido(1)","kaido(2)","kaido(1)(1)"]
 Explanation: Please note that system adds the suffix (k) to current name even it contained the same suffix before.
 */
struct MakingFileNamesUnique {
    func getFolderNames(_ names: [String] = ["gta","gta(1)","gta","avalon"]) -> [String] {
        var res: [String] = []
        var dict: [String: Int] = [:]
        
        for s in names {
            if let value = dict[s] {
                for i in dict[s]!...res.count {
                    let value = dict["\(s)(\(i))"]
                    if value == nil {
                        dict["\(s)(\(i))"] = 1
                        res.append("\(s)(\(i))")
                        dict[s] = i
                        break
                    }
                }
            } else {
                dict[s] = 1
                res.append(s)
            }
        }
        return res
    }
}
