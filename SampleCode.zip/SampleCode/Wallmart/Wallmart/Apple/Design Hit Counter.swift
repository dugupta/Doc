//
//  Design Hit Counter.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/21/21.
//

import Foundation
//https://leetcode.com/problems/design-hit-counter/
/*
 Example 1:
 
 Input
 ["HitCounter", "hit", "hit", "hit", "getHits", "hit", "getHits", "getHits"]
 [[], [1], [2], [3], [4], [300], [300], [301]]
 Output
 [null, null, null, null, 3, null, 4, 3]
 
 Explanation
 HitCounter hitCounter = new HitCounter();
 hitCounter.hit(1);       // hit at timestamp 1.
 hitCounter.hit(2);       // hit at timestamp 2.
 hitCounter.hit(3);       // hit at timestamp 3.
 hitCounter.getHits(4);   // get hits at timestamp 4, return 3.
 hitCounter.hit(300);     // hit at timestamp 300.
 hitCounter.getHits(300); // get hits at timestamp 300, return 4.
 hitCounter.getHits(301); // get hits at timestamp 301, return 3.
 
 
 Constraints:
 
 1 <= timestamp <= 2 * 109
 All the calls are being made to the system in chronological order (i.e., timestamp is monotonically increasing).
 At most 300 calls will be made to hit and getHits.
 
 
 
 */
class HitCounter {
    
    var hits: [Int: Int] = [:]
    
    init() {
        
    }
    
    func hit(_ timestamp: Int) {
        // if let value = hits[timestamp] {
        //     hits[timestamp] = value + 1
        // } else {
        //     hits[timestamp] = 1
        // }
        hits[timestamp, default: 0] += 1
    }
    
    func getHits(_ timestamp: Int) -> Int {
        let start = timestamp - 299
        let filter = hits.filter({ $0.key >= start && $0.key <= timestamp })
        let sum = filter.reduce(0) { result, item in
            result + item.value
        }
        
        return sum
    }
    
    /**
     * Your HitCounter object will be instantiated and called as such:
     * let obj = HitCounter()
     * obj.hit(timestamp)
     * let ret_2: Int = obj.getHits(timestamp)
     */
    
    static func test() {
        let hitCounter = HitCounter()
        hitCounter.hit(1)
        hitCounter.hit(2)
        hitCounter.hit(3)
        
        let resultOne = hitCounter.getHits(300)
        
        hitCounter.hit(4)
        
        let resultTwo = hitCounter.getHits(300)
        let resultThree = hitCounter.getHits(301)
    }
    
}

/**
 * Your HitCounter object will be instantiated and called as such:
 * let obj = HitCounter()
 * obj.hit(timestamp)
 * let ret_2: Int = obj.getHits(timestamp)
 */
