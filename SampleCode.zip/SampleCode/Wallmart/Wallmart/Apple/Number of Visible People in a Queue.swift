//
//  Number of Visible People in a Queue.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/15/21.
//

import Foundation
/*
 ///https://leetcode.com/problems/number-of-visible-people-in-a-queue/
 
 */
class NumberofVisiblePeopleinaQueue {
    func canSeePersonsCount(_ heights: [Int] = [3,1,5,8,6]) -> [Int] {
        var result: [Int] = []
        for outerIndex in 0..<heights.count {
            var count = 0
            var maximum = 0
            for innerIndex in (outerIndex + 1)..<heights.count {
                if innerIndex == outerIndex + 1 {
                    count += 1
                    if heights[innerIndex] > heights[outerIndex] { break }
                    maximum = heights[innerIndex]
                } else {
                    
                    if heights[innerIndex] > maximum {
                        count += 1
                        maximum = max(maximum, heights[innerIndex])
                    }
                }
            }
            print("Count value is \(count)")
            result.append(count)
        }
        return result
    }
}


func multiply(_ num1: String, _ num2: String) -> String {
        let s1 = Array(num1).reversed()
        let s2 = Array(num2).reversed()
        var digits = Array(repeating: 0, count: num1.count + num2.count)

    for (index1, value1) in s1.enumerated() {
        for (index2, value2) in s2.enumerated() {
                let product = Int(String(value1))! * Int(String(value2))!
                let pos1 = index1 + index2
                let pos2 = pos1 + 1
                let sum = product + digits[pos2]

                digits[pos1] += sum / 10;
                digits[pos2] = (sum) % 10;
            }
        }

        // slower due to 3 separate passes over the array
        // let result = digits.reduce([], {(partial, val) in partial.isEmpty && val == 0 ? partial : partial + [val]}).map{String($0)}.joined()
        var result = ""
        for val in digits {
            if !(result.isEmpty && val == 0) {
                result.append(String(val))
            }
        }

        return result.isEmpty ? "0" : result
    }

