//
//  Valid Parenthesis String.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/23/21.
//

import Foundation

class ValidParenthesisString {
    
    func checkValidString(_ s: String = "((((()(()()()*()(((((*)()*(**(())))))(())()())(((())())())))))))(((((())*)))()))(()((*()*(*)))(*)()") -> Bool {
        var stack = [String]()
        var leftParenthesisStack = [String]()
        var rightParenthesisStack = [String]()
        for c in s {
            if c == "(" {
                stack.append("(")
                leftParenthesisStack.append("(")
                rightParenthesisStack.append("(")
            } else if c == ")" {
                if stack.isEmpty && leftParenthesisStack.isEmpty && rightParenthesisStack.isEmpty {
                    return false
                }
                if !stack.isEmpty {
                    stack.removeLast()
                }
                if !leftParenthesisStack.isEmpty {
                    leftParenthesisStack.removeLast()
                }
                if !rightParenthesisStack.isEmpty {
                    rightParenthesisStack.removeLast()
                }
            } else {
                leftParenthesisStack.append("(")
                if !rightParenthesisStack.isEmpty {
                    rightParenthesisStack.removeLast()
                }
            }
        }
        return stack.isEmpty || leftParenthesisStack.isEmpty || rightParenthesisStack.isEmpty
    }
}

