//
//  Find the Celebrity.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/22/21.
//

import Foundation

//https://leetcode.com/problems/find-the-celebrity/
/*
 Example 1:


 Input: graph = [[1,1,0],[0,1,0],[1,1,1]]
 Output: 1
 Explanation: There are three persons labeled with 0, 1 and 2. graph[i][j] = 1 means person i knows person j, otherwise graph[i][j] = 0 means person i does not know person j. The celebrity is the person labeled as 1 because both 0 and 2 know him but 1 does not know anybody.
 Example 2:


 Input: graph = [[1,0,1],[1,1,0],[0,1,1]]
 Output: -1
 Explanation: There is no celebrity.
  

 Constraints:

 n == graph.length
 n == graph[i].length
 2 <= n <= 100
 graph[i][j] is 0 or 1.
 graph[i][i] == 1

 */

class Relation {
    func knows(_ a: Int, _ b: Int) -> Bool {
        true
    }
}
/**
 * The knows API is defined in the parent class Relation.
 *     func knows(_ a: Int, _ b: Int) -> Bool;
 */
// This answer is correct, only Time complexity is high
class FindTheCelebrity : Relation {
    func findCelebrity(_ n: Int) -> Int {
        for index in 0..<n {
            var counter = 0
            for innerIndex in 0..<n {
                if index ==  innerIndex { continue }
                if knows(index, innerIndex) { break }
                else {
                    if knows(innerIndex, index) {
                        counter += 1
                    }
                    if counter == n - 1 {
                        return index
                    }
                }
            }
        }
        return -1
    }
}

