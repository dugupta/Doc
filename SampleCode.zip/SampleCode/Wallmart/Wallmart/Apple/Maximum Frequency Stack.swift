//
//  Maximum Frequency Stack.swift
//  Wallmart
//
//  Created by Durgesh Lal on 8/29/21.
//

import Foundation
/*
 /// https://leetcode.com/problems/maximum-frequency-stack/
 
 Example 1:

 Input
 ["FreqStack", "push", "push", "push", "push", "push", "push", "pop", "pop", "pop", "pop"]
 [[], [5], [7], [5], [7], [4], [5], [], [], [], []]
 Output
 [null, null, null, null, null, null, null, 5, 7, 5, 4]

 Explanation
 FreqStack freqStack = new FreqStack();
 freqStack.push(5); // The stack is [5]
 freqStack.push(7); // The stack is [5,7]
 freqStack.push(5); // The stack is [5,7,5]
 freqStack.push(7); // The stack is [5,7,5,7]
 freqStack.push(4); // The stack is [5,7,5,7,4]
 freqStack.push(5); // The stack is [5,7,5,7,4,5]
 freqStack.pop();   // return 5, as 5 is the most frequent. The stack becomes [5,7,5,7,4].
 freqStack.pop();   // return 7, as 5 and 7 is the most frequent, but 7 is closest to the top. The stack becomes [5,7,5,4].
 freqStack.pop();   // return 5, as 5 is the most frequent. The stack becomes [5,7,4].
 freqStack.pop();   // return 4, as 4, 5 and 7 is the most frequent, but 4 is closest to the top. The stack becomes [5,7].
 
 */
class FreqStack {
    typealias Value = (count: Int, index: [Int])
    var stack: [Int: Value] = [:]
    var index = -1
    init() {
        
    }
    
    func push(_ val: Int) {
        index += 1
        if let item = stack[val] {
            let count = item.count + 1
            let newIndex = item.index + [index]
            stack[val] = (count, newIndex)
        } else {
            stack[val] = (1, [index])
        }
    }
    
    func pop() -> Int {
        
        var sorted = stack.sorted(by: { $0.value.index.last! > $1.value.index.last! })
        sorted = sorted.sorted(by: { $0.value.count > $1.value.count})
        
        let firstObject = sorted.first!
        let key = firstObject.key
        let decreaseCount = firstObject.value.count - 1
        var decreaseIndex = firstObject.value.index
        decreaseIndex.removeLast()
        if decreaseCount == 0 {
            stack.removeValue(forKey: key)
        } else {
            stack[key] = (decreaseCount, decreaseIndex)
        }
        
        return firstObject.key
    }
    
    static func test() {
        let stack = FreqStack()
        stack.push(5)
        stack.push(7)
        stack.push(5)
        stack.push(7)
        stack.push(4)
        stack.push(5)
        var value = stack.pop()
        value = stack.pop()
        value = stack.pop()
    }
}

/**
 * Your FreqStack object will be instantiated and called as such:
 * let obj = FreqStack()
 * obj.push(val)
 * let ret_2: Int = obj.pop()
 */
