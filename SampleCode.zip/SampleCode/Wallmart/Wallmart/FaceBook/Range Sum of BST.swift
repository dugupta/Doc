//
//  Range Sum of BST.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/24/21.
//

import Foundation
//https://leetcode.com/problems/range-sum-of-bst/

/*
 Input: root = [10,5,15,3,7,null,18], low = 7, high = 15
 Output: 32
 Explanation: Nodes 7, 10, and 15 are in the range [7, 15]. 7 + 10 + 15 = 32.
 
 Input: root = [10,5,15,3,7,13,18,1,null,6], low = 6, high = 10
 Output: 23
 Explanation: Nodes 6, 7, and 10 are in the range [6, 10]. 6 + 7 + 10 = 23.
 
 */


extension RangeSumofBST.TreeNode {
    func traverse(_ level: Int, _ visit:(_ level: Int, _ value: Int) -> Void) {
        self.left?.traverse(level - 1, visit)
        visit(level, val)
        self.right?.traverse(level + 1, visit)
    }
    
    func traverse(_ level: Int, _ secondLevel: Int, _ visit:(_ level: Int,_ secondLevel: Int, _ value: Int) -> Void) {
        self.left?.traverse(level - 1, secondLevel + 1, visit)
        visit(level, secondLevel, val)
        self.right?.traverse(level + 1, secondLevel + 1, visit)
    }
    
}



class RangeSumofBST {
    
    public class TreeNode {
        public var val: Int
        public var left: TreeNode?
        public var right: TreeNode?
        public init() { self.val = 0; self.left = nil; self.right = nil; }
        public init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
        public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
            self.val = val
            self.left = left
            self.right = right
        }
    }
    
    func rangeSumBST(_ root: TreeNode?, _ low: Int, _ high: Int) -> Int {
        if root == nil { return 0 }
        var result: Int = 0
        root?.traverseInOrder {
             if $0 >= low && $0 <= high {
                result += $0
            }
        }
        
        return result
    }
    
    func verticalTraversal(_ root: TreeNode?) -> [[Int]] {
        var memory:[Int: [Int]] = [:]
        
        root?.traverse(0) { (level, item) in
            memory[level, default:[]].append(item)
        }
        
        print("Memory is \(memory)")
        
        let sorted = memory.sorted { itemOne, itemTwo in
            itemOne.key < itemTwo.key
        }
        print("sorted is \(sorted)")
        return []
    }
    
    func verticalTraversal2(_ root: TreeNode?) -> [[Int]] {
            var result = [[Int]]()
            var xToNodes = [Int: [(y: Int, val: Int)]]()
            root?.traverse(0,0) { (first, second, item) in
                xToNodes[first, default: []].append((y: second, val: item))
            }
            
            // iterate over sorted Xs
            let sorted = xToNodes.sorted(by: { (one, two) in
                            one.key < two.key
                        })
            print("Durgesh : sorted \(sorted)")
            
            for item in sorted {
                let valueSorted = item.value.sorted(by: { (itemOne, itemTwo) in
                    itemOne.y < itemTwo.y
                })
                var temp: [Int] = []
                
                for item in valueSorted {
                    temp.append(item.val)
                }
                result.append(temp)
            }
        
        let array = [[1], [3, 2], [5, 3, 9]]
        for item in array {
            let sortArray = item.sorted()
        }
            
            return result
        }
}

extension RangeSumofBST.TreeNode {
    func traverseInOrder(visit: (Int) -> Void) {
        left?.traverseInOrder(visit: visit)
        visit(val)
        right?.traverseInOrder(visit: visit)
    }
}


func addBinary(_ a: String, _ b: String) -> String {
        let max = max(a.count, b.count)
        var result: [Character] = []
        var arrayA: [Character] = Array(repeating: "0", count: max - a.count) + Array(a)
        var arrayB: [Character] = Array(repeating: "0", count: max - b.count) + Array(b)
        var carry: Int = 0
        while !arrayA.isEmpty {
            if let lastA = arrayA.last, let lastB = arrayB.last {
            let sum = Int(String(lastA))! + Int(String(lastB))! + carry
            print("Sum is \(sum)")
            if sum > 1 {
                carry = 1
                result.insert(sum == 3 ? "1" : "0", at: 0)
            } else {
                carry = 0
                result.insert(contentsOf: "\(sum)", at: 0)
            }
            arrayA.removeLast()
            arrayB.removeLast()
          }
        }
        
        if carry > 0 {
            result.insert("1", at: 0)
        }
        return String(result)
    }

