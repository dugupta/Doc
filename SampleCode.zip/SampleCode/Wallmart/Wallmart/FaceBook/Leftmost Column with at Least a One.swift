//
//  Leftmost Column with at Least a One.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/17/21.
//

import Foundation
//https://leetcode.com/problems/leftmost-column-with-at-least-a-one/
/*
Example 1:

Input: mat = [[0,0],[1,1]]
Output: 0

 
 Input: mat = [[0,0,0,1],[0,0,1,1],[0,1,1,1]]
 Output: 1
 
 Input: mat = [[0,0],[0,0]]
 Output: -1
 
 
 */

class BinaryMatrix {
    func get(_ row: Int, _ col: Int) -> Int {
        1
    }
    func dimensions() -> [Int] {
        [2]
    }
}

class LeftmostColumnwithatLeastaOne {
    func leftMostColumnWithOne(_ binaryMatrix: BinaryMatrix) -> Int {
        let rowCol = binaryMatrix.dimensions()
        let row = rowCol[0]
        let col = rowCol[1]
        var result = Int.max
        var i = 0
        while i < row {
            for j in stride(from: col-1, through: 0, by: -1) {
                if j < result {
                    if binaryMatrix.get(i,j) == 1 {
                        result = min(result, j)
                    } else {
                        break
                    }
                }
            }
            i += 1
        }
        
        return result == Int.max ? -1 : result
    }
}
