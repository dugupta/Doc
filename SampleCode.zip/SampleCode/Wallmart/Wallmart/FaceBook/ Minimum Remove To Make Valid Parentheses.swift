//
//   Minimum Remove To Make Valid Parentheses.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/17/21.
//

import Foundation
//https://leetcode.com/problems/minimum-remove-to-make-valid-parentheses/
/*
 
 Input: s = "lee(t(c)o)de)"
 Output: "lee(t(c)o)de"
 Explanation: "lee(t(co)de)" , "lee(t(c)ode)" would also be accepted.
 
 
 Input: s = "a)b(c)d"
 Output: "ab(c)d"
 
 
 Input: s = "))(("
 Output: ""
 Explanation: An empty string is also valid.
 
 
 Input: s = "(a(b(c)d)"
 Output: "a(b(c)d)"
 
 
 */
class MinimumRemoveToMakeValidParentheses {
    func minRemoveToMakeValid(_ s: String = "))((") -> String {
        var arr = Array(s)
        var stack: [Int] = []
        
        for (index, character) in arr.enumerated() {
            if character == "(" {
                stack.append(index)
            } else if character == ")" {
                if !stack.isEmpty {
                    stack.removeLast()
                } else {
                    arr[index] = "*"
                }
            }
        }
        while !stack.isEmpty {
            let index = stack.removeLast()
            arr[index] = "*"
        }
        return String(arr).replacingOccurrences(of: "*", with: "")
    }
}


