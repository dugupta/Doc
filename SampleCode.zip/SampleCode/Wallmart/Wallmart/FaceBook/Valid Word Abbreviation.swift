//
//  Valid Word Abbreviation.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/16/21.
//

import Foundation

struct ValidWordAbbreviation {
    func validWordAbbreviation(_ word: String = "cccc", _ abbr: String = "c2ca") -> Bool {
        if abbr.count > word.count { return false }
        var abbrArray = Array(abbr)
        var input = Array(word)
        
        var digits = ""
        for char in abbrArray {
            if char.isASCII && char.isNumber {
                digits += "\(char)"
            } else {
                if digits.isEmpty {
                    if let first = input.first {
                        if first == char {
                            input.removeFirst()
                        }
                    }
                } else {
                    let count = Int(digits)!
                    digits = ""
                    input = Array(input[count...])
                    if input.isEmpty { return false }
                    if let first = input.first {
                        if first == char {
                            input.removeFirst()
                        }
                    }
                }
            }
        }
        if let found = Int(digits) {
            return input.count == found
        }
        return input.isEmpty
        
    }
}
