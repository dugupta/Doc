//
//  Missing Ranges.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/27/21.
//

import Foundation

/*
 ///https://leetcode.com/problems/missing-ranges/
 */

struct MissingRange {
    func findMissingRanges(_ nums: [Int] = [-1], _ lower: Int = -1, _ upper: Int = -1) -> [String] {
        
        var missing : [Int] = []
        for index in lower...upper {
            if let found = nums.firstIndex(where: { $0 == index }) {
                continue
            } else {
                missing.append(index)
            }
        }
        
        print("All missing \(missing)")
        var result : [String] = []
        var stack: [Int] = []
        for (index, item) in missing.enumerated() {
            if item == 99 {
                print("Item is 76")
            }
            if let last = stack.last {
                if item - last > 1 {
                    if stack.count == 1 {
                        result.append("\(stack[0])")
                    } else {
                        result.append("\(stack[0])->\(stack.last!)")
                    }
                    stack = []
                    stack.append(item)
                } else {
                    stack.append(item)
                }
            } else {
                stack.append(item)
            }
        }
        if stack.count == 1 {
            result.append("\(stack[0])")
        } else {
           // result.append("\(stack[0])->\(stack.last!)")
        }
        return result
    }
}
