//
//  Is Graph Bipartite?.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/16/21.
//

import Foundation

struct GraphBipartite {
    func isBipartite(_ graph: [[Int]] = [[1,2,3],[0,2],[0,1,3],[0,2]]) -> Bool {
        
        var visited = Array(repeating: 0, count: graph.count)
        for i in 0..<graph.count{
            if 0 == visited[i] {
                //let res = dfs(i ,graph, &visited)
                let res = bfs(i ,graph, &visited)
                if !res {
                    return false
                }
            }
        }
        return true
    }
    
    func bfs(_ node:Int, _ graph:[[Int]], _ visited:inout[Int])->Bool{
        var queue:[Int] = []
        queue.append(node)
        visited[node] = 1
        
        while !queue.isEmpty {
            let item = queue.removeFirst()
            for child in graph[item]{
                if visited[child] == 0 {
                    visited[child] = visited[item] == 1 ? 2 : 1
                    queue.append(child)
                }else{
                    if visited[child] == visited[item] { return false }
                }
            }
        }
        return true
    }
    
    func dfs(_ node:Int, _ graph:[[Int]], _ visited:inout[Int],_ parent:Int? = nil)->Bool{
        if parent == nil {
            visited[node] = 1
        }
        for child in graph[node]{
            if visited[child] == 0{
                visited[child] = visited[node] == 1 ? 2 : 1
                if !dfs(child, graph, &visited, node) {
                    return false
                }
            }else{
                if visited[child] == visited[node] { return false }
            }
        }
        return true
    }
}

