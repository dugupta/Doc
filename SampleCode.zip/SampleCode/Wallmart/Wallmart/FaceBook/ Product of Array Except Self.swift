//
//   Product of Array Except Self.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/18/21.
//

import Foundation
//https://leetcode.com/problems/product-of-array-except-self/

/*
 Example 1:

 Input: nums = [1,2,3,4]
 Output: [24,12,8,6]
 Example 2:

 Input: nums = [-1,1,0,-3,3]
 Output: [0,0,9,0,0]
 
 */
class  ProductofArrayExceptSelf {
    /*
    func productExceptSelf(_ nums: [Int]) -> [Int] {
        var retValue: [Int] = []
        
        for (index, _) in nums.enumerated() {
            var input = nums
            input.remove(at: index)
            retValue.append(input.reduce(1, { $0 * $1 }))
        }
        return retValue
    }
 */
    
    func productExceptSelf(_ nums: [Int] = [4, 5, 1, 8, 2, 10, 6]) -> [Int] {
        var left: [Int] = []
        var right: [Int] = []
        var result: [Int] = []
        
        for (index, item) in nums.enumerated() {
            if index == 0 { left.append(1); continue }
            left.append(nums[index - 1] * left[index - 1])
        }
        
        for index in stride(from: nums.count - 1, through: 0, by: -1) {
            if index == nums.count - 1 { right.append(1); continue }
            right.insert(nums[index + 1] * right.first!, at: 0)
        }
        
        for index in 0..<nums.count {
            result.append(left[index] * right[index])
        }
        
        return result
    }
}
