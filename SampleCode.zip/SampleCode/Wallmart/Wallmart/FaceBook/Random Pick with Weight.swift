//
//  Random Pick with Weight.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/25/21.
//

import Foundation

struct RandomPickwithWeight {
    var acc: [Int]
    init(_ w: [Int]) {
        self.acc = w
        for i in 1..<w.count {
            self.acc[i] += self.acc[i - 1]
        }
    }
    
    func pickIndex() -> Int {
        let rand = Int.random(in: 1...acc.last!)
        var start = 0
        var end = acc.count - 1
        while start < end {
            //let mid = (start + end) >> 1
            let mid = Int(floor(Double(start + end) / 2.0))
            acc[mid] < rand ? (start = mid + 1) : ( end = mid)
        }
        return start
    }
}
