//
//  Continuous Subarray Sum.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/18/21.
//

import Foundation

class ContinuousSubarraySum {
    /*
    func checkSubarraySum(_ nums: [Int] = [23,2,4,6,6], _ k: Int = 7) -> Bool {
        var cache: [Int: Int] = [0 : 1]
        var sum: Int = 0
        
        for index in 0..<nums.count {
            sum += nums[index]
            if let val = cache[sum - k] {
                return true
            }
            
            if let val = cache[sum] {
                cache[sum] = val + 1
            } else {
                cache[sum] = 1
            }
        }
        
        return false
    }
    */
    ///https://leetcode.com/problems/continuous-subarray-sum/submissions/
    func checkSubarraySum(_ nums: [Int] = [23,2,4,6,6], _ k: Int = 7) -> Bool {
        var map : [Int: Int] = [0 : -1]
        var sum = 0
        
        for (index, item) in nums.enumerated() {
            sum += item
            
            if k != 0 { sum = sum % k}
            
            if 0 == map[sum] {
                return true
            } else {
                map[sum] = index
            }
        }
        return false
    }
}
