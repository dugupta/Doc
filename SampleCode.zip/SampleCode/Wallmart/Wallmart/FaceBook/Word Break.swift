//
//  Word Break.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/28/21.
//

import Foundation

/*
 https://leetcode.com/problems/word-break/
 Example 1:

 Input: s = "leetcode", wordDict = ["leet","code"]
 Output: true
 Explanation: Return true because "leetcode" can be segmented as "leet code".
 Example 2:

 Input: s = "applepenapple", wordDict = ["apple","pen"]
 Output: true
 Explanation: Return true because "applepenapple" can be segmented as "apple pen apple".
 Note that you are allowed to reuse a dictionary word.
 Example 3:

 Input: s = "catsandog", wordDict = ["cats","dog","sand","and","cat"]
 Output: false
 
 */
struct WordBreak {
    func wordBreak(_ s: String, _ wordDict: [String]) -> Bool {
        return true
    }
}
