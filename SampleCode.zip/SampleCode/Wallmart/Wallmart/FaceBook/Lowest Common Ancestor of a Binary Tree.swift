//
//  Lowest Common Ancestor of a Binary Tree.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/24/21.
//

import Foundation
//https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree-iii/
/*
 Input: root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 1
 Output: 3
 Explanation: The LCA of nodes 5 and 1 is 3.
 
 Input: root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 4
 Output: 5
 Explanation: The LCA of nodes 5 and 4 is 5 since a node can be a descendant of itself according to the LCA definition.
 
 */
class LowestCommonAncestorofBinaryTree {
    
    public class Node {
        public var val: Int
        public var left: Node?
        public var right: Node?
        public var parent: Node?
        public init(_ val: Int) {
            self.val = val
            self.left = nil
            self.right = nil
            self.parent = nil
        }
    }

    
    func lowestCommonAncestor(_ p: Node?,_ q: Node?) -> Node? {
        var array: [Int: Node] = [:]
        var counter = 1
        var retValue: Node? = nil
        p?.traverse {
            print("Priniting for p \($0?.val)")
            if let node = $0 {
                 array[node.val] =  node
            }
        }
        
        var current = q
        while let value = current {
            if array[value.val] != nil {
                return value
            } else {
                current = current?.parent
            }
        }
        
        print("Let resturn something")
        return retValue
    }
}

extension LowestCommonAncestorofBinaryTree.Node {
    func traverse(visit: (LowestCommonAncestorofBinaryTree.Node?) -> Void) {
        visit(self)
        parent?.traverse(visit: visit)
    }
}
