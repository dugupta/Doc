//
//  Exclusive Time of Functions.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/18/21.
//

import Foundation
/*
 ///https://leetcode.com/problems/exclusive-time-of-functions/
 */
struct ExclusiveTimeofFunctions {
    func exclusiveTime(_ n: Int = 2, _ logs: [String] = ["0:start:0","0:start:2","0:end:5","1:start:6","1:end:6","0:end:7"]) -> [Int] {
        var stack = [Int]()
        var res = Array(repeating: 0, count: n)
        var startTime = 0
        for log in logs {
            let data = log.split(separator: ":")
            let id = Int(data[0])!, op = data[1], time = Int(data[2])!
            switch op {
            case "start":
                if !stack.isEmpty {
                    res[stack.last!] += time - startTime - 1
                }
                stack.append(id)
                startTime = time
            case "end":
                res[stack.last!] += time - startTime + 1
                stack.removeLast()
                startTime = time
            default:
                break
            }
        }
        return res
    }
}


func accountsMerge(_ accounts: [[String]]) -> [[String]] {
    var cache: [String : [[String]]] = [:]
    
    for account in accounts {
        if let found = cache[account.first!] {
            var emailArray = found
            
            for (index, email) in emailArray.enumerated() {
                let match = account.filter(email.contains)
                if match.count > 0 {
                    let temp = Array(Set(email + account))
                    emailArray[index] = temp
                    cache[account.first!] = emailArray
                    break
                }
                
                if index == (emailArray.count - 1) {
                    var modifiedAccount = account
                    modifiedAccount.removeFirst()
                    emailArray.append(modifiedAccount)
                    cache[account.first!] = emailArray
                }
            }
        } else {
            var temp = account
            temp.removeFirst()
            cache[account.first!] = [temp]
        }
    }
    
    var result: [[String]] = []
    
    for item in cache {
        for single in item.value {
            var array: [String] = [item.key]
            array += single.sorted(by: < )
            result.append(array)
        }
    }
    return result
}
