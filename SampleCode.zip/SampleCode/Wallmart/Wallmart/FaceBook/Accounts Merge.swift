//
//  Accounts Merge.swift
//  Wallmart
//
//  Created by Durgesh Lal on 10/16/21.
//

import Foundation


struct AccountsMerge {
    
    func addEdge(_ graph: inout [String: [String]], _ from: String, _ to: String) {
        graph[from, default: []].append(to)
    }
    
    func dfs(_ graph: inout [String: [String]], _ source: String, _ visited: inout Set<String>, _ currentSet: inout Set<String>) {
        visited.insert(source)
        currentSet.insert(source)
        
        for neighbour in graph[source] ?? [] {
            if !visited.contains(neighbour) {
                dfs(&graph, neighbour, &visited, &currentSet)
            }
        }
    }
    
    func accountsMerge(_ accounts: [[String]] = [["David","David0@m.co","David1@m.co"],["David","David3@m.co","David4@m.co"],["David","David4@m.co","David5@m.co"],["David","David2@m.co","David3@m.co"],["David","David1@m.co","David2@m.co"]]) -> [[String]] {
        
        
        
        var graph: [String : [String]] = [:]
        var emailToName: [String : String] = [:]
        
        for account in accounts {
            let name = account[0]
            let firstEmail = account[1]
            let emails = account.dropFirst()
            
            for email in emails {
                addEdge(&graph, firstEmail, email)
                addEdge(&graph, email, firstEmail)
                emailToName[email] = name
            }
        }
        
        
        var visited = Set<String>()
        var result = [[String]]()
        
        for (key, _) in graph {
            var currentSet = Set<String>()
            if !visited.contains(key) {
                dfs(&graph, key, &visited, &currentSet)
            }
            if currentSet.count > 0 {
                let currentEmails = Array(currentSet)
                var currentResult = [emailToName[currentEmails[0]]!]
                currentResult += currentEmails.sorted()
                result.append(currentResult)
            }
        }
        
        return result
        
        /*
        var memory: [String: Int] = [:]
        var users: [String] = []
        for (index, account) in accounts.enumerated() {
            var tempDict: [String: Int] = [:]
            for email in 1..<account.count {
                if let found = memory[account[email]] {
                    for foundEmail in 1..<account.count {
                        memory[account[foundEmail]] = found
                    }
                    tempDict = [:]
                    break
                } else {
                    tempDict[account[email]] = index
                }
            }
            var shouldAddUser = true
            tempDict.forEach { (k,v) in
                print("Value is \(account)")
                if shouldAddUser {
                    users.append(account[0])
                    shouldAddUser = false
                }
                
                memory[k] = v
            }
            if tempDict.isEmpty {
                users.append("")
            }
        }
        var result: [[String]] = Array(repeating:[], count: users.count)
        
        for (key, value) in memory.enumerated() {
            print("key is \(value.key) and value is \(value.value)")
            let index = value.value
            result[index].append(value.key)
        }
        
        for (index, name) in users.enumerated() {
            result[index] = [name] + result[index].sorted()
        }
        var tempResult: [[String]] = []
        
        for item in result {
            if item.count != 1 {
                tempResult.append(item)
            }
        }
        print("result \(tempResult)")
        return tempResult
         */
    }
}

