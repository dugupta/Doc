//
//  Valid Number.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/25/21.
//

import Foundation
//https://leetcode.com/problems/valid-number/submissions/


struct ValidNumber {
    func isNumber(_ s: String = "inf") -> Bool {
        if let value = Double(s)  {
            return true
        } else {
            return false
        }
    }
    
    //https://leetcode.com/problems/string-to-integer-atoi/
    
    func myAtoi(_ s: String) -> Int {
        var result = ""
        let firstElement = "\(Array(s.replacingOccurrences(of: " ", with: ""))[1])"
        let intValue = Int(firstElement)
        
        if firstElement != "-" {
            if intValue == nil {
                return 0
            }
        }
        s.forEach { item in
            if item == "-" { result.append(item) }
            if let unwraped = Int(String(item)) {
                result.append(item)
            }
        }
        if let value = Int(result) {
            return value
        } else {
            return -1
        }
    }
    
}

