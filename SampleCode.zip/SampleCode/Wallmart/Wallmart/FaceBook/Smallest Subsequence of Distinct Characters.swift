//
//  Smallest Subsequence of Distinct Characters.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/22/21.
//

import Foundation
/*
 ///https://leetcode.com/problems/smallest-subsequence-of-distinct-characters/
 */


struct SmallestSubsequenceOfDistinctCharacters {
    
    func removeDuplicateLetters(_ s: String = "cbacdcbc") -> String {
        let ref = Character("a").ascii
        var counts = [Int](repeatElement(0, count: 26))
        var visited = [Bool](repeatElement(false, count: 26))
        var stack = [Character]()
        
        for char in s {
            print("[char.ascii - ref] \([char.ascii - ref])")
            counts[char.ascii - ref] += 1
        }
        
        for char in s {
            let ascii = char.ascii - ref
            counts[ascii] -= 1
            if visited[ascii] {
                continue
            }
            
            while(stack.count > 0 && stack.last! > char
                    && counts[stack.last!.ascii - ref]  > 0) {
                var last = stack.removeLast()
                visited[last.ascii - ref] = false
            }
            
            stack.append(char);
            visited[ascii] = true
        }
        
        return stack.reduce("") { $0 + String($1) }
    }
}

extension Character {
    var ascii: Int {
        return Int(unicodeScalars.first!.value)
    }
}
