//
//  Construct Binary Tree from Inorder and Postorder Traversal.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/29/21.
//

import Foundation

class ConstructBinaryTreefromInorderandPostorderTraversal {
    
    class TreeNode {
        var val: Int
        var left: TreeNode?
        var right: TreeNode?
        init() { self.val = 0; self.left = nil; self.right = nil; }
        init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
        init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
            self.val = val
            self.left = left
            self.right = right
        }
    }
    
    var postOrderIndex = 0
        
    func buildTree(_ inorder: [Int] = [9,3,15,20,7], _ postorder: [Int] = [9,15,7,20,3]) -> TreeNode? {
        var inOrderIndexDict = [Int: Int]()
        for (index, item) in inorder.enumerated() {
            inOrderIndexDict[item] = index
        }
        postOrderIndex = postorder.count - 1
        return buildTree(postorder, 0, inorder.count - 1, inOrderIndexDict)
    }


    func buildTree(_ postorder: [Int], _ left: Int, _ right: Int, _ preOrderIndexMemory: [Int :Int]) -> TreeNode? {
        guard left <= right else { return nil }
        
        let rootIndex = preOrderIndexMemory[postorder[postOrderIndex]]!
        let rootVal = postorder[postOrderIndex]
        postOrderIndex -= 1
        
        let rightTree = buildTree(postorder, rootIndex + 1, right, preOrderIndexMemory)
        let leftTree = buildTree(postorder, left, rootIndex - 1, preOrderIndexMemory)
        return TreeNode(rootVal, leftTree, rightTree)
    }
    
}



