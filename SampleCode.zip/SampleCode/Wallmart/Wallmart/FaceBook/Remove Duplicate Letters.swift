//
//  Remove Duplicate Letters.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/30/21.
//

import Foundation

class RemoveDuplicateLetters {
    
    func removeDuplicateLetters(_ s: String = "cbacdcbc") -> String {
        //var input = Array(s)
        var visited: [Character: Bool] = [:]
        
        let ref = Character("a").ascii
        var ascii: [Character: Int] = [:]
        var input: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","u","v","w","x","y","z"]
        
        for item in input {
            visited[item, default: false] = false
            ascii[item, default:0] = item.ascii
        }
        
        var stack: [Character] = []
        
        var characterInput = Array(s)
        
        var counter: [Character: Int] = [:]
        for item in characterInput {
            counter[item, default: 0] += 1
        }
        
        for item in characterInput {
            print("Character is \(item)")
            func append() {
                //Add item in stack
                stack.append(item)
                //update status in visted
                visited[item] = true
                //Update counter value
                
                if var counterValue = counter[item] {
                    counterValue -= 1
                    if counterValue == 0 {
                        counter[item] = nil
                    }
                }
            }
            
            if visited[item] ?? false {
                print("Visited value \(item)")
                continue
            }
            if let top = stack.last {
                //If current element is samller than, top. Rome top if already have element in the string using counter dictionary
                if ascii[item]! < ascii[top]! {
                     if var counterValue = counter[top] {
                         if counterValue > 0 {
                             stack.removeLast()
                             visited[top] = false
                             counterValue -= 1
                             counter[top] = counterValue
                             if counterValue == 0 {
                                counter[top] = nil
                            }
                           append()
                            
                         } else {
                             visited[top] = true
                             counter[top] = nil
                         }
                     } else {
                        append()
                     }
                } else {
                    append()
                }
            } else {
                append()
            }
        }
        return String(stack)
    }
}
