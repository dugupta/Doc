//
//  Lowest Common Ancestor of Deepest Leaves.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/23/21.
//

import Foundation

struct LowestCommonAncestorofDeepestLeaves {
    class TreeNode {
        var val: Int
        var left: TreeNode?
        var right: TreeNode?
        init() { self.val = 0; self.left = nil; self.right = nil; }
        init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
        init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
            self.val = val
            self.left = left
            self.right = right
        }
    }
    
    func lcaDeepestLeaves(_ root: TreeNode?) -> TreeNode? {
        let result = getDepth(root).node
        return result
    }
    
    func getDepth(_ node: TreeNode?) -> (node: TreeNode?,depth: Int) {
        print("Node details \(node?.val) left \(node?.left?.val) right \(node?.right?.val) ")
        guard let root = node else {
            return (node, 0)
        }
        let left = getDepth(root.left)
        //print("Left value is \(left.node?.val) and depth \(left.depth)")
        let right = getDepth(root.right)
        //print("Right value is \(right.node?.val) and depth \(right.depth)")
        if left.depth == right.depth {
            return (root, left.depth + 1)
        } else if left.depth > right.depth {
            return (left.node, left.depth + 1)
        }
        return (right.node, right.depth + 1)
    }
    
    static func test() {
        let seven = LowestCommonAncestorofDeepestLeaves.TreeNode(7)
        let four = LowestCommonAncestorofDeepestLeaves.TreeNode(4)
        let two = LowestCommonAncestorofDeepestLeaves.TreeNode(2, seven, four)
        let six = LowestCommonAncestorofDeepestLeaves.TreeNode(6)
        let five = LowestCommonAncestorofDeepestLeaves.TreeNode(5, six, two)
        
        let zero = LowestCommonAncestorofDeepestLeaves.TreeNode(0)
        let eight = LowestCommonAncestorofDeepestLeaves.TreeNode(8)
        let one = LowestCommonAncestorofDeepestLeaves.TreeNode(1, zero, eight)
        
        let three = LowestCommonAncestorofDeepestLeaves.TreeNode(3, five, one)
        
        let result = LowestCommonAncestorofDeepestLeaves().lcaDeepestLeaves(three)
        print("Result is \(result)")
    }
}
