//
//  Verifying an Alien Dictionary.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/17/21.
//

import Foundation
//https://leetcode.com/problems/verifying-an-alien-dictionary/

/*
 Input: words = ["hello","leetcode"], order = "hlabcdefgijkmnopqrstuvwxyz"
 Output: true
 Explanation: As 'h' comes before 'l' in this language, then the sequence is sorted.
 
 Input: words = ["word","world","row"], order = "worldabcefghijkmnpqstuvxyz"
 Output: false
 Explanation: As 'd' comes after 'l' in this language, then words[0] > words[1], hence the sequence is unsorted.
 
 Input: words = ["apple","app"], order = "abcdefghijklmnopqrstuvwxyz"
 Output: false
 Explanation: The first three characters "app" match, and the second string is shorter (in size.) According to lexicographical rules "apple" > "app", because 'l' > '∅', where '∅' is defined as the blank character which is less than any other character (More info).
 */

class VerifyingAlienDictionary {
    func isAlienSorted(_ words: [String] = ["apple","app"], _ order: String = "abcdefghijklmnopqrstuvwxyz") -> Bool {
        
        var scale: [Character: Int] = [:]
        order.enumerated().forEach {
            scale[$0.element] = $0.offset
        }
        
        for index in 0..<words.count-1 {
            let left = words[index]
            let right = words[index+1]
            let minCount = min(left.count, right.count)
            for idx in 0..<minCount {
                if let lVal = scale[left[idx]], let rVal = scale[right[idx]] {
                    if lVal < rVal {
                        if right == words.last { return true }
                        break
                    } else if rVal < lVal {
                        return false
                    }
                }
            }
            
            if left.count > minCount { return false }
        }
        
        return true
    }
}

   
