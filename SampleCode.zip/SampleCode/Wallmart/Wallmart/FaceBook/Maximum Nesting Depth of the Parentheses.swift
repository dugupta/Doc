//
//  Maximum Nesting Depth of the Parentheses.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/25/21.
//

import Foundation

struct MaximumNestingDepthoftheParentheses {
    func maxDepth(_ s: String) -> Int {
        return -1
    }
}
