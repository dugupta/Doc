//
//  Making A Large Island.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/27/21.
//

import Foundation
/*
 https://leetcode.com/problems/making-a-large-island/
 Input: grid = [[1,0],[0,1]]
 Output: 3
 Explanation: Change one 0 to 1 and connect two 1s, then we get an island with area = 3.
 Example 2:

 Input: grid = [[1,1],[1,0]]
 Output: 4
 Explanation: Change the 0 to 1 and make the island bigger, only one island with area = 4.
 Example 3:

 Input: grid = [[1,1],[1,1]]
 Output: 4
 Explanation: Can't change any 0 to 1, only one island with area = 4.
 */
class MakingALargeIsland {
    
    func largestIsland(_ grid: [[Int]] = [[1,1],[1,1]]) -> Int {
        var maximum: Int = 0
        var newGrid = grid
        var zero: Bool = false
        for (indexOne, _) in grid.enumerated() {
            for (indexTwo, _) in grid[indexOne].enumerated() {
                //var newGrid = grid
                zero = grid[indexOne][indexTwo] == 0
                if zero {
                    newGrid[indexOne][indexTwo] = 1
                }
                maximum = max(maximum, gridArea(&newGrid, indexOne: indexOne, indexTwo: indexTwo))
                if zero {
                    newGrid[indexOne][indexTwo] = 0
                }
                
            }
        }
        return zero ? maximum + 1 : maximum
    }
    
    private func gridArea(_ grid: inout [[Int]], indexOne: Int, indexTwo: Int) -> Int {
        //Exit condition
        //Check for border
        //Check for water
        let rows = grid.count
        let column = grid.first?.count ?? 0
        if indexOne < 0 || indexTwo < 0 || indexOne >= rows || indexTwo >= column || grid[indexOne][indexTwo] == 0 {
            return 0
        }
        // Now we have a number
        // Find left, Right, Top and bottom and change 1 to zero to avoid going back and check that grid again
        // First make grid value to zero
        grid[indexOne][indexTwo] = 0
        let left = gridArea(&grid, indexOne: indexOne, indexTwo: indexTwo - 1)
        let right = gridArea(&grid, indexOne: indexOne, indexTwo: indexTwo + 1)
        let top = gridArea(&grid, indexOne: indexOne - 1, indexTwo: indexTwo)
        let bottom = gridArea(&grid, indexOne: indexOne + 1, indexTwo: indexTwo)
        
        return left + right + top + bottom + 1
    }
}
