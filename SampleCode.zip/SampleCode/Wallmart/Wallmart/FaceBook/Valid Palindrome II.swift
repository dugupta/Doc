//
//  Valid Palindrome II.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/17/21.
//

import Foundation

class ValidPalindrome2 {
    func valid(_ string: String, start: Int, end: Int) -> Bool {
        if string.isEmpty || string.count < 3 { return true }
        let array = Array(string)
        let arrayString = String(array[start...end])
        let stringArray = Array(arrayString)
        if stringArray.count == 2 {
            return stringArray.first! == stringArray.last!
        }
        for index in 0..<(stringArray.count / 2) {
            if stringArray[index] == stringArray[stringArray.count - (1 + index)] {
                continue
            } else {
                return false
            }
        }
        return true
    }
    
    func validPalindrome(_ s: String = "deeee") -> Bool {
        var subString = ""
        let arrayString = Array(s)
        for index in 0..<arrayString.count / 2 {
            if arrayString[index] == arrayString[arrayString.count - (1 + index)] {
                continue
            } else {
                subString = String(arrayString[index...(arrayString.count - index - 1)])
                break
            }
        }
    
        if valid(subString, start: 0, end: subString.count - 2) || valid(subString, start: 1, end: subString.count - 1) {
            return true
        } else {
            return false
        }
    }
    /*
    func validPalindrome(_ s: String = "fbpeusbqtwfdknryiphdboswzcckirmpxogobegmattvqmfrqcwyfbeykdtdsmzucsdotvapbzejobficllwsfzbmoqmkvcchowxgbhfbxydngxfhjgwdcwbnniqvnpclvgqpipoenbcriyrgqfvnmzkldkpikkknlzpiatsdddxzftivnebropbedfqndvjnrervxhlschmzntkykovxjbxyyjzclpegkzliitvdznndnydchxeynqkhbltsefapmzqoacizdcgvorrbwuxfigmnrufojaojhvepqltxkznkyyweyfuyfiedisixfiwkamdqsdyadoetumvefenfptmnjlddrmwpmjcndossrvhroedsrokzfjgsvjmxushokavvkbqglfzadlcsicizydcnjjzxzlqjtfofszauyqiteqlxhjszgemiwlymmjbpdwhdrotanjwgkaiznpscddsqpuoaugqggvkilgptsmpqhndcqsowhmcnyeyoeqwcalmzhhgnnwxtzfllyukitbttdwtselgqvdqmjuamxcvnesuioshewwhdpddrphwpkhplnxwvjysldvkrqhjlbitdwrxedhdxosuxuhnzbjrvzogetjwwvltvhvbzsyncjgemybtqynvphrvhwmtxcgecdztevqfoaweqxkpigfaysrhfhvemhivtuxnceaozrpdusicmmwkeqeimppudirboqfsnloyckdcdyoaaxquvhzqhpdgwzohizwvdaigbtshhzaeoufkytbyoztmgxjejresftmrbtyzlzgxwjhvkzxrijlaqaqsavjebosqisdywclyuqcmtatrbvtnwvbkwctrghzvsmgobqnpbxcnrzgthahmvprurfmexixmfgnkxeeeifbzroeixdowdfupbujqvyazwkvdxcuypehjhcycrhrihyzpfcvmlwtucdrjzrkacrpnyvektfnuvimoquelxhiabcjpzcbkkbczpjcbaihxleuqomivunftkevynprcakrzjrdcutwlmvcfpzyhirhrcychjhepyucxdvkwzayvqjubpufdwodxieorzbfieeexkngfmxixemfrurpvmhahtgzrncxbpnqbogmsvzhgrtcwkbvwntvbrtatmcquylcwydsiqsobejvasqaqaljirxzkvhjwxgzlzytbrmtfserjejxgmtzoybtykfuoeazhhstbgiadvwzihozwgdphqzhvuqxaaoydcdkcyolnsfqobriduppmieqekwmmcisudprzoaecnxutvihmevhfhrsyafgipkxqewaofqvetzdcegcxtmwhvrhpvnyqtbymegjcnyszbvhvtlvwwjtegozvrjbznhuxusoxdhdexrwdtibljhqrkvdlsyjvwxnlphkpwhprddpdhwwehsoiusenvcxmaujmqdvqglestwdtntbtikuyllfztxwnnghhzmlacwqeoyeyncmhwosqcdnhqpmstpglikvggqguaoupqsddcspnziakgwjnatordhwdpbjmmylwimegzsjhxlqetiqyuazsfoftjqlzxzjjncdyziciscldazflgqbkvvakohsuxmjvsgjfzkorsdeorhvrssodncjmpwmrddljnmtpfnefevmuteodaydsqdmakwifxisideifyufyewyyknzkxtlqpevhjoajofurnmgifxuwbrrovgcdzicaoqzmpafestlbhkqnyexhcdyndnnzdvtiilzkgeplczjyyxbjxvokyktnzmhcslhxvrernjvdnqfdebporbenvitfzxdddstaipzlnkkkipkdlkzmnvfqgryircbneopipqgvlcpnvqinnbwcdwgjhfxgndyxbfhbgxwohccvkmqombzfswllcifbojezbpavtodscuzmsdtdkyebfywcqrfmqvttamgebogoxpmrikcczwsobdhpiyrnkdfwtqbsuepbf") -> Bool {
        let input = s
        if input == String(s.reversed()) { return true }
        var iterate = Array(input)
        for (index, _) in iterate.enumerated() {
            var string = iterate
            string.remove(at: index)
            if String(string) == String(String(string).reversed()) {
                return true
            }
        }
        return false
    }
 */
}
