//
//  Remove Invalid Parentheses.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/25/21.
//

import Foundation

//https://leetcode.com/problems/remove-invalid-parentheses/

/*
 
 Example 1:

 Input: s = "()())()"
 Output: ["(())()","()()()"]
 
 Example 2:

 Input: s = "(a)())()"
 Output: ["(a())()","(a)()()"]
 
 Example 3:

 Input: s = ")("
 Output: [""]
 
 */
class RemoveInvalidParentheses {
   
    func solution(_ string: String, mra: Int, cache: inout [String : String], result: inout [String]) {
        let mra = mra
        if mra == 0 {
            if string.isValidParentheses {
                if cache[string] == nil {
                    cache[string] = string
                    result.append(string)
                }
            }
        }
        
        for index in 0..<string.count {
            var newString = string
            newString.remove(at: string.index(string.startIndex, offsetBy: index))
            solution(newString, mra: mra - 1, cache: &cache, result: &result)
        }
    }
    func removeInvalidParentheses(_ s: String = "()())()") -> [String] {
        var result: [String] = []
        var cache: [String : String] = [:]
        solution(s, mra: s.getMin, cache: &cache, result: &result)
        return result
        
    }
}

extension String {
    var isValidParentheses: Bool {
        var stack: [Character] = []
        self.forEach { char in
            if char == "(" {
                stack.append(char)
            } else if char == ")" {
                if stack.isEmpty {
                    stack.append(char)
                } else if stack.last == "(" {
                    stack.removeLast()
                } else {
                    stack.append(char)
                }
            }
        }
        return stack.isEmpty
    }
    
    var getMin: Int {
        var stack: [Character] = []
        self.forEach { char in
            if char == "(" {
                stack.append(char)
            } else {
                if stack.isEmpty {
                    stack.append(char)
                } else if stack.last == "(" {
                    stack.removeLast()
                } else {
                    stack.append(char)
                }
            }
        }
        return stack.count
    }
}
