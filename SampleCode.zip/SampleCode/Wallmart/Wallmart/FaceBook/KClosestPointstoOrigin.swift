//
//  KClosestPointstoOrigin.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/17/21.
//

import Foundation
//https://leetcode.com/problems/k-closest-points-to-origin/
/*
 Input: points = [[1,3],[-2,2]], k = 1
 Output: [[-2,2]]
 Explanation:
 The distance between (1, 3) and the origin is sqrt(10). // 1*1 + 3*3  = 10
 The distance between (-2, 2) and the origin is sqrt(8). // 2*2 + 2*2
 Since sqrt(8) < sqrt(10), (-2, 2) is closer to the origin.
 We only want the closest k = 1 points from the origin, so the answer is just [[-2,2]].
 
 Input: points = [[3,3],[5,-1],[-2,4]], k = 2
 Output: [[3,3],[-2,4]]
 Explanation: The answer [[-2,4],[3,3]] would also be accepted.
 
 
 */
class KClosestPointstoOrigin {
    struct Point {
        var points: [Int]
        var distance: Int
    }
    
    func kClosest(_ points: [[Int]] = [[1,3],[-2,2]], _ k: Int = 1) -> [[Int]] {
        var retValue: [Point] = []
        for point in points {
            print(point)
            let x: Int = point.first!
            let y: Int = point.last!
            let distance = x*x + y*y
            retValue.append(Point(points: point, distance: distance))
        }
        
        let sorted = retValue.sorted(by: { $0.distance < $1.distance })
        var result: [[Int]] = []
        for index in 0..<k {
            result.append(sorted[index].points)
        }
        return result
    }
}
