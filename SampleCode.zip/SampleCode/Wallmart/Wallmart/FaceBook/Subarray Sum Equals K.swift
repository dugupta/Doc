//
//  Subarray Sum Equals K.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/18/21.
//

import Foundation
//https://leetcode.com/problems/subarray-sum-equals-k/

/*
 Example 1:

 Input: nums = [1,1,1], k = 2
 Output: 2
 Example 2:

 Input: nums = [1,2,3], k = 3
 Output: 2
 
 Input: nums = [3, 6, 2, 6, 1, 1, 1, 1, 1, 1, -1, 2, 3, 2],  k = 5
 Output: 7
 
 */
class SubarraySumEqualsK {
    func subarraySum(_ nums: [Int] = [3, 6, 2, 6, 1, 1, 1, 1, 1, 1, -1, 2, 3, 2], _ k: Int = 5) -> Int {
        
        var cache: [Int : Int] = [0 : 1]
        var sum = 0
        var result = 0
        for item in nums {
            sum += item
            if let value = cache[sum - k] {
                result += value
            }
            if let present = cache[sum] {
                cache[sum] = present + 1
            } else {
                cache[sum] = 1
            }
        }
        return result
    }
    /*
    func subarraySum(_ nums: [Int] = [1,-1,0], _ k: Int = 0) -> Int {
        var res: Int = 0
        
        for index in 0..<nums.count {
            var sum: Int = nums[index]
            var cache: [Int] = [sum]
            if sum == k {
                res += 1
                continue
            }
            for indexTwo in (index + 1)..<nums.count {
                sum += nums[indexTwo]
                cache.append(nums[indexTwo])
                if sum == k {
                    res += 1
                    break
                }
                while sum > k {
                    if let first = cache.first {
                        sum -= first
                        cache.remove(at: 0)
                    }
                }
                
               // if sum > k { break }
            }
        }
        return res
    }
 */
}

