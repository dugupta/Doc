//
//  House Robber II.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/30/21.
//

import Foundation
/*
//https://leetcode.com/problems/house-robber-ii/
 Example 1:

 Input: nums = [2,3,2]
 Output: 3
 Explanation: You cannot rob house 1 (money = 2) and then rob house 3 (money = 2), because they are adjacent houses.
 Example 2:

 Input: nums = [1,2,3,1]
 Output: 4
 Explanation: Rob house 1 (money = 1) and then rob house 3 (money = 3).
 Total amount you can rob = 1 + 3 = 4.
 Example 3:

 Input: nums = [0]
 Output: 0
 */
struct HouseRobberII {
    
    func rob(_ nums: [Int] = [100, 1, 1, 1, 50, 2]) -> Int {
        var input = nums
        input.removeFirst()
        var maximum = 0
        if nums.count <= 3 {
            return nums.max()!
        }
        
        input[2] += input[0]
        
        for index in 3..<input.count {
            input[index] += max(input[index - 2], input[index - 3])
        }
        
        maximum = input.max()!
        
        input  = nums
        input.removeLast()
        
        
        input[2] += input[0]
        for index in 3..<input.count {
            input[index] += max(input[index - 2], input[index - 3])
        }
        
        maximum = max(maximum, input.max()!)
        return maximum
    }
}
