//
//  Buildings With an Ocean View.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/18/21.
//

import Foundation
//https://leetcode.com/problems/buildings-with-an-ocean-view/

/*
 Example 1:

 Input: heights = [4,2,3,1]
 Output: [0,2,3]
 Explanation: Building 1 (0-indexed) does not have an ocean view because building 2 is taller.
 Example 2:

 Input: heights = [4,3,2,1]
 Output: [0,1,2,3]
 Explanation: All the buildings have an ocean view.
 Example 3:

 Input: heights = [1,3,2,4]
 Output: [3]
 Explanation: Only building 3 has an ocean view.
 Example 4:

 Input: heights = [2,2,2,2]
 Output: [3]
 Explanation: Buildings cannot see the ocean if there are buildings of the same height to its right.
 */

class BuildingsWithAnOceanView {
    func findBuildings(_ heights: [Int] = [4,2,3,1]) -> [Int] {
        var retValue: [Int] = []
        guard var height: Int = heights.last else { return [] }
        retValue.append(heights.count - 1)
        for index in stride(from: heights.count - 2, through: 0, by: -1) {
            if heights[index] > height {
                height = heights[index]
                retValue.append(index)
            }
        }
        
        return retValue.reversed()
    }
}
