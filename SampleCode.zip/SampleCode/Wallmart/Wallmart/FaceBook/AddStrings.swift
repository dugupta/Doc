//
//  AddStrings.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/17/21.
//

import Foundation
//https://leetcode.com/problems/add-strings/
/*
 
 Input: num1 = "11", num2 = "123"
 Output: "134"
 Example 2:

 Input: num1 = "456", num2 = "77"
 Output: "533"
 Example 3:

 Input: num1 = "0", num2 = "0"
 Output: "0"

 */
class AddStrings {
    func addStrings(_ num1: String = "11", _ num2: String = "123") -> String {
        var numberArrayOne = Array(num1)
        var numberArrayTwo = Array(num2)
        var returnString: [Int] = []
        var carry: Int = 0
        let max = max(num1.count, num2.count)
        numberArrayOne = Array(repeating: "0", count: max - numberArrayOne.count) + numberArrayOne
        numberArrayTwo = Array(repeating: "0", count: max - numberArrayTwo.count) + numberArrayTwo
        while !numberArrayOne.isEmpty || !numberArrayTwo.isEmpty {
            guard let numberOneLast = numberArrayOne.last else {
                return ""
            }
            guard let numberTwoLast = numberArrayTwo.last else {
                return ""
            }
            let sum = Int(String(numberOneLast))! + Int(String(numberTwoLast))! + carry
            carry = 0
            if sum >= 10 {
                returnString.insert(sum % 10, at: 0)
                carry = 1
            } else {
                returnString.insert(sum, at: 0)
            }
            numberArrayOne.removeLast()
            numberArrayTwo.removeLast()
        }
        if carry > 0 {
            return returnString.reduce("1", { "\($0)" + "\($1)" })
        }
        return returnString.reduce("", { "\($0)" + "\($1)" })
    }
}
