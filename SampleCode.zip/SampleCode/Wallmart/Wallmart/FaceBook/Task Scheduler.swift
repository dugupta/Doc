//
//  Task Scheduler.swift
//  Wallmart
//
//  Created by Durgesh Lal on 9/5/21.
//

import Foundation
/*
 ///https://leetcode.com/problems/task-scheduler/
 Example 1:

 Input: tasks = ["A","A","A","B","B","B"], n = 2
 Output: 8
 Explanation:
 A -> B -> idle -> A -> B -> idle -> A -> B
 There is at least 2 units of time between any two same tasks.
 Example 2:

 Input: tasks = ["A","A","A","B","B","B"], n = 0
 Output: 6
 Explanation: On this case any permutation of size 6 would work since n = 0.
 ["A","A","A","B","B","B"]
 ["A","B","A","B","A","B"]
 ["B","B","B","A","A","A"]
 ...
 And so on.
 Example 3:

 Input: tasks = ["A","A","A","A","A","A","B","C","D","E","F","G"], n = 2
 Output: 16
 Explanation:
 One possible solution is
 A -> B -> C -> A -> D -> E -> A -> F -> G -> A -> idle -> idle -> A -> idle -> idle -> A
 */
struct TaskScheduler {
    func leastInterval(_ tasks: [Character], _ n: Int) -> Int {
        //Create a map with frequency of tasks/characters
        var map: [Character: Int] = [:]
        for task in tasks {
            map[task, default: 0] += 1
        }
        
        // Number of Intervals is decided by most frequent element in dic.
        let m = map.values.max()!
        
        // Count elements with maximum frequency in dic.
        let numsOfMax = map.values.filter({ $0 == m }).count
        
        // number of intervals = m - 1 => between the 3 As we had to place 2 intervals => m - 1
        let numsOfIntervals = m - 1
        
        // Final result = number of intervals * size of each interval + number of elements with maximum frequency items.
        return max(tasks.count, numsOfIntervals * (n + 1) + numsOfMax)
    }
}
