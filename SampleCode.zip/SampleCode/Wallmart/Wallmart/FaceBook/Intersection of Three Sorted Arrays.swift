//
//  Intersection of Three Sorted Arrays.swift
//  Wallmart
//
//  Created by Durgesh Lal on 7/25/21.
//

import Foundation

struct IntersectionofThreeSortedArrays {
    func arraysIntersection(_ arr1: [Int], _ arr2: [Int], _ arr3: [Int]) -> [Int] {
        return interSaction(interSaction(arr1, arr2), arr3)
    }
}

func interSaction(_ arr1: [Int], _ arr2: [Int]) -> [Int] {
    var result: [Int] = []
    arr1.forEach { item in
        if arr2.contains(item) {
            result.append(item)
        }
    }
    return result
}
