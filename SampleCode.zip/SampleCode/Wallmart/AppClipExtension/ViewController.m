//
//  ViewController.m
//  AppClipExtension
//
//  Created by Durgesh Lal on 4/26/21.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
