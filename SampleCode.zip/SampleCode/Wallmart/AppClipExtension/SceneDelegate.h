//
//  SceneDelegate.h
//  AppClipExtension
//
//  Created by Durgesh Lal on 4/26/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

