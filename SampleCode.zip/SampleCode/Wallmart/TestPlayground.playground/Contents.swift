import UIKit
/*
struct MemberwiseStruct {
    let firstName: String?
    let lastName: String
}


func checkingMemberswiseStruct() {
    print("Compile")
}

checkingMemberswiseStruct()




import Foundation

open class Employee {
  
  public var name: String
  
  public init(_ name: String) {
    self.name = name
    print("Employee \(name) initialised 🥳")
  }
  
  deinit {
    print("Employee \(name) de-initialised 💀")
  }
}

class Manager: Employee {
  var workers: [Worker] = []
}

class Worker: Employee {
  
  unowned let manager: Manager
  
  init(_ name: String, manager: Manager) {
    self.manager = manager
    super.init(name)
  }
}


do {
  let manager = Manager("Manager 1")
  let worker = Worker("Worker 1", manager: manager)
  manager.workers.append(worker)
  print(manager.name, "is still in memory!")
  print(worker.name, "is still in memory!")
}




var tickCount = 0

let incrementTickCount : () -> Void = {
    tickCount += 1
    print("Number of ticks =", tickCount)
}

incrementTickCount()
incrementTickCount()
incrementTickCount()
incrementTickCount()


class Person {

    var name: String
    var age: Int

    init(name: String, age: Int) {
        self.name = name
        self.age = age
        print("\(name) Initialised")
    }

    deinit {
        print("\(name) De-initialised")
    }

    lazy var growOld: (Int) -> Void = { [weak self] delta in
        print("Passed delta is \(delta)")
        self?.age += delta
        print(self?.age)
    }
}

let mark = Person(name: "Mark", age: 10)
mark.growOld(3)


class Year {
    var currentYear: String
    init(currentYear: String) {
        self.currentYear = currentYear
    }
    deinit {
        print("Year de-initialised")
    }
    func getYear() { print("Current year is =", currentYear) }
}

var getCurrentYear : () -> Void
do {
    let year = Year(currentYear: "2019")
    getCurrentYear = { [weak curYear = year] in
        guard let currYear = curYear else {
            print("Unknown year ")
            return
        }
        currYear.getYear()
    }

    getCurrentYear()
    year.currentYear = "2020"
    getCurrentYear()
}
getCurrentYear()


//struct Constants {
//    static let someValue = "someValue"
//}
//
//let _ = Constants()

enum Constants {
    static let someValue = "someValue"
    func enumFunction() {
        print("Inside enum")
    }
}

struct Map: Codable {
    let page: Int?
    let per_page: Int?
    let total: Int?
    let total_pages: Int?
}

do {
    let url: URL! = URL(string: "https://reqres.in/api/users?page=2")
    URLSession.shared.dataTask(with: url) { data, response, error in
        print("data \(data), resposne \(response), error\(error)")
        let decoder = JSONDecoder()
        if let _data = data {
            let object = try? decoder.decode(Map.self, from: _data)
            print(object?.total)
        }
    }.resume()
}

import UIKit

class TestController: UIViewController {
    
    override func loadView() {
        super.loadView()
        print("Load view called")
    }
    
    override func loadViewIfNeeded() {
        super.loadViewIfNeeded()
        print("loadViewIfNeeded")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        print("viewWillLayoutSubviews")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print("viewDidLayoutSubviews")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("viewDidDisappear")
    }
}


var newArray: [String]? = nil
let anotherArray = ["Durgesh", "Gupta"]
newArray = anotherArray
print("newArray \(newArray)")


let controller = TestController()

let superView = UIView()
superView.addSubview(controller.view)


func testSwitch(_ value: Int) {
    defer {
        print("I am in defer1")
    }
    defer {
        print("I am in defer2")
    }
    
    defer {
        print("I am in defer3")
    }
    switch value {
   
    case 1...10:
        defer {
            print("I am in defer")
        }
        
        do {
            print("I am in do")
        }
        print("In between 1 to 10")
        fallthrough
    case 5...10:
        print("In between 5 to 10")
        
    default:
        print("Falling under default")
    }
    do {
        print("I am in defer4")
    }
}

testSwitch(3)


var newValue: String? = .none

if newValue == .none {
    print("Its nil")
}


func countUniques<T: Comparable>(_ array: Array<T>) -> Int {
  let sorted = array.sorted()
  let initial: (T?, Int) = (.none, 0)
  let reduced = sorted.reduce(initial) {
    ($1, $0.0 == $1 ? $0.1 : $0.1 + 1)
  }
  return reduced.1
}

print(countUniques([1, 2, 3, 3]))


let numbers = [1, 12, 2, 9, 27]

print(numbers.reduce(0, +))


let names = ["Taylor", "Paul", "Adele"]
let count = names.reduce(0) {
    let first = $0
    let last = $1
    print("First is \(first)")
    print("Last is \(last)")
    return ($0 + $1.count)
}
print(count)


extension Array where Element: Comparable {
    func countUniques() -> Int {
        let sorted = self.sorted()
        let initial: (Element?, Int) = (.none, 0)
        let reduced = sorted.reduce(initial) {
          ($1, $0.0 == $1 ? $0.1 : $0.1 + 1)
        }
        return reduced.1
    }
}

print([1, 2, 3, 3].countUniques())

struct MyStruct {
    var abc: String = "initila value"

    mutating func changeValue() {
        abc = "some other value" //Compile time error: Cannot assign to property: 'self' is immutable. Mark method 'mutating' to make 'self' mutable.
    }
}


var testOne = MyStruct()
print(testOne)


withUnsafePointer(to: testOne) { _ in print("\(testOne)") }


var newArray = "durgesh"

print(newArray.dropFirst())

print(newArray)


//var count = "Durgesh".componentsSeparatedByString(" ").reduce(0) {
//   words.contains($1) ? $0 + 1 : $0
//}

print("All substring".contains("  sub"))



func printTest1(_ result: () -> Void) {
    print("Before")
    result()
    print("After")
}

printTest1({ print("Hello") })

func printTest2(_ result: @autoclosure () -> Void) {
    print("Before")
    result()
    print("After")
}

printTest2(print("Hello"))


 */


func testForLoop() {
    outerLoop: for outerIndex in 1...100 {
        print("******** Outer Index is \(outerIndex)*************")
        for innerIndex in 1...100 {
            if innerIndex == 5 {
                break outerLoop
            } else {
                print("innerIndex value \(innerIndex)")
            }
        }
    }
}

testForLoop()

let stringArray = ["z", "Durgesh", "Durgeshz"]
print(stringArray.sorted(by: > ))

let intArray = [3, 5, 1, 2, 45]
print(intArray.sorted())
