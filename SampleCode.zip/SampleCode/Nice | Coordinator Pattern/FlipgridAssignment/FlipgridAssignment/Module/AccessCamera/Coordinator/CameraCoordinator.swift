//
//  CameraCoordinator.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/21/21.
//

import Foundation
import UIKit

class CameraCoordinator: NSObject, Coordinator, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    typealias Completion = ((UIImage?) -> Void)
    private var cameraCompletion: Completion?
    internal var children: [Coordinator] = []
    internal var navigationController: UINavigationController
    
    weak var parent: SignupCoordinator?
    
    required init(_ navigationController: UINavigationController, completion: Completion? = nil) {
        self.navigationController = navigationController
        self.cameraCompletion = completion
    }
    
    func start() {
        openCamera()
    }
    
    func didFinishCamera() {
        parent?.childDidFinish(self)
    }
}

extension CameraCoordinator {

    func openCamera() {
        let camera = UIImagePickerController()
        var sourceType: UIImagePickerController.SourceType = .camera
        #if targetEnvironment(simulator)
        sourceType = .photoLibrary
        #endif
        camera.sourceType = sourceType
        camera.allowsEditing = true
        camera.delegate = self
        navigationController.present(camera, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[.editedImage] as? UIImage else { fatalError("No image found") }
        cameraCompletion?(image)
        didFinishCamera()
    }
}
