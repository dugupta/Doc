//
//  SignInCoordinator.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/21/21.
//
import UIKit

class SignInCoordinator: Coordinator {
    internal var children: [Coordinator] = []
    internal var navigationController: UINavigationController
    
    weak var parent: AppCoordinator?
    
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        ///Sign In alert
        let alert = UIAlertController(title: "Welcome!", message: "Welcome to sign in coordinator", preferredStyle: .alert)
        navigationController.present(alert, animated: true, completion: nil)
    }
    
    func didFinishSignUp() {
        parent?.childDidFinish(self)
    }
    
    func childDidFinish(_ child: Coordinator?) {
        if let index = children.firstIndex(where: { $0 === child }) {
            children.remove(at: index)
        }
    }
}
