//
//  SignupFormCell.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

class SignupForm: UITableViewCell {
    
    @IBOutlet weak var firstName: FlipGridTextField!
    @IBOutlet weak var emailAdress: FlipGridTextField!
    @IBOutlet weak var password: FlipGridTextField!
    @IBOutlet weak var website: FlipGridTextField!
    
    private weak var delegate: SignupFormDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        applyTheme()
    }
    
    private func applyTheme() {
        apply(firstName, emailAdress, password, website) { item in
            item?.layer.cornerRadius = 5
            item?.layer.borderWidth = 1
            item?.layer.borderColor = UIColor.gray.cgColor
            item?.layer.sublayerTransform = CATransform3DMakeTranslation(8, 0, 0)
            item?.clearButtonMode = .whileEditing
            item?.delegate = self
        }
    }
    
    func configureWith(_ dataSource: SignupFormViewModeling, delegate: SignupFormDelegate) {
        self.delegate = delegate
        firstName.placeholder = dataSource.namePlaceholder
        emailAdress.placeholder = dataSource.emailPlaceholder
        password.placeholder = dataSource.passwordPlaceholder
        website.placeholder = dataSource.websitePlaceholder
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    fileprivate lazy var textFields: [UITextField] = {
        return [firstName, emailAdress, password, website]
    }()
}


extension SignupForm: UITextFieldDelegate {
   
    private func validateData() {
        let data = FormData(email: emailAdress.text, password: password.text, name: firstName.text, website: website.text)
        self.delegate?.validateForm(data)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        validateData()
        if let selectedTextFieldIndex = textFields.firstIndex(of: textField), selectedTextFieldIndex < textFields.count - 1 {
            textFields[selectedTextFieldIndex + 1].becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        validateData()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        validateData()
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        validateData()
        return true
    }
}
