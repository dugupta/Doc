//
//  SignHeaderCell.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import UIKit

class SignupHeaderCell: UITableViewCell, FromNib {
    
    @IBOutlet weak var headerTitleLabel: UILabel!
    @IBOutlet weak var headerDescriptionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureViewWith(_ dataSource: SignupHeaderViewModeling) {
        headerTitleLabel.text = dataSource.headerText
        headerDescriptionLabel.text = dataSource.helpText
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        headerTitleLabel = nil
        headerDescriptionLabel = nil
    }
}

