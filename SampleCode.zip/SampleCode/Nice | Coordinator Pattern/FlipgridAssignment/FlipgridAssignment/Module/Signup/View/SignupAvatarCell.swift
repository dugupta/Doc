//
//  SignupAvatarCell.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

protocol SignupAvatarDataSource {
    var userImage: UIImage? { get }
}

protocol SignupAvatarDelegate: AnyObject {
    func openCamera(_ completion: @escaping (UIImage?) -> Void)
}

class SignupAvatarCell: UITableViewCell, FromNib, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    @IBOutlet weak var headerImageView: UIImageView!
    private weak var delegate: SignupAvatarDelegate?
     
    override func awakeFromNib() {
        super.awakeFromNib()
        let tap = UITapGestureRecognizer(target: self, action: #selector(SignupAvatarCell.addImage))
        headerImageView.addGestureRecognizer(tap)
        headerImageView.isUserInteractionEnabled = true
    }
    
    func configureWithDelegate(_ dataSource: SignupAvatarDataSource? = nil, delegate: SignupAvatarDelegate? = nil) {
        self.delegate = delegate
        if let image = dataSource?.userImage {
            headerImageView.image = image
        }
    }
    
    @objc func addImage() {
        delegate?.openCamera({ [weak self] image in
            self?.headerImageView.image = image
        })
    }
   
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
