//
//  SignupConfirmationUserDetailCell.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

class SignupConfirmationUserDetailCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailAdressLabel: UILabel!
    @IBOutlet weak var websiteLabel: UILabel!
    
    private weak var delegate: SignupFormDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        websiteLabel.textColor = .blue
    }
    
    func configureWith(_ dataSource: SignupConfirmationUserDetailViewModeling) {
        if let name = dataSource.name {
            nameLabel.isHidden = false
            nameLabel.text = name
        } else {
            nameLabel.isHidden = true
        }
        emailAdressLabel.text = dataSource.email
        if let website = dataSource.website {
            websiteLabel.attributedText = website
            websiteLabel.isHidden = false
        } else {
            websiteLabel.isHidden = true
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
