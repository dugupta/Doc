//
//  SignupViewController.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit
import AppTrackingTransparency
import AdSupport
import AdServices

class SignupViewController: UIViewController  {
    
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    private var viewModel: SignupViewModeling
    private let coordinator: SignupCoordinator?
    
    init?(viewModel: SignupViewModeling, coordinator: SignupCoordinator?, coder: NSCoder) {
        self.viewModel = viewModel
        self.coordinator = coordinator
        super.init(coder: coder)
    }
    
    @available(*, unavailable, renamed: "init(viewModel:coordinator:coder:)")     required init?(coder: NSCoder) {
        fatalError("Invalid way of decoding this class")
    }
    
    private func configureTable() {
        tableView.dataSource = self
        tableView.register(SignupHeaderCell.self)
        tableView.register(SignupAvatarCell.self)
    }
    
    private func subscribeKeyboardNotification() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(sender:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(sender:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        hideKeyboardWhenTappedAround()
//        submitButton.setTitle(viewModel.actionButtonTitle, for: .normal)
//        configureTable()
//        subscribeKeyboardNotification()
        AAAttribution.attributionToken()
       
    }
    
    @objc func keyboardWillShow(sender: NSNotification) {
         self.view.frame.origin.y = -150
    }

    @objc func keyboardWillHide(sender: NSNotification) {
         self.view.frame.origin.y = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let status = ATTrackingManager.trackingAuthorizationStatus
        if status == .authorized {
            print("Adfa enabled without calling is \(ASIdentifierManager.shared().isAdvertisingTrackingEnabled)")
            print("Adfa without calling is \(ASIdentifierManager.shared().advertisingIdentifier)")
            return
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
            ATTrackingManager.requestTrackingAuthorization(completionHandler: { status in
                switch status {
                case .authorized:
                    print("Authorized")
                    print("Adfa enabled after calling is \(ASIdentifierManager.shared().isAdvertisingTrackingEnabled)")
                    print("Adfa after calling is \(ASIdentifierManager.shared().advertisingIdentifier)")
                    
                default:
                    print("Some thing else is here")
                }
            })
        })
        
    }
}

extension SignupViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = viewModel.itemAtIndex(indexPath.row)
        switch item {
        case .header:
            let cell = tableView.dequeueReusableCell(forIndexPath: indexPath) as SignupHeaderCell
            cell.configureViewWith(SignupHeaderViewModel())
            return cell
        case .avatar:
            let cell = tableView.dequeueReusableCell(forIndexPath: indexPath) as SignupAvatarCell
            cell.configureWithDelegate(nil, delegate: coordinator)
            return cell
        case .form:
            if let cell = tableView.dequeueReusableCell(withIdentifier: "SignupForm") as? SignupForm {
                cell.configureWith(SignupFormViewModel(), delegate: self)
                return cell
            }
        }
        return UITableViewCell()
    }
}

extension SignupViewController: SignupFormDelegate {
    
    func validateForm(_ data: FormData) {
        viewModel.updateFormData(data)
    }
    
    @IBAction func submitButtonTouched(_ sender: UIButton) {
//        guard viewModel.isValidForm else {
//            coordinator?.popUpInvalidFormError()
//            return
//        }
        viewModel.signupUserWith() { [weak self] data in
            self?.coordinator?.confirmSignupWith(data)
        }
    }
}
