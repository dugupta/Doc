//
//  SignupConfirmationViewController.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import UIKit

class SignupConfirmationViewController: UIViewController  {
    
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    private let viewModel: SignupConfirmationViewModel
    private let coordinator: SignupCoordinator?
    private var formData: FormData?

    init?(viewModel: SignupConfirmationViewModel, coordinator: SignupCoordinator?, coder: NSCoder) {
        self.viewModel = viewModel
        self.coordinator = coordinator
        super.init(coder: coder)
    }
    
    @available(*, unavailable, renamed: "init(viewModel:coordinator:coder:)")
    required init?(coder: NSCoder) {
        fatalError("Invalid way of decoding this class")
    }
    
    private func configureTable() {
        tableView.dataSource = self
        tableView.register(SignupHeaderCell.self)
        tableView.register(SignupAvatarCell.self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        submitButton.setTitle(viewModel.actionButtonTitle, for: .normal)
        configureTable()
        configureTable()
    }
    
    deinit {
        print("Calling deinit")
    }
}

extension SignupConfirmationViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = viewModel.itemAtIndex(indexPath.row)
        switch item {
        case .header:
            let cell = tableView.dequeueReusableCell(forIndexPath: indexPath) as SignupHeaderCell
            cell.configureViewWith(SignupConfirmationHeaderViewModel(viewModel.getUser))
            return cell
        case .avatar:
            let cell = tableView.dequeueReusableCell(forIndexPath: indexPath) as SignupAvatarCell
            cell.configureWithDelegate(viewModel)
            return cell
        case .userDeatils:
            if let cell = tableView.dequeueReusableCell(withIdentifier: "SignupConfirmationUserDetailCell") as? SignupConfirmationUserDetailCell {
                let cellViewModel = SignupConfirmationUserDetailViewModel(viewModel.getUser)
                cell.configureWith(cellViewModel)
                
                return cell
            }
        }
        
        return UITableViewCell()
    }
}

extension SignupConfirmationViewController {
   
    @IBAction func signInButtonTouched(_ sender: UIButton) {
        coordinator?.didFinishSignUp()
    }
}
