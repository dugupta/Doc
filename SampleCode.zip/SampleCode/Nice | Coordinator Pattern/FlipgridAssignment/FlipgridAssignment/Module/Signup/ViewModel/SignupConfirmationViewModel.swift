//
//  SignupConfirmationViewModel.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

protocol SignupConfirmationViewModeling {
    var actionButtonTitle: String? { get }
    var numberOfRows: Int { get }
    var getUser: User { get }
    func itemAtIndex(_ index: Int) -> SignupConfirmationViewModel.CellItem
}

struct SignupConfirmationViewModel: SignupConfirmationViewModeling, SignupAvatarDataSource {
    
    enum CellItem {
        case header, avatar, userDeatils
    }
    
    private let userData: User
    private var dataSource: [CellItem] = [.header, .avatar, .userDeatils]
    internal var userImage: UIImage?
    init(_ userData: User, userImage: UIImage? = nil) {
        self.userData = userData
        self.userImage = userImage
    }
    
    private(set) var actionButtonTitle: String? = "Sign In"
    
    var numberOfRows: Int { dataSource.count }
    var getUser: User { userData }
    
    func itemAtIndex(_ index: Int) -> SignupConfirmationViewModel.CellItem {
        dataSource[index]
    }
}
