//
//  SignupHeaderViewModel.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation

protocol SignupHeaderViewModeling {
    var headerText: String? { get }
    var helpText: String? { get }
}

struct SignupHeaderViewModel: SignupHeaderViewModeling {
    private(set) var headerText: String? = "Profile Creation"
    private(set) var helpText: String? = "Use the form below to submit your portfolio.\nAn email and password are required."
}

struct SignupConfirmationHeaderViewModel: SignupHeaderViewModeling {
    
    private let user: User
    
    init(_ user: User) {
        self.user = user
    }
    
    var headerText: String? {
        if user.name?.count ?? 0 > 0 {
            return "Hello, \(user.name ?? "")!"
        }
        return "Hello, \(user.email ?? "")!"
    }
    
    private(set) var helpText: String? = "Your super-awesome profile hase been successfully submitted! The preview below is what the community will see!"
}
