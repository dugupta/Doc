//
//  SignupConfirmationUserDetailViewModel.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

protocol SignupConfirmationUserDetailViewModeling {
    var name: String? { get }
    var email: String? { get }
    var website: NSAttributedString? { get }
}

struct SignupConfirmationUserDetailViewModel: SignupConfirmationUserDetailViewModeling {
    
    private let userData: User
    
    init(_ userData: User) {
        self.userData = userData
    }
    
    var name: String? { userData.name }
    var email: String? { userData.email }
    
    
    var website: NSAttributedString? {
        guard let site = userData.website else { return nil }
        let underlineAttribute = [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.thick.rawValue]
        let underlineAttributedString = NSAttributedString(string: "\(site)", attributes: underlineAttribute)
        return underlineAttributedString
    }
}
