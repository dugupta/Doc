//
//  SignupFormViewModel.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation

protocol SignupFormViewModeling {
    var namePlaceholder: String? { get }
    var emailPlaceholder: String? { get }
    var passwordPlaceholder: String? { get }
    var websitePlaceholder: String? { get }
}


struct FormData {
    let email: String?
    let password: String?
    let name: String?
    let website: String?
}

protocol SignupFormDelegate: AnyObject {
    func validateForm(_ data: FormData)
}

struct SignupFormViewModel: SignupFormViewModeling {
    private(set) var namePlaceholder: String? = "First Name"
    private(set) var emailPlaceholder: String? = "Email Address"
    private(set) var passwordPlaceholder: String? = "Password"
    private(set) var websitePlaceholder: String? = "Website" 
}
