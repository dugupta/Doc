//
//  SignupViewModel.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
protocol SignupViewModeling {
    var actionButtonTitle: String? { get }
    var numberOfRows: Int { get }
    var isValidForm: Bool { get }
    func updateFormData(_ data: FormData)
    func itemAtIndex(_ index: Int) -> SignupViewModel.CellItem
    func signupUserWith(_ data: @escaping (User) -> Void)
}

class SignupViewModel: SignupViewModeling {
    private var emailValidator: EmailValidating
    private let dataManager: SignupDataManaging
    private var formData: FormData?
    
    init(_ dataManager: SignupDataManaging = SignupDataManager(), emailValidator: EmailValidating = EmailValidator()) {
        self.dataManager = dataManager
        self.emailValidator = emailValidator
    }
    
    enum CellItem {
        case header, avatar, form
    }
    
    private(set) var actionButtonTitle: String? = "Submit"
    private var dataSource: [CellItem] = [.header, .avatar, .form]
    
    var isValidForm: Bool {
        guard let data = formData else { return false }
        guard let email = data.email else { return false }
        guard email.isNotEmpty && emailValidator.isValidEmail(email) else { return false }
        guard data.password?.isNotEmpty ?? false else { return false }
        return true
    }
    
    var numberOfRows: Int { dataSource.count }
    
    func itemAtIndex(_ index: Int) -> SignupViewModel.CellItem {
        dataSource[index]
    }
    
    func updateFormData(_ data: FormData) {
        formData = data
    }
    
    func signupUserWith(_ data: @escaping (User) -> Void) {
        guard let formData = self.formData else {
            ///Handle Invalid form data error
            return
        }
        let param: [String : String?] = ["name" : formData.name, "email" : formData.email, "website" : formData.website]
        dataManager.signUpUserWith(param) { response in
            switch response {
            case .success(let model):
                data(model)
            case .failure(_):
                break
            }
        }
    }
}
