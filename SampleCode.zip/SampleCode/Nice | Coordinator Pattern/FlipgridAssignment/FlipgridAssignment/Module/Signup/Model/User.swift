//
//  User.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

struct User: Codable {
    let name: String?
    let email: String?
    let website: String?
}

