//
//  SignupDataManager.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation

///An imaginary DataManager
/// In actual implementation, these are real data manager, interacting with web server and will ve mocked in test target
protocol SignupDataManaging {
    init(_ networkManager: NetworkManaging)
    func signUpUserWith(_ param: [String : String?], callBack: @escaping (Result<User, Failure>) -> Void)
}

struct SignupDataManager: SignupDataManaging {
    
    private var networkManager: NetworkManaging
    
    init(_ networkManager: NetworkManaging = NetworkManager()) {
        self.networkManager = networkManager
    }
    
    func signUpUserWith(_ param: [String : String?], callBack: @escaping (Result<User, Failure>) -> Void) {
        networkManager.request(url: "", params: param, callBack: callBack)
    }
}
