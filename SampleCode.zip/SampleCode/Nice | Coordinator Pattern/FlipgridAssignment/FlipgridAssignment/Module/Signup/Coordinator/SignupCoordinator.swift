//
//  SignupCoordinator.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

class SignupCoordinator: Coordinator {
    
    private var container: ServiceResolving
    private var userImage: UIImage?
    private var cameraCompletion: ((UIImage?) -> Void)?
    
    internal var children: [Coordinator] = []
    internal var navigationController: UINavigationController
    
    weak var parent: AppCoordinator?
    
    required init(_ navigationController: UINavigationController, container: ServiceResolving) {
        self.navigationController = navigationController
        self.container = container
    }
    
    func start() {
        coordinateToSignupPage()
    }
    
    func didFinishSignUp() {
        parent?.childDidFinish(self)
    }
    
    func childDidFinish(_ child: Coordinator?) {
        if let index = children.firstIndex(where: { $0 === child }) {
            children.remove(at: index)
        }
    }
}

// MARK:- Private Functions
extension SignupCoordinator {
    private func coordinateToSignupPage() {
        let storyboard = UIStoryboard(name: "SignupViewController", bundle: nil)
        let viewController = storyboard.instantiateViewController(
            identifier: "SignupViewController",
            creator: { coder in
                let viewModel = SignupViewModel(SignupDataManager(), emailValidator: self.container.resolve())
                return SignupViewController(viewModel: viewModel, coordinator: self, coder: coder)
            }
        )
        navigationController.pushViewController(viewController, animated: false)
    }
    
    func popUpInvalidFormError() {
        ///Sign In alert
        let alert = UIAlertController(title: "Error!", message: "Please enter valid email and password", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .cancel) { action in }
        alert.addAction(action)
        navigationController.present(alert, animated: true, completion: nil)
    }
    
    func confirmSignupWith(_ user: User) {
        let storyboard = UIStoryboard(name: "SignupViewController", bundle: nil)
        let viewController = storyboard.instantiateViewController(
            identifier: "SignupConfirmationViewController",
            creator: { [weak self] coder in
                let viewModel = SignupConfirmationViewModel(user, userImage: self?.userImage)
                return SignupConfirmationViewController(viewModel: viewModel, coordinator: self, coder: coder)
            }
        )
        navigationController.viewControllers = []
        navigationController.pushViewController(viewController, animated: false)
    }
}

extension SignupCoordinator: SignupAvatarDelegate {

    func openCamera(_ completion: @escaping (UIImage?) -> Void) {
        let coordinator = CameraCoordinator(navigationController) { [weak self] image in
            self?.userImage = image
            completion(image)
        }
        children.append(coordinator)
        coordinator.parent = self
        coordinator.start()
    }
}
