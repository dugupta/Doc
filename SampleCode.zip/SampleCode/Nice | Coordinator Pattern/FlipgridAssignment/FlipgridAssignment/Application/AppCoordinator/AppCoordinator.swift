//
//  AppCoordinator.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

struct ApplicationBootstrap {
    func createContainer() -> ServiceResolving {
        let container: ServiceResolving = Container()
        container.register(EmailValidating.self) { _ in EmailValidator() }
        return container
    }
}
/// This coordinator pattern is refered from https://www.youtube.com/watch?v=ueByb0MBMQ4&ab_channel=PaulHudson
protocol Coordinator: AnyObject {
    var children: [Coordinator] { get set }
    var navigationController: UINavigationController { get set }
    func start()
}

class AppCoordinator: NSObject, Coordinator {
    
    private var container: ServiceResolving
    
    internal var children: [Coordinator] = []
    internal var navigationController: UINavigationController
    
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
        container = ApplicationBootstrap().createContainer()
    }
    
    func start() {
        let coordinator = SignupCoordinator(navigationController, container: container)
        children.append(coordinator)
        coordinator.parent = self
        coordinator.start()
    }
    
    func childDidFinish(_ child: Coordinator?) {
        if let index = children.firstIndex(where: { $0 === child }) {
            children.remove(at: index)
            if child is SignupCoordinator {
                startSignInflow()
            }
        }
    }
}

extension AppCoordinator {
    ///Start Sign In flow
    func startSignInflow() {
        let signInCoordinator = SignInCoordinator(navigationController)
        children.append(signInCoordinator)
        signInCoordinator.parent = self
        signInCoordinator.start()
    }
}
