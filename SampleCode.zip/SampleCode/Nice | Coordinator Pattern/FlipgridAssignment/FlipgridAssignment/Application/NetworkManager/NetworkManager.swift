//
//  NetworkManager.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
/// An Imaginary Network Manager
/// In actual world, this is real network manager, responsible for all out going rest api call from device and will be mocked in test target 
enum Failure: Error {
    case decoding
    case badResponse
}

protocol NetworkManaging {
    func request<T: Decodable>(url: String, params: [String: String?]?, callBack: @escaping (Result<T, Failure>) -> Void)
}

class NetworkManager: NetworkManaging {
    
    func request<T: Decodable>(url: String, params: [String: String?]?, callBack: @escaping (Result<T, Failure>) -> Void) {
        guard let data = try? JSONSerialization.data(withJSONObject: params ?? [], options: []) else {
            callBack(.failure(.badResponse))
            return
        }
        let decoder = JSONDecoder()
        guard let model = try? decoder.decode(T.self, from: data) else {
            callBack(.failure(.decoding))
            return
        }
        DispatchQueue.main.async {
            callBack(.success(model))
        }
    }
}

extension Bundle {
    static var current: Bundle {
        class __ { }
        return Bundle(for: __.self)
    }
}
/*
struct NetworkManager: NetworkManaging {
    private func process<T: Decodable>(_ data: Data? = nil, callBack: @escaping (RequestStatus, T?) -> Void) {
        if let _data = data {
            let decoder = JSONDecoder()
            let model = try? decoder.decode(T.self, from: _data)
            callBack(.success, model)
            return
        }
        callBack(RequestStatus.failure(.badResponse), nil)
    }

    func request<T: Decodable>(url: String, callBack: @escaping (RequestStatus, T?) -> Void) {
        if let bundlePath = Bundle.current.path(forResource: url, ofType: "json"),
           let data = try? String(contentsOfFile: bundlePath).data(using: .utf8) {
            process(data, callBack: callBack)
        } else {
            fatalError("Facebook: Error while fetching data from local json")
        }
    }
 
 
 //Actual Network call
 func request<T: Decodable>(url: String, params: [String: String]?, callBack: @escaping (RequestStatus, T?) -> Void) {
     let defaultSession = URLSession(configuration: .default)
     var dataTask: URLSessionDataTask?
    
     var urlComponents = URLComponents(string: url)
     params?.forEach { (k,v) in requiredParametrs[k] = v }
     urlComponents?.queryItems = requiredParametrs.map {
          URLQueryItem(name: $0, value: $1)
     }
     
     guard let url = urlComponents?.url else { callBack(RequestStatus.failure(.badRequest), nil); return }
     dataTask = defaultSession.dataTask(with: url, completionHandler: { (data, response, error) in
         self.process(data, urlResponse: response, error: error, callBack: callBack)
     })
     dataTask?.resume()
 }
}
*/
