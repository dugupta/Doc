//
//  Helper.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
import UIKit

func apply<T>(_ elemenst: T..., closure:(T) -> Void) {
    elemenst.forEach { closure($0) }
}


extension String {
    var isNotEmpty: Bool {
        return count > 0
    }
}

extension UITableView {
    
    func register<T: UITableViewCell> (_: T.Type) where T: ViewReusable & ViewLoadable {
        let nib = UINib(nibName: T.NibName, bundle: nil)
        register(nib, forCellReuseIdentifier: T.reuseIdentifier)
    }
}

extension UITableView {
    
    func dequeueReusableCell<T: UITableViewCell>(forIndexPath indexPath: IndexPath) -> T where T: ViewReusable {
        guard let cell = dequeueReusableCell(withIdentifier: T.reuseIdentifier, for: indexPath as IndexPath) as? T else {
            fatalError("Could not dequeue cell with identifier: \(T.reuseIdentifier)")
        }
        return cell
    }
}

protocol ViewReusable: AnyObject {}
extension ViewReusable where Self: UIView {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}

protocol ViewLoadable: AnyObject { }
extension ViewLoadable where Self: UIView {
    static var NibName: String {
        return String(describing: self)
    }
}

protocol FromNib: ViewReusable, ViewLoadable { }


//This is required to aling clear button properly while tyeping
class FlipGridTextField: UITextField {
    override func clearButtonRect(forBounds bounds: CGRect) -> CGRect {
        let originalRect = super.clearButtonRect(forBounds: bounds)
        return originalRect.offsetBy(dx: -10, dy: 0)
    }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

