//
//  EmailValidator.swift
//  FlipgridAssignment
//
//  Created by Durgesh Lal on 10/21/21.
//

import Foundation

protocol Validating { }

protocol EmailValidating: Validating {
    func isValidEmail(_ email: String) -> Bool
}
///Reference : https://www.swiftbysundell.com/articles/validating-email-addresses/
struct EmailValidator: EmailValidating {
    func isValidEmail(_ email: String) -> Bool {
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = email as NSString
            let results = regex.matches(in: email, range: NSRange(location: 0, length: nsString.length))
            if results.count == 0 {
                returnValue = false
            }
        } catch let _ as NSError {
            returnValue = false
        }
        return  returnValue
    }
}
