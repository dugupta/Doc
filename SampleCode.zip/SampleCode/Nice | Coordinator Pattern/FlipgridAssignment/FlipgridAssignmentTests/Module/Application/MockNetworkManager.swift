//
//  MockNetworkManager.swift
//  FlipgridAssignmentTests
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation
@testable import FlipgridAssignment

struct MockNetworkManager: NetworkManaging {
    
    func request<T>(url: String, params: [String : String?]?, callBack: @escaping (Result<T, Failure>) -> Void) where T : Decodable {
        guard let data = try? JSONSerialization.data(withJSONObject: params ?? [], options: []) else {
            callBack(.failure(.badResponse))
            return
        }
        let decoder = JSONDecoder()
        guard let model = try? decoder.decode(T.self, from: data) else {
            callBack(.failure(.decoding))
            return
        }
        callBack(.success(model))
    }
}
