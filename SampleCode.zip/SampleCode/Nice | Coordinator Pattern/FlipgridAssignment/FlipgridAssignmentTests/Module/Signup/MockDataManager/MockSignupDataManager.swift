//
//  MockSignupDataManager.swift
//  FlipgridAssignmentTests
//
//  Created by Durgesh Lal on 10/20/21.
//

import Foundation

import Foundation
@testable import FlipgridAssignment

struct MockSignupDataManager: SignupDataManaging {
    
    private var networkManager: NetworkManaging
    
    init(_ networkManager: NetworkManaging = MockNetworkManager()) {
        self.networkManager = networkManager
    }
    
    func signUpUserWith(_ param: [String : String?], callBack: @escaping (Result<User, Failure>) -> Void) {
        networkManager.request(url: "", params: param, callBack: callBack)
    }
}
