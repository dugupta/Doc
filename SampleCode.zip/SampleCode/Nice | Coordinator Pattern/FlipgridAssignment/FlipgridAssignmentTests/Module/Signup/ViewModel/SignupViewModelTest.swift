//
//  SignupViewModelTest.swift
//  FlipgridAssignmentTests
//
//  Created by Durgesh Lal on 10/20/21.
//

import XCTest
@testable import FlipgridAssignment

class SignupViewModelTest: XCTestCase {
    
    private var viewModel: SignupViewModel!
    override func setUpWithError() throws {
        viewModel = SignupViewModel(MockSignupDataManager())
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }
    
    func testActionButtonTitle() {
        XCTAssertEqual(viewModel.actionButtonTitle, "Submit")
    }
    func testNumberOfRows() {
        XCTAssertEqual(viewModel.numberOfRows, 3)
    }
    
    func testItemAtIndex() {
        XCTAssertEqual(viewModel.itemAtIndex(0), .header)
        XCTAssertEqual(viewModel.itemAtIndex(1), .avatar)
        XCTAssertEqual(viewModel.itemAtIndex(2), .form)
    }
    
    func testSignupUser() {
        viewModel.updateFormData(FormData(email: "durgesh.aaa@bbb.com", password: "strongPassword", name: "Durgesh", website: "durgesh@net"))
        viewModel.signupUserWith() { user in
            XCTAssertEqual(user.email, "durgesh.aaa@bbb.com")
            XCTAssertEqual(user.name, "Durgesh")
            XCTAssertEqual(user.website, "durgesh@net")
        }
    }
    
}
