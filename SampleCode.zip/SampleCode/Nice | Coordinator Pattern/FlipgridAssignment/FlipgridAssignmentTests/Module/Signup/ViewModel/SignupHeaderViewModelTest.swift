//
//  SignupHeaderViewModelTest.swift
//  FlipgridAssignmentTests
//
//  Created by Durgesh Lal on 10/20/21.
//

import XCTest
@testable import FlipgridAssignment

class SignupHeaderViewModelTest: XCTestCase {

    private var viewModel: SignupHeaderViewModel!
    override func setUpWithError() throws {
        viewModel = SignupHeaderViewModel()
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }
    
    func testHeaderText() {
        XCTAssertEqual(viewModel.headerText, "Profile Creation")
    }
    
    func testHelpText() {
        XCTAssertEqual(viewModel.helpText, "Use the form below to submit your portfolio.\nAn email and password are required.")
    }

}
