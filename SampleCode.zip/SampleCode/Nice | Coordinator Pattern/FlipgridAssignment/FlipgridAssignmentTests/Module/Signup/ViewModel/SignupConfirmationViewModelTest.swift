//
//  SignupConfirmationViewModelTest.swift
//  FlipgridAssignmentTests
//
//  Created by Durgesh Lal on 10/20/21.
//

import XCTest
@testable import FlipgridAssignment

class SignupConfirmationViewModelTest: XCTestCase {

    var viewModel: SignupConfirmationViewModel!
    
    override func setUpWithError() throws {
        viewModel = SignupConfirmationViewModel(User(name: "Durgesh", email: "durgesh@aaa.com", website: "durgesh@net"), userImage: nil)
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }
    
    func testActionButtonTitle() {
        XCTAssertEqual(viewModel.actionButtonTitle, "Sign In")
    }
    func testNumberOfRows() {
        XCTAssertEqual(viewModel.numberOfRows, 3)
    }
    
    func testItemAtIndex() {
        XCTAssertEqual(viewModel.itemAtIndex(0), .header)
        XCTAssertEqual(viewModel.itemAtIndex(1), .avatar)
        XCTAssertEqual(viewModel.itemAtIndex(2), .userDeatils)
    }
}
