//
//  PartnerDashboradViewController.swift
//  Coursera
//
//  Created by Durgesh Lal on 1/21/22.
//

import Foundation
import UIKit


enum Failure: Error {
    case other
    case badUrl
    case parsingRrror
}

protocol NetworkManaging {
    func request<T: Decodable>(url: String, params: [String: String]?, callBack: @escaping (Result<T, Failure>) -> Void)
}


class NetworkManager: NetworkManaging {
    
    func request<T: Decodable>(url: String, params: [String: String]? = nil, callBack: @escaping (Result<T, Failure>) -> Void) {
        
        guard let url = URL(string: url) else { callBack(.failure(.badUrl))
            return
        }
        let request = URLRequest(url: url)
        let session = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _data = data else {
                // Invalid data
                DispatchQueue.main.async {
                    callBack(.failure(.other))
                }
                
                return
            }
            print("Data \(_data), response \(response), error \(error)")
            
            let data = Data
            let decoder = JSONDecoder()
            guard let object = try? decoder.decode(T.self, from: _data) else {
                // Parsing Error
                DispatchQueue.main.async {
                    callBack(.failure(.parsingRrror))
                }
                
                return
            }
            DispatchQueue.main.async {
                callBack(.success(object))
            }
            
        }
        session.resume()
    }
}

/*
 
 {
   "elements": [
      {
       "name": "The University of North Carolina at Chapel Hill",
       "id": "77",
       "shortName": "unc"
      }
   ]
 }


 */

struct Partners: Codable {
    
    let elements: [Partner]?
    struct Partner: Codable {
        let courseIds: [String]?
        let description: String?
        let name: String?
        let id: String?
        let shortName: String?
    }
}

protocol PartnerDashboradDataManaging {
    func fetchUniversityList(_ url: String, callBack: @escaping (Result<Partners, Failure>) -> Void)
}

class PartnerDashboradDataManager: PartnerDashboradDataManaging {
    
    private let networkManager: NetworkManaging
    
    required init(_ networkManager: NetworkManaging) {
        self.networkManager = networkManager
    }
    
    func fetchUniversityList(_ url: String, callBack: @escaping (Result<Partners, Failure>) -> Void) {
        networkManager.request(url: url, params: nil, callBack: callBack)
    }
}


protocol PartnerDashboradViewModeling {
    var numberOfRows: Int { get }
    func itemAtIndex(_ index: Int) -> Partners.Partner
    func fetchUniversityList(_ callBack: @escaping (_ success: Bool) -> Void)
    
}

class PartnerDashboradViewModel: PartnerDashboradViewModeling {
    private let dataManager: PartnerDashboradDataManaging
    private var partnerList: [Partners.Partner] = []
    required init(_ dataManager: PartnerDashboradDataManaging) {
        self.dataManager = dataManager
    }
    
    func fetchUniversityList(_ callBack: @escaping (_ success: Bool) -> Void) {
        let query = [URLQueryItem(name: "fields", value: "description,courseIds")]
        dataManager.fetchUniversityList("https://api.coursera.org/api/partners.v1?fields=description,courseIds") { [weak self] result in
            switch result {
            case .failure(let error):
                print("Error is \(error)")
                callBack(false)
            case .success(let data):
                print("Data is \(data)")
                self?.partnerList = data.elements ?? []
                callBack(true)
            }
        }
    }
    
    var numberOfRows: Int {
        partnerList.count
    }
    
    func itemAtIndex(_ index: Int) -> Partners.Partner {
        partnerList[index]
    }
}


enum ReuseCellIdentifier: String {
    case UniversityName
}


class PartnerDashboradViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
   
    private var viewModel: PartnerDashboradViewModeling!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: ReuseCellIdentifier.UniversityName.rawValue)
        let networkManager: NetworkManaging = NetworkManager()
        let dataManager: PartnerDashboradDataManaging = PartnerDashboradDataManager(networkManager)
        viewModel = PartnerDashboradViewModel(dataManager)
        viewModel.fetchUniversityList { [weak self] result in
            self?.tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = viewModel.itemAtIndex(indexPath.row)
        let cell = tableView.dequeueReusableCell(withIdentifier: ReuseCellIdentifier.UniversityName.rawValue, for: indexPath)
        cell.textLabel?.text = "\(item.name ?? "")"
        return cell
    }
    
    var holdingObject: [CourseListViewController] = []
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = viewModel.itemAtIndex(indexPath.row)
        guard let controller: CourseListViewController = self.storyboard?.instantiateViewController(withIdentifier: "CourseListViewController") as? CourseListViewController else { return }
        controller.updateCourseIds(item.courseIds ?? [])
        //holdingObject.append(controller)
        navigationController?.pushViewController(controller, animated: true)
    }
}


struct Courses: Codable {
    
    let elements: [Course]?
    
    struct Course: Codable {
        let courseType: String?
        let name: String?
        let id: String?
        let slug: String?
    }
}

protocol CourseListDataManaging {
    func fetchCourseList(_ url: String, callBack: @escaping (Result<Courses, Failure>) -> Void)
}

class CourseListDataManager: CourseListDataManaging {
    private let networkManager: NetworkManaging
    
    required init(_ networkManager: NetworkManaging) {
        self.networkManager = networkManager
    }
    
    func fetchCourseList(_ url: String, callBack: @escaping (Result<Courses, Failure>) -> Void) {
        networkManager.request(url: url, params: nil, callBack: callBack)
    }
}
 
protocol CourseListViewModeling {
    var numberOfRows: Int { get }
    func itemAtIndex(_ index: Int) -> Courses.Course
    func fetchOfferedCourseList(_ courseIdes: [String], callBack: @escaping (_ success: Bool) -> Void)
}

class CourseListViewModel: CourseListViewModeling {
    private let dataManager: CourseListDataManaging
    private var courseList: [Courses.Course] = []
    required init(_ dataManager: CourseListDataManaging) {
        self.dataManager = dataManager
    }
    
    func fetchOfferedCourseList(_ courseIdes: [String], callBack: @escaping (_ success: Bool) -> Void) {
        let joined = courseIdes.joined(separator: ",")
        let url = "https://api.coursera.org/api/courses.v1?ids=\(joined)"
        
        dataManager.fetchCourseList(url) { [weak self] result in
            switch result {
            case .failure(let error):
                print("Error is \(error)")
                callBack(false)
            case .success(let data):
                print("Data is \(data)")
                self?.courseList = data.elements ?? []
                callBack(true)
            }
        }
    }
    
    
    var numberOfRows: Int {
        courseList.count
    }
    
    func itemAtIndex(_ index: Int) -> Courses.Course {
        courseList[index]
    }
}

class CourseListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
   
    private var viewModel: CourseListViewModeling!
    
    private var courseIds: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        let networkManager: NetworkManaging = NetworkManager()
        let dataManager: CourseListDataManaging = CourseListDataManager(networkManager)
        viewModel = CourseListViewModel(dataManager)
        viewModel.fetchOfferedCourseList(courseIds) { [weak self] result in
            self?.tableView.reloadData()
        }
    }
    
    deinit {
        print("Durgesh : De init CourseListViewController")
    }
    
    func updateCourseIds(_ courseIds: [String]) {
        self.courseIds = courseIds
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = viewModel.itemAtIndex(indexPath.row)
        let cell: CourseCell = tableView.dequeueReusableCell(withIdentifier: "CourseCell", for: indexPath) as! CourseCell
        let viewModel = CourseCellViewModel(item)
        cell.configureWith(viewModel)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

protocol CourseCellViewModeling {
    var type: String? { get }
    var title: String? { get }
    var description: String? { get }
}

struct CourseCellViewModel: CourseCellViewModeling {
    let course: Courses.Course
    init(_ course: Courses.Course ) {
        self.course = course
    }
    
    var type: String? { course.courseType }
    var title: String? { course.name }
    //For now, using slug
    var description: String? { course.slug }
    
}


class CourseCell: UITableViewCell {
    
    @IBOutlet weak var courseType: UILabel!
    @IBOutlet weak var courseTitle: UILabel!
    @IBOutlet weak var courseDescription: UILabel!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func configureWith(_ data: CourseCellViewModeling) {
        courseType.text = data.type
        courseTitle.text = data.title
        courseDescription.text = data.description
    }
}
