//
//  NetworkManager.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
import Combine

enum BaseUrl: String {
    case fetchImage = "https://image.tmdb.org/t/p/w500/"
    case polularMovies = "https://api.themoviedb.org/3/"
    var url: String {
        return rawValue
    }
}

enum Failure: Error {
  case statusCode
  case decoding
  case invalidURL
  case other(Error)
  
  static func map(_ error: Error) -> Failure {
    return (error as? Failure) ?? .other(error)
  }
}

// MARK: - Networking method
///
/// - Note: Struct must confirm to Codable while passing in Callback
/// - Parameters:
///   - url: Target url to be hit
///   - params: Parameters if any
///   - callBack: Callback with a RequestStatus and Codable Object

protocol NetworkManaging {
    func request<T: Decodable>(url: String, params: [String: String]?) -> AnyPublisher<T, Failure>
}

class NetworkManager: NetworkManaging {
   
    var requiredParametrs: [String: String] = ["api_key" : "539208b89a9c50661fd4d0753c8fd252", "language" : "en-US"]
    func request<T: Decodable>(url: String, params: [String: String]? = nil) -> AnyPublisher<T, Failure> {
        
        let defaultSession = URLSession(configuration: .default)
        
        //var dataTask: URLSessionDataTask?
       
        var urlComponents = URLComponents(string: url)
        params?.forEach { (k,v) in requiredParametrs[k] = v }
        urlComponents?.queryItems = requiredParametrs.map {
             URLQueryItem(name: $0, value: $1)
        }
        
        let url = urlComponents?.url // else { return Failure.invalidURL }
        let urlRequest = URLRequest(url: url!)

        return defaultSession.dataTaskPublisher(for: urlRequest)
          .tryMap { response -> Data in
            guard let httpURLResponse = response.response as? HTTPURLResponse,
              httpURLResponse.statusCode == 200 else {
                throw Failure.statusCode
            }
            
            print("response \(httpURLResponse) data \(response.data), description : \(response)")
            return response.data
          }
          .decode(type: T.self, decoder: JSONDecoder())
          .mapError { Failure.map($0) }
          .eraseToAnyPublisher()
    }
}
