//
//  PopularMovieHomeViewController.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import UIKit
import WebKit

protocol PopularMovieHomeViewModeling {
    init(_ url: String, title: String?)
    var screenTitle: String? { get }
    var homePageUrl: String { get }
}

struct PopularMovieHomeViewModel: PopularMovieHomeViewModeling {
    
    private var title: String?
    private var url: String
    
    init(_ url: String, title: String? = nil) {
        self.url = url
        self.title = title
    }
    
    var screenTitle: String? {
        title
    }
    
    var homePageUrl: String {
        url
    }
}

class PopularMovieHomeViewController: UIViewController, WKNavigationDelegate, ErrorPresentable {

    private var viewModel: PopularMovieHomeViewModeling
    typealias CallBack = () -> Void
    
    private var callBack: CallBack?
    
    init(_ viewModel: PopularMovieHomeViewModeling, callBack: CallBack?) {
        self.viewModel = viewModel
        self.callBack = callBack
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var webView: WKWebView!
    
    private func configureWebView() {
        if let url = URL(string: viewModel.homePageUrl) {
            webView.load(URLRequest(url: url))
            webView.allowsBackForwardNavigationGestures = true
        } else {
            presentError("Movie home url is Invalid!")
        }
    }
    
    private func configureView() {
        title = viewModel.screenTitle
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
        //Add Cancel button instead Back Button
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancel))
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        configureView()
        configureWebView()
    }
    
    @objc func cancel() {
        self.callBack?()
    }
    
    deinit {
        Log.debug("*********Deallocting PopularMovieHomeViewController***********")
    }
}
