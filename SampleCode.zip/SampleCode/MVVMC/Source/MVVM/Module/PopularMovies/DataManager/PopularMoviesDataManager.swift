//
//  PopularMoviesDataManager.swift
//  MVVM-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
import Combine

protocol PopularMoviesDataManaging {
    init(_ networkManager: NetworkManaging)
    // MARK: - Populare Movie List
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    func moviesList() -> AnyPublisher<PopularMoviesResponse, Failure>
    // MARK: - Genre
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    func fetchGenres() -> AnyPublisher<GenreResponse, Failure>
}

struct PopularMoviesDataManager: PopularMoviesDataManaging {
    
    enum EndPoint {
        case moviesList
        case genre
        var url: String {
            switch self {
            case .moviesList:
                return "\(BaseUrl.polularMovies.url)movie/popular?"
            case .genre:
                return "\(BaseUrl.polularMovies.url)genre/movie/list?"
            }
        }
    }
    
    private var networkManager: NetworkManaging
    private var page: Int = 1
    private var isApiInprocess = false
    
    init(_ networkManager: NetworkManaging = NetworkManager()) {
        self.networkManager = networkManager
    }
    
    func moviesList() -> AnyPublisher<PopularMoviesResponse, Failure> {
        networkManager.request(url: EndPoint.moviesList.url, params: ["page" : "\(page)"])
    }
    
    func fetchGenres() -> AnyPublisher<GenreResponse, Failure> {
        networkManager.request(url: EndPoint.genre.url, params: nil)
    }
}


class DummyClass {
    typealias CallBack = () -> Void
    private var callBack: CallBack?
    
    func checkingClosure(_ completion: CallBack?) {
        self.callBack = completion
        
        DispatchQueue.main.async {
            self.callBack?()
        }
        //completion?()
    }
}
