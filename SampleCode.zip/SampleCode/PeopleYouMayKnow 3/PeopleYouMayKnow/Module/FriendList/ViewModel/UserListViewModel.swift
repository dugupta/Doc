//
//  UserListViewModel.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/16/21.
//

import Foundation

protocol UserListViewModeling {
    func fetchUserList(_ list: String)
    var notify: (() -> Void)? { get set }
    
    var screenTitle: String? { get }
    var headerTitle: String? { get }
    var numberOfRows: Int { get }
    
    func user(_ index: Int) -> UserViewModeling
}

class UserListViewModel: UserListViewModeling {
    
    var notify: (() -> Void)? = nil
    private var dataSource: [UserViewModel] = [] {
        didSet {
            self.notify?()
        }
    }
    private var dataManager: UserListDataManaging
    private var currentUser: User!
    required init(_ dataManager: UserListDataManaging = UserListDataManager()) {
        self.dataManager = dataManager
    }
    
    lazy var screenTitle: String? = {
        currentUser?.name
    }()
    
    lazy var headerTitle: String? = {
        if let title = screenTitle {
            return "\(title) : Suggested friends"
        }
        return nil
    }()
}

// MARK: Table View Data Source
extension UserListViewModel {
   
    var numberOfRows: Int {
        dataSource.count
    }
    
    func user(_ index: Int) -> UserViewModeling {
        dataSource[index]
    }
}

// MARK: - APi calls
extension UserListViewModel {
    
    /// - Complexity: O(n2), where *n* is the length of the sequence.
    /// Its a shortest path in a graph using  "Dijkstra's Algorithm"
    private func socialDistance (source: Int, destination: Int, graph: Graph) -> Int {
        /// - Complexity: O(n), where *n* is the length of the sequence.
        guard var currentNode = graph.nodes.first(where: { $0.identifier == source }) else { return -1 }
        currentNode.visited = true
        currentNode.distance = 0
        var toVisit: [Node] = []
        toVisit.append(currentNode)
        /// - Complexity: O(n), where *n* is the length of the sequence.
        while !toVisit.isEmpty {
            toVisit = toVisit.filter{ $0.identifier != currentNode.identifier }
            currentNode.visited = true
            /// Go to each adjacent vertex and update the path length
            /// - Complexity: O(n), where *n* is the length of the sequence.
            for connectedEdge in currentNode.edges {
                let dist = currentNode.distance + connectedEdge.weight
                if dist < connectedEdge.to.distance {
                    connectedEdge.to.distance = dist
                    toVisit.append(connectedEdge.to)
                    if connectedEdge.to.visited {
                        connectedEdge.to.visited = false
                    }
                }
            }
            
            currentNode.visited = true
            //set current node to the smallest vertex
            if !toVisit.isEmpty {
                if let minNode = toVisit.min(by: { $0.distance < $1.distance}) {
                    currentNode = minNode
                }
            }
            
            if currentNode.identifier == destination {
                return currentNode.distance
            }
        }
        return -1
    }

    
    /// - Complexity: O(n), where *n* is the length of the sequence.
    /// To reduce the complexity, using dict to find common freinds, instead using higher order func like filter and contain and chain together
    private func mutualFriendsCountfor(_ facebookCandidate: UserViewModel, user: UserViewModel) -> Int? {
        var cache: [Int : Int] = [:]
        /// - Complexity: O(*n*), where *n* is the length of the sequence.
        /// Loop through all the friends in Facebook candidate and add in dict having key and value, both as user id
        facebookCandidate.friends?.forEach({ friend in
            cache[friend] = friend
        })
        /// - Complexity: O(*n*), where *n* is the length of the sequence.
        /// Loop through all the friends in user and check for user id in the cache, if found increase the counter by 1
        var count = 0
        user.friends?.forEach({ friend in
            if cache[friend] != nil {
                count += 1
            }
        })
        return count > 0 ? count : nil
    }
    /// - Complexity: O(*n* log *n*), where *n* is the length of the sequence.
    private func sort(_ validUser: inout [UserViewModel]) {
        validUser = validUser.sorted(by: { objectOne, objectTwo in
            /// If social distance is same, sort using highest mutual friends first
            if objectOne.socialDistance! == objectTwo.socialDistance! {
                if let valueOne = objectOne.mutualFriends, let valueTwo = objectTwo.mutualFriends {
                    return valueOne > valueTwo
                }
                return objectOne.mutualFriends != nil
            } else {
                /// lesser social distance value will come first in the list
                return objectOne.socialDistance! < objectTwo.socialDistance!
            }
        })
    }
    
    /// - Complexity: O(n2), where *n* is the length of the sequence.
    private func createGraphNodes(_ response: [User]?) -> [[Int]] {
        /// - Complexity: O(n2), where *n* is the length of the sequence.
        var graph: [[Int]] = []
        response?.forEach({ item in
            item.friends?.forEach({ friend in
                if let id = item.id {
                    let node = [id, friend, 1]
                    graph.append(node)
                }
            })
        })
        return graph
    }
    
    
    func fetchUserList(_ list: String) {
        /// Fetch Data from mock json
        /// Output is array of user
        ///  struct {
        ///     let id: Int?
        ///     let name: String?
        ///     let friends: [Int]?
        ///  }
        /// response = [User]
        dataManager.userList(list) { status, response in
            guard let users = response else { fatalError("Facbook: Users is nil")}
            /// - Complexity: O(n), where *n* is the length of the sequence.
            /// Fetch current user to show screen title as user name
            guard let currentUserIndex = users.firstIndex(where: { $0.id == 1 }) else { fatalError("Facbook: Current user index is missing") }
            self.currentUser = users[currentUserIndex]
           
            /// Crate a graph with given set of data
            /// Data input is [[Int]] and each element is [source, destination, weight]
            /// Weight is always 1 in this case
            /// For example: [[1,25,1], [1,13,1], [1,40,1], [1,3,1], [1,5,1], [1,6,1], [1,7,1], [1,8,1] ]
            let graphNodes: [[Int]] = self.createGraphNodes(response)
            /// validUser is defined to all user from whom the social distance is greater that 0
            /// In the given mock json, 2 user have no valid social distance "John Smith" & "Francisco Alvarado"
            ///  They are fiend which each other and not linked to anyone
            ///
            /*
             
             {
               "id": 32,
               "name": "John Smith",
               "friends": [51]
             },{
                "id": 51,
                "name": "Francisco Alvarado",
                "friends": [32]
             }
             
             */
            var validUser: [UserViewModel] = []
            for object in response ?? [] {
                /// Pass back graphNodes created from all user to create actual graph
                /// For above example : [[1,25,1], [1,13,1], [1,40,1], [1,3,1], [1,5,1], [1,6,1], [1,7,1], [1,8,1] ]
                /*
                 1 -1-> 25
                 1 -1-> 13
                 1 -1-> 40
                 1 -1-> 3
                 1 -1-> 5
                 1 -1-> 6
                 1 -1-> 7
                 1 -1-> 8
                 */
                let graphObject = setupGraphwith(edges: graphNodes)
                if let id = object.id {
                    /// We do not want, first object to be visible in list
                    if id == 1 { continue }
                    /// Its a shortest path in a graph using  "Dijkstra's Algorithm"
                    let distance = self.socialDistance(source: 1, destination: id, graph: graphObject)
                    if distance > 0 {
                        let item = UserViewModel(object.name, friends: object.friends)
                        item.socialDistance = distance
                        validUser.append(item)
                    }
                }
            }
           
            validUser.forEach { object in
                let current = UserViewModel(self.currentUser.name, friends: self.currentUser.friends)
                object.mutualFriends = self.mutualFriendsCountfor(current, user: object)
            }
            /// Sort all valid users as per requirements
            /*
             a. John Doe - Social distance: 2, Mutual friends: 5
             b. Bob Kemp - Social Distance: 2, Mutual friends: 3
             c. Bryce Holmes - Social Distance: 3
             d. James Smith - Social Distance: 3
             */
            self.sort(&validUser)
            self.dataSource = validUser
        }
    }
}



