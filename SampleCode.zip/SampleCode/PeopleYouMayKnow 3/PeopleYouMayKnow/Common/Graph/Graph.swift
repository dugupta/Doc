//
//  Graph.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/17/21.
//

import Foundation

class Node {
    /// unique identifier required for each node, to identify uniquely while traversal
    var identifier : Int
    var distance : Int = Int.max
    var edges: [Edge] = []
    var visited = false
    
    init(visited: Bool, identifier: Int, edges: [Edge]) {
        self.visited = visited
        self.identifier = identifier
        self.edges = edges
    }
    
    static func == (lhs: Node, rhs: Node) -> Bool {
        return lhs.identifier == rhs.identifier
    }
}

class Edge {
    var from: Node
    var to: Node
    var weight: Int

    init(to: Node, from: Node, weight: Int) {
        self.to = to
        self.weight = weight
        self.from = from
    }
}

class Graph {
    var nodes: [Node] = []
}

/// - Complexity: O(*n*), where *n* is the length of the sequence.
func setupGraphwith(edges: [[Int]]) -> Graph {
    let graph = Graph()
    // create all the nodes
    // The first and last node need to be included, so need nodes from "to" and "from"
    /// [Source, Destination, weight]
    let nodeNames = Set ( edges.map{ $0[0] } + edges.map{ $0[1]} )
    /// - Complexity: O(*n*), where *n* is the length of the sequence.
    for node in nodeNames {
        let newNode = Node(visited: false, identifier: node, edges: [])
        graph.nodes.append(newNode)
    }
    var cache: [Int: Node] = [:]
    ///Loop through all the nodes and add in Dict called cache to find while creating edges
    graph.nodes.forEach { node in
        cache[node.identifier] = node
    }
    // create all the edges to link the nodes
    /// - Complexity: O(*n*), where *n* is the length of the sequence.
    for edge in edges {
        guard let fromNode = cache[edge[0]] else { return graph }
        guard let toNode = cache[edge[1]] else { return graph }
        let forwardEdge = Edge(to: toNode, from: fromNode, weight: edge[2])
        fromNode.edges.append(forwardEdge)
    }
    return graph
}

