//
//  PopularMoviesViewModel.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Combine
import Foundation

struct CallBack {
    
}

class PopularMoviesListViewModel: PopularMoviesListViewModeling {
    func update() {
        //data = itemResponse.results?.map({ PopularMovieViewModel($0) }) ?? []
    }
    
    var callBack = {
        
    }
    
    var error: Failure = .invalidURL {
        didSet {
            switch error {
            case .decoding:
                break
            case .invalidURL:
                break
            case .statusCode:
                break
            case .other(let reason):
                break
            }
        }
    }
    
    private var subject = CurrentValueSubject<CallBack, Never>(CallBack())
    
    var publisher: AnyPublisher<CallBack, Never> {
        return subject.eraseToAnyPublisher()
    }
    
    private var subscriptions: Set<AnyCancellable> = []
    typealias Item = PopularMovieViewModel
    private var data: [PopularMovieViewModel] = []
//    var itemResponse: PopularMoviesResponse {
//        didSet {
//
//        }
//    }
    
    private var dataManager: PopularMoviesDataManaging
    required init(_ dataManager: PopularMoviesDataManaging = PopularMoviesDataManager()) {
        self.dataManager = dataManager
        self.fetchGenres()
        self.fetchPopularMoviesList()
    }
    
    lazy var screenTitle: String? = {
        return "Popular movies"
    }()
}

// MARK: Table View Data Source
extension PopularMoviesListViewModel {
    
    func itemAt(_ indexPath: Int) -> PopularMovieViewModel {
        return data[indexPath]
    }
    
    var moviesList: [PopularMovieViewModel]  {
        return self.data
    }
    
    func movieIdAt(_ indexPath: Int) -> String? {
        if let id = data[indexPath].rawItem.movieId {
            return "\(id)"
        }
        return nil
    }
}

// MARK: - APi calls
extension PopularMoviesListViewModel {
    
    func fetchPopularMoviesList() {
        dataManager.moviesList()
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .finished: break
                case .failure(let error):
                    print("Error: \(error)")
                }
            } receiveValue: { response in
                Log.debug("************list Response***************\n\(String(describing: response.results))")
                self.data = response.results?.map({ PopularMovieViewModel($0) }) ?? []
                self.subject.value = CallBack()
                //self.itemResponse = response
            }
            .store(in: &subscriptions)
    }
    
    func fetchGenres() {
        dataManager.fetchGenres()
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .finished: break
                case .failure(let error):
                    print("Error: \(error)")
                }
            } receiveValue: { response in
                Log.debug("************Genres Response***************\n\(String(describing: response))")
                Genre.object.genreResponse = response
            }
            .store(in: &subscriptions)
    }
}
