//
//  PopularMovieDetailViewController.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import UIKit

protocol ErrorPresentable {
    func presentError(_ message: String?)
}

extension ErrorPresentable where Self: UIViewController {
    func presentError(_ message: String? = "Sorry of inconvenience, we are working on, please try again later!") {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
}

class PopularMovieDetailViewController<T: PopularMovieDetailViewModeling>: UITableViewController, ErrorPresentable {
    
    private var viewModel: T
    private weak var delegate: AppFlowCoordinating?
    
    private var dataSource: UITableViewDiffableDataSource<MovieSection, PopularMovieDetailViewModel>! = nil
    
    private func internalSetup() {
        title = viewModel.screenTitle
        view.backgroundColor = .white
    }
    
    private func configureTableView() {
        tableView.separatorStyle = .none
        tableView.register(MovieDetailCell.self)
    }
   
    required init(_ viewModel: T, delegate: AppFlowCoordinating? = nil) {
        self.viewModel = viewModel
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func updateImage(_ item: PopularMovieDetailViewModel) {
        guard item.imageUrl != nil else { return }
        MovieDetailImageCaching.publicCache.load(url: item.imageUrl as NSURL, item: item) { [weak self] (fetchedItem, image) in
            guard let img = image, img != fetchedItem.image else { return }
            guard var updatedSnapshot = self?.dataSource.snapshot() else { return }
            guard let item = self?.viewModel as? PopularMovieDetailViewModel else { return }
            item.image = img
            updatedSnapshot.reloadItems([item])
            self?.dataSource.apply(updatedSnapshot, animatingDifferences: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        internalSetup()
        configureTableView()
        
        dataSource = UITableViewDiffableDataSource<MovieSection, PopularMovieDetailViewModel>(tableView: tableView) {
           [weak self] (tableView: UITableView, indexPath: IndexPath, item: PopularMovieDetailViewModel) -> UITableViewCell? in
            guard let self = self else { return UITableViewCell() }
            let cell: MovieDetailCell = tableView.dequeueReusableCell(forIndexPath: indexPath) as MovieDetailCell
            cell.configureWith(item, delegate: self)
            self.updateImage(item)
            return cell
        }
        self.dataSource.defaultRowAnimation = .fade
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchDetails()
    }
    
    deinit {
        Log.debug("*********Deallocting PopularMovieDetailViewController***********")
    }
}

extension PopularMovieDetailViewController: MovieDetailDelegate {
    func movieHomeTapped(_ sender: UIButton) {
        guard let movieHomePageUrl = viewModel.homePageUrl, !movieHomePageUrl.isEmpty else {
            presentError()
            return
        }
        delegate?.coordinateToMovieHomePage(movieHomePageUrl, movieName: viewModel.title)
    }
}

//MARK: Api
extension PopularMovieDetailViewController {
    private func fetchDetails() {
        viewModel.data.addObserver(self) { [weak self] _ in
            var initialSnapshot = NSDiffableDataSourceSnapshot<MovieSection, PopularMovieDetailViewModel>()
            initialSnapshot.appendSections([.main])
            guard let vm = self?.viewModel as? PopularMovieDetailViewModel  else { return }
            initialSnapshot.appendItems([vm])
            self?.dataSource.apply(initialSnapshot, animatingDifferences: true)
        }
    }
}
