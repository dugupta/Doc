//
//  AppDelegate.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import UIKit

struct FormatManager: FormatManaging { }

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func createContainer() -> ServiceResolving {
        let container: ServiceResolving = Container()
        container.register(FormatManaging.self) { _ in FormatManager() }
        return container
    }
    
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.window = UIWindow(frame: UIScreen.main.bounds)
        let navigationController = UINavigationController()
        self.window?.rootViewController = navigationController
        self.window?.backgroundColor = .white
        self.window?.makeKeyAndVisible()
        self.window?.isHidden = false
        let flowCoordinator = AppFlowCoordinator(navigationController)
        flowCoordinator.start()
        let container = createContainer()
        let formatManager: FormatManaging = container.resolve()
        print(formatManager.append("Durgesh"))
        return true
    }
}
