//
//  Binding.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import Combine
import UIKit

class DynamicValue<T> {
    
    typealias CompletionHandler = ((T) -> Void)
    
    var value : T {
        didSet {
            self.notify()
        }
    }
    
    private var observers = [String: CompletionHandler]()
    
    init(_ value: T) {
        self.value = value
    }
    
    func addObserver(_ observer: NSObject, completionHandler: @escaping CompletionHandler) {
        observers[observer.description] = completionHandler
    }
    
    func addAndNotify(observer: NSObject, completionHandler: @escaping CompletionHandler) {
        self.addObserver(observer, completionHandler: completionHandler)
        self.notify()
    }
    
    private func notify() {
        observers.forEach({ $0.value(value) })
    }
    
    deinit {
        observers.removeAll()
    }
}

protocol GenericDataSource {
    associatedtype Item
    var data: DynamicValue<[Item]> { get }
}


/*
protocol GlobalUpdating {
    func update()
}

extension GlobalUpdating {
    func registerForUpdate() {
        update()
    }
}

class Observer {
    static let updateChanged = Notification.Name("EnvironmentChangeUpdate")
    static let shared = Observer()
    
    private var sinks  = [AnyCancellable]()
    
    var values = [Any]()
    
    private init() { }
    
    
    func register<T: ObservableObject>(_ value: T) {
        values.append(value)
        
        let sink = value.objectWillChange.sink { _ in
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: Self.updateChanged, object: value)
            }
        }
        sinks.append(sink)
    }
}


@propertyWrapper struct Global<ObjectType: ObservableObject> {
    var wrappedValue: ObjectType

    init() {
        if let value = Observer.shared.values.first(where: { $0 is ObjectType }) as? ObjectType {
            self.wrappedValue = value
        } else {
            fatalError("Missing Type in Environment")
        }
    }
}








class AppSettings:  ObservableObject {
    @Published var language = "English"
}

class Environment {
    static let updateChanged = Notification.Name("EnvironmentChangeUpdate")
    static let shared = Environment()
    
    private var sinks  = [AnyCancellable]()
    
    var values = [Any]()
    
    private init() { }
    
    
    func register<T: ObservableObject>(_ value: T) {
        values.append(value)
        
        let sink = value.objectWillChange.sink { _ in
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: Self.updateChanged, object: value)
            }
        }
        sinks.append(sink)
    }
}


class SecondViewController: UIViewController, GlobalUpdating {
    
    @Global var appSettings: AppSettings
    
    func update() {
        print("Value of app Settings in second view controller is \(appSettings.language)")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerForUpdate()
    }
}




class ViewController: UIViewController, GlobalUpdating {
    
    
    @Global var appSettings: AppSettings
    
    func update() {
        print("Value of app Settings in ViewController controller is \(appSettings.language)")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerForUpdate()
        
        let second = SecondViewController()
        
        print("Value from second view controller = \(second.appSettings.language)")
        
        appSettings.language = "Hindi"
        
        print("Value from second view controller after change = \(second.appSettings.language)")
      
    }
}
*/
