//
//  PopularMoviesViewModelTest.swift
//  walmart-coding-challengeTests
//
//  Created by Durgesh Lal on 12/7/20.
//

import XCTest
@testable import walmart_coding_challenge

class PopularMoviesViewModelTest: XCTestCase {

    private var viewModel: PopularMoviesListViewModel!
    override func setUpWithError() throws {
        viewModel = PopularMoviesListViewModel(MockPopularMoviesDataManager())
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }
 
    func testScreenTitle() {
        XCTAssertEqual(viewModel.screenTitle, "Popular movies")
    }

    func testItemAtIndex() {
        let itemOne = viewModel.itemAt(0)
        XCTAssertEqual(itemOne.popularityScore, "Popularity score: 2267.77")
        XCTAssertEqual(itemOne.releaseYear, "Release date: 2020-11-20")
        XCTAssertEqual(itemOne.genre, "Genre: Action, Fantasy, Science Fiction")
        XCTAssertEqual(itemOne.title, "Jiu Jitsu")
        
        let itemTen = viewModel.itemAt(10)
        XCTAssertEqual(itemTen.popularityScore, "Popularity score: 859.391")
        XCTAssertEqual(itemTen.releaseYear, "Release date: 2020-11-18")
        XCTAssertEqual(itemTen.genre, "Genre: Adventure, Family, Fantasy")
        XCTAssertEqual(itemTen.title, "The Christmas Chronicles: Part Two")
        
        let last = viewModel.itemAt(19)
        XCTAssertEqual(last.popularityScore, "Popularity score: 644.539")
        XCTAssertEqual(last.releaseYear, "Release date: 2020-09-29")
        XCTAssertEqual(last.genre, "Genre: Action, Adventure, Drama, Thriller")
        XCTAssertEqual(last.title, "Welcome to Sudden Death")
    }
    
    func testMoviesList() {
        XCTAssertEqual(viewModel.moviesList.count, 20)
        
        let itemOne = viewModel.moviesList.first
        XCTAssertEqual(itemOne?.popularityScore, "Popularity score: 2267.77")
        XCTAssertEqual(itemOne?.releaseYear, "Release date: 2020-11-20")
        XCTAssertEqual(itemOne?.genre, "Genre: Action, Fantasy, Science Fiction")
        XCTAssertEqual(itemOne?.title, "Jiu Jitsu")
        
        let itemTen = viewModel.moviesList[5]
        XCTAssertEqual(itemTen.popularityScore, "Popularity score: 804.565")
        XCTAssertEqual(itemTen.releaseYear, "Release date: 2019-10-02")
        XCTAssertEqual(itemTen.genre, "Genre: Crime, Drama, Thriller")
        XCTAssertEqual(itemTen.title, "Joker")
        
        let last = viewModel.moviesList.last
        XCTAssertEqual(last?.popularityScore, "Popularity score: 644.539")
        XCTAssertEqual(last?.releaseYear, "Release date: 2020-09-29")
        XCTAssertEqual(last?.genre, "Genre: Action, Adventure, Drama, Thriller")
        XCTAssertEqual(last?.title, "Welcome to Sudden Death")
    }
}
