#   PYMK Take-Home Assignment

## Assignment Description

Assignment is to build a minimum viable product of an app called “People You May Know”. In the app, the user will see suggestions for people they might know and want to send a friend request to.

# Design Pattern used [MVVM-C]
### MVVM Pattern is used as aroot design pattern to modularize the components so that the view models containg the presenattion logic are unit testable. For unit testing, static json files are being used.

### Model
Raw objects, basically replica of json with few changes in key per need basis with the help of CodingKey in Swift

### View Model
Modified version of Model with all the presenation tweaks and business logic. Also responsible for communicating between UI and Model.

### View/ View Controller
Underlying view or root views are connected to the view model through view controller that its hosted in.


# Flow Chart

App Delegate -> AppCoordinator Start the flow from app cordinator using start() method 

## Simple UI controller flow

    UIViewController(ViewModel(DataManager(NetworkManager)))
   1. View Model needs a Datamanger to get raw model objects.
   2. Data Manager needs a network manager to fetch remote data, and call back to data manager
   3. Once get data from view model, view model will refine and notify controller to reload UI.


# Input data 
Input data is an array of user having id, name and list of friend ids

[
  {
    "id": 1,
    "name": "Facebook Candidate",
    "friends": [25, 24, 16, 8, 13, 12, 7, 15]
  },
  {
    "id": 2,
    "name": "Anne Emerson",
    "friends": [3, 21, 4, 20, 24, 5, 7, 12, 18]
  }
]

# Output UI
Is a List view having current user as controller title and list of suggested friends defined by rules in the requirement

There are 2 func used to achieve the requirememts
1. func socialDistance (source: Int, destination: Int, graph: Graph) -> Int
    Its a func used to find the shortest path in a graph from source to destination using "Dijkstra's Algorithm"
    The response from mock json is converted into a graph for this func
2.  func mutualFriendsCountfor(_ facebookCandidate: UserViewModel, user: UserViewModel) -> Int?
    This function is defined to find the mutual friends between facebook candidate and other users.


