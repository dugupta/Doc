//
//  UserListViewModelTest.swift
//  PeopleYouMayKnowTests
//
//  Created by Durgesh Lal on 8/17/21.
//

import XCTest
@testable import PeopleYouMayKnow


class UserListViewModelTest: XCTestCase {
    
    func testScreenTitle() {
        let viewModel = UserListViewModel(UserListDataManager(MockNetworkManager()))
        viewModel.notify = {
            XCTAssertEqual(viewModel.screenTitle, "Facebook Candidate")
        }
        viewModel.fetchUserList("TestSuite")
    }
    
    func testNumberOfRows() {
        let viewModel = UserListViewModel(UserListDataManager(MockNetworkManager()))
        viewModel.notify = {
            XCTAssertEqual(viewModel.numberOfRows, 25)
        }
        viewModel.fetchUserList("TestSuite")
    }
    
    func testUserAtIndex0() {
        let viewModel = UserListViewModel(UserListDataManager(MockNetworkManager()))
        viewModel.notify = {
            XCTAssertEqual(viewModel.user(0).displayUserString, "Noel Serrano - Social distance:  1, Mutual friends: 2")
        }
        viewModel.fetchUserList("TestSuite")
    }
    
    func testUserAtIndex10() {
        let viewModel = UserListViewModel(UserListDataManager(MockNetworkManager()))
        viewModel.notify = {
            XCTAssertEqual(viewModel.user(10).displayUserString, "Anne Emerson - Social distance:  2, Mutual friends: 3")
        }
        viewModel.fetchUserList("TestSuite")
    }
    
    func testUserAtIndexLast() {
        let viewModel = UserListViewModel(UserListDataManager(MockNetworkManager()))
        viewModel.notify = {
            XCTAssertEqual(viewModel.user(viewModel.numberOfRows - 1).displayUserString, "Shields Gilliam - Social distance:  5")
        }
        viewModel.fetchUserList("TestSuite")
    }
    ///Generally we used to have one assert statement per test case, just adding for now
    func testAllUserSequence() {
        let viewModel = UserListViewModel(UserListDataManager(MockNetworkManager()))
        viewModel.notify = {
            XCTAssertEqual(viewModel.user(0).displayUserString, "Noel Serrano - Social distance:  1, Mutual friends: 2")
            XCTAssertEqual(viewModel.user(1).displayUserString, "Cristina Patton - Social distance:  1, Mutual friends: 1")
            XCTAssertEqual(viewModel.user(2).displayUserString, "Campos Benton - Social distance:  1, Mutual friends: 1")
            XCTAssertEqual(viewModel.user(3).displayUserString, "Whitfield Ramsey - Social distance:  1, Mutual friends: 1")
            XCTAssertEqual(viewModel.user(4).displayUserString, "Santana English - Social distance:  1, Mutual friends: 1")
            XCTAssertEqual(viewModel.user(5).displayUserString, "Freida Evans - Social distance:  1")
            XCTAssertEqual(viewModel.user(6).displayUserString, "Josefa Coffey - Social distance:  1")
            XCTAssertEqual(viewModel.user(7).displayUserString, "Katharine Ingram - Social distance:  1")
            XCTAssertEqual(viewModel.user(8).displayUserString, "Alana Solomon - Social distance:  2, Mutual friends: 5")
            XCTAssertEqual(viewModel.user(9).displayUserString, "Marion Fields - Social distance:  2, Mutual friends: 4")
            XCTAssertEqual(viewModel.user(10).displayUserString, "Anne Emerson - Social distance:  2, Mutual friends: 3")
            XCTAssertEqual(viewModel.user(11).displayUserString, "Snow Valentine - Social distance:  2, Mutual friends: 3")
            XCTAssertEqual(viewModel.user(12).displayUserString, "Stewart Graves - Social distance:  2, Mutual friends: 3")
            XCTAssertEqual(viewModel.user(13).displayUserString, "Alba Gates - Social distance:  2, Mutual friends: 2")
            XCTAssertEqual(viewModel.user(14).displayUserString, "Louise Pennington - Social distance:  2, Mutual friends: 2")
            XCTAssertEqual(viewModel.user(15).displayUserString, "Claire Kemp - Social distance:  2, Mutual friends: 2")
            XCTAssertEqual(viewModel.user(16).displayUserString, "Vasquez Lowery - Social distance:  2, Mutual friends: 2")
            XCTAssertEqual(viewModel.user(17).displayUserString, "Ashley Hopper - Social distance:  2, Mutual friends: 1")
            XCTAssertEqual(viewModel.user(18).displayUserString, "Suarez Rosario - Social distance:  2, Mutual friends: 1")
            XCTAssertEqual(viewModel.user(19).displayUserString, "Newton Holmes - Social distance:  3")
            XCTAssertEqual(viewModel.user(20).displayUserString, "Deana Fowler - Social distance:  3")
            XCTAssertEqual(viewModel.user(21).displayUserString, "Angelique Vincent - Social distance:  3")
            XCTAssertEqual(viewModel.user(22).displayUserString, "Jocelyn Wolf - Social distance:  4")
            XCTAssertEqual(viewModel.user(23).displayUserString, "Cameron Bryant - Social distance:  4")
            XCTAssertEqual(viewModel.user(24).displayUserString, "Shields Gilliam - Social distance:  5")
        }
        viewModel.fetchUserList("TestSuite")
    }

}
