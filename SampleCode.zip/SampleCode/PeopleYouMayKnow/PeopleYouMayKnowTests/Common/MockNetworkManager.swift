//
//  MockNetworkManager.swift
//  PeopleYouMayKnowTests
//
//  Created by Durgesh Lal on 8/17/21.
//

import Foundation
@testable import PeopleYouMayKnow

struct MockNetworkManager: NetworkManaging {
    
    private func process<T: Decodable>(_ data: Data? = nil, callBack: @escaping (RequestStatus, T?) -> Void) {
        if let _data = data {
            let decoder = JSONDecoder()
            let model = try? decoder.decode(T.self, from: _data)
            callBack(.success, model)
            return
        }
        callBack(RequestStatus.failure(.badResponse), nil)
    }

    func request<T: Decodable>(url: String, callBack: @escaping (RequestStatus, T?) -> Void) {
        if let bundlePath = Bundle.current.path(forResource: url, ofType: "json"),
           let data = try? String(contentsOfFile: bundlePath).data(using: .utf8) {
            process(data, callBack: callBack)
        } else {
            fatalError("Facebook: Error while fetching data from local json")
        }
    }
}
