//
//  AppCoordinator.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/16/21.
//

import Foundation
import UIKit

protocol Coordinator: AnyObject {
    var children: [Coordinator] { get set }
    var navigationController: UINavigationController { get set }
    func start()
}


class AppCoordinator: NSObject, Coordinator {
    
    var children: [Coordinator] = []
    
    var navigationController: UINavigationController
    
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let coordinator = UserListCoordinator(navigationController)
        children.append(coordinator)
        coordinator.parent = self
        coordinator.start()
    }
    
    func childDidFinish(_ child: Coordinator?) {
        if let index = children.firstIndex(where: { $0 === child }) {
            children.remove(at: index)
        }
    }
}


class UserListCoordinator: Coordinator {
    weak var parent: AppCoordinator?
    
    var children: [Coordinator] = []
    
    var navigationController: UINavigationController
    
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        coordinateToUserList()
    }
    
    func didFinishUserList() {
        parent?.childDidFinish(self)
    }
}

// MARK:- Private Functions
extension UserListCoordinator {
    private func coordinateToUserList() {
        let viewModel = UserListViewModel()
        let controller = UserListViewController(viewModel, coordinator: self)
        navigationController.pushViewController(controller, animated: false)
    }
}
