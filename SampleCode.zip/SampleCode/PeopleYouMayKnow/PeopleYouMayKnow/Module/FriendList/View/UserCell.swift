//
//  UserCell.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/16/21.
//

import UIKit

class UserCell: UITableViewCell, FromNib {

    @IBOutlet weak var userLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func configureWithUser(_ user: UserViewModeling) {
        userLabel.text = user.displayUserString
    }
}
