//
//  FriendListDataManager.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/16/21.
//

import Foundation

protocol UserListDataManaging {
    init(_ networkManager: NetworkManaging)
    // MARK: - User List
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    
    func userList(_ listName: String, callBack: @escaping (RequestStatus, [User]?) -> Void)
}

struct UserListDataManager: UserListDataManaging {
   
    private var networkManager: NetworkManaging
    init(_ networkManager: NetworkManaging = NetworkManager()) {
        self.networkManager = networkManager
    }
    
    func userList(_ listName: String, callBack: @escaping (RequestStatus, [User]?) -> Void) {
        networkManager.request(url: listName, callBack: callBack)
    }
}

