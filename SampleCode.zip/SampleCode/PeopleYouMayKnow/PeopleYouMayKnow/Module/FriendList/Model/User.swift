//
//  User.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/16/21.
//

import Foundation

struct User: Codable {
    let id: Int?
    let name: String?
    let friends: [Int]?
}
