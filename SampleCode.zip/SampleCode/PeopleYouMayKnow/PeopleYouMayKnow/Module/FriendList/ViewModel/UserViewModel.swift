//
//  UserViewModel.swift
//  PeopleYouMayKnow
//
//  Created by Durgesh Lal on 8/17/21.
//

import Foundation

protocol UserViewModeling {
    var displayUserString: String? { get }
}

class UserViewModel: UserViewModeling {
    var name: String?
    var friends: [Int]?
    var socialDistance: Int? = nil
    var mutualFriends: Int? = nil
    
    init(_ name: String?, friends: [Int]?) {
        self.name = name
        self.friends = friends
    }
}

extension UserViewModel {
    
    var displayUserString: String? {
        var result = "\(name ?? "") - "
        
        if let value = socialDistance {
            result += "Social distance:  \(value)"
        }
        
        if let value = mutualFriends {
            result += ", Mutual friends: \(value)"
        }
        return result
    }
}
