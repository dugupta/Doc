//
//  AppDelegate.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.window = UIWindow(frame: UIScreen.main.bounds)
        let navigationController = UINavigationController()
        self.window?.rootViewController = navigationController
        self.window?.backgroundColor = .white
        self.window?.makeKeyAndVisible()
        self.window?.isHidden = false
        let flowCoordinator = AppFlowCoordinator(navigationController)
        flowCoordinator.start()
        return true
    }
}
