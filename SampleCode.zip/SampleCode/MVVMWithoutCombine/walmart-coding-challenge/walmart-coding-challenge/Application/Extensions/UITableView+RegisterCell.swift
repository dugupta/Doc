//
//  UITableView+RegisterCell.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import UIKit

extension UITableView {
    
    func register<T: UITableViewCell> (_: T.Type) where T: ViewReusable & ViewLodable {
        let nib = UINib(nibName: T.NibName, bundle: nil)
        register(nib, forCellReuseIdentifier: T.reuseIdentifier)
    }
}

extension UITableView {
    
    func dequeueReusableCell<T: UITableViewCell>(forIndexPath indexPath: IndexPath) -> T where T: ViewReusable {
        guard let cell = dequeueReusableCell(withIdentifier: T.reuseIdentifier, for: indexPath as IndexPath) as? T else {
            fatalError("Could not dequeue cell with identifier: \(T.reuseIdentifier)")
        }
        return cell
    }
}

protocol ViewReusable: class {}
extension ViewReusable where Self: UIView {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}

protocol ViewLodable: class { }
extension ViewLodable where Self: UIView {
    static var NibName: String {
        return String(describing: self)
    }
}

protocol FromNib: ViewReusable, ViewLodable { }

