//
//  PopularMoviesListViewController.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import UIKit

enum MovieSection {
    case main
}

class PopularMoviesListViewController<T: PopularMoviesListViewModeling>: UITableViewController {
    
    private var viewModel: T
    private var delegate: AppFlowCoordinating?
    
    private var dataSource: UITableViewDiffableDataSource<MovieSection, PopularMovieViewModel>! = nil
    
    private func internalSetup() {
        title = viewModel.screenTitle
        view.backgroundColor = .white
    }
    
    private func configureTableView() {
        tableView.register(PopularMovieCell.self)
    }
   
    required init(_ viewModel: T, delegate: AppFlowCoordinating? = nil) {
        self.viewModel = viewModel
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func updateImage(_ item: PopularMovieViewModel) {
        guard item.imageUrl != nil else { return }
        MovieListImageCaching.publicCache.load(url: item.imageUrl as NSURL, item: item) { (fetchedItem, image) in
            guard let img = image, img != fetchedItem.image else { return }
            var updatedSnapshot = self.dataSource.snapshot()
            guard let datasourceIndex = updatedSnapshot.indexOfItem(fetchedItem) else { return }
            guard let item = self.viewModel.itemAt(datasourceIndex) as? PopularMovieViewModel else { return }
            item.image = img
            updatedSnapshot.reloadItems([item])
            self.dataSource.apply(updatedSnapshot, animatingDifferences: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        internalSetup()
        configureTableView()
        
        dataSource = UITableViewDiffableDataSource<MovieSection, PopularMovieViewModel>(tableView: tableView) {
            (tableView: UITableView, indexPath: IndexPath, item: PopularMovieViewModel) -> UITableViewCell? in
            let cell: PopularMovieCell = tableView.dequeueReusableCell(forIndexPath: indexPath) as PopularMovieCell
            cell.configureWith(item)
            self.updateImage(item)
            return cell
        }
        
        self.dataSource.defaultRowAnimation = .fade
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.fetchList()
    }
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let bottom = scrollView.contentSize.height - scrollView.frame.size.height
        let buffer: CGFloat = 200.0
        let scrollPosition = scrollView.contentOffset.y
        if scrollPosition > (bottom - buffer) {
            viewModel.fetchPopularMoviesList()
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let movieId = viewModel.movieIdAt(indexPath.row) else { return }
        delegate?.coordinateToPopularMovieDetailPage(movieId)
    }
}

///Api
extension PopularMoviesListViewController {
    private func fetchList() {
        viewModel.data.addObserver(self) { [weak self] _ in
            guard let self = self else { return }
            var initialSnapshot = NSDiffableDataSourceSnapshot<MovieSection, PopularMovieViewModel>()
            initialSnapshot.appendSections([.main])
            guard let data = self.viewModel.moviesList as? [PopularMovieViewModel] else { return }
            initialSnapshot.appendItems(data)
            self.dataSource.apply(initialSnapshot, animatingDifferences: true)
        }
    }
}
