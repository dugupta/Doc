//
//  GenreResponse.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation

extension Bundle {
    static var current: Bundle {
        class __ { }
        return Bundle(for: __.self)
    }
}

struct Genre {
    static var object = Genre()
    var genreResponse: GenreResponse?
    init() { }
    
    mutating func genreStringFrom(_ genres:[Int]) -> String? {
        if genreResponse == nil {
            //Read from static json file
            self.genreResponse = genreFrom()
        }
        let filteredGenres = genreResponse?.genres?.filter({ genres.contains($0.id ?? -1) })
        let retValue: String = filteredGenres?.reduce("Genre: ", { (result, item) -> String in
            return result + (item.name ?? "") + ", "
        }) ?? ""
        return String(retValue.dropLast().dropLast())
    }
    
    private func genreFrom(_ file: String = "Genres") -> GenreResponse? {
        let bundle = Bundle.current
        guard let path = bundle.path(forResource: file, ofType: "json") else { return nil }
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: path), options: .uncachedRead) else { return nil }
        let decoder = JSONDecoder()
        let serializedObject = try? decoder.decode(GenreResponse.self, from: data)
        return serializedObject
    }
}


struct GenreResponse: Codable {
    let genres: [Item]?
    
    struct Item: Codable {
        let id: Int?
        let name: String?
    }
}
