//
//  PopularMoviesDetailResponse.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation

struct PopularMoviesDetailResponse: Codable {
    let title: String?
    let genres: [GenreResponse.Item]?
    let popularity: Double?
    let releaseDate: String?
    let overview: String?
    let runtime: Int?
    let thumbnailImageUrl: String?
    let homepage: String?
    
    private enum CodingKeys : String, CodingKey {
        case releaseDate = "release_date", title, homepage, genres, popularity, overview, runtime, thumbnailImageUrl = "backdrop_path"
    }
}
