//
//  PopularMovieViewModeling.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation

protocol PopularMovieViewModeling: Hashable {
    ///ViewModel data type
    associatedtype Item
    
    // MARK: Init
    init(_ item: Item)
    
    var rawItem: Item { get }
    
    // MARK: Cell Properties
    var title: String? { get }
    var genre: String? { get }
    var releaseYear: String? { get }
    var popularityScore: String? { get }
}

