//
//  PopularMovieDetailViewModeling.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation

protocol PopularMovieDetailViewModeling {
    ///ViewModel data
    associatedtype Item
    var data: DynamicValue<[Item]> { get }
    
    // MARK: Init
    init(_ dataManager: PopularMovieDetailDataManaging)
    
    // MARK: Cell Properties
    var title: String? { get }
    var genre: String? { get }
    var releaseYear: String? { get }
    var runTime: String? { get }
    var popularityScore: String? { get }
    var screenTitle: String? { get }
    var overView: String? { get }
    var homePageUrl: String? { get }
}
