//
//  PopularMovieDetailViewModel.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import UIKit

class PopularMovieDetailViewModel: Hashable, PopularMovieDetailViewModeling {
    
    typealias Item = PopularMoviesDetailResponse
    var data: DynamicValue<[PopularMoviesDetailResponse]> = DynamicValue([])
    
    private var dataManager: PopularMovieDetailDataManaging
    var image: UIImage? = nil
    var imageUrl: URL! = URL(string: "")
    let identifier = UUID()
    
    required init(_ dataManager: PopularMovieDetailDataManaging) {
        self.dataManager = dataManager
        fetchPopularMoviesDetails()
    }
   
    var screenTitle: String? {
        return Constants.movieDetails.value
    }
    
    var overView: String? {
        return "\(Constants.overview.value)\n\(data.value.first?.overview ?? "")"
    }
    
    var runTime: String? {
        if let runTime = data.value.first?.runtime {
            return String(format: Constants.runTime.value, runTime)
        }
        return nil
    }
    
    var title: String? {
        return data.value.first?.title
    }
    
    var genre: String? {
        guard let genres = data.value.first?.genres else { return nil }
        let retValue: String = genres.reduce("Genre: ", { (result, item) -> String in
            return result + item.name! + ", "
        })
        return String(retValue.dropLast().dropLast())
    }
    
    var releaseYear: String? {
        if let releaseDate = data.value.first?.releaseDate {
            return "\(Constants.releaseDate.value) \(releaseDate)"
        }
        return nil
    }
    
    var popularityScore: String? {
        if let score = data.value.first?.popularity {
            return "\(Constants.popuarityScore.value) \(score)"
        }
        return nil
    }
    
    var homePageUrl: String? {
        return data.value.first?.homepage
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(identifier)
    }
    
    static func == (lhs: PopularMovieDetailViewModel, rhs: PopularMovieDetailViewModel) -> Bool {
        return lhs.identifier == rhs.identifier
    }
}

extension PopularMovieDetailViewModel {
    func fetchPopularMoviesDetails() {
        dataManager.moviesDetail { [weak self] (status, response) in
            guard .success == status else { return }
            guard let detail = response else { return }
            self?.imageUrl = URL(string: "\(BaseUrl.fetchImage.url)\(detail.thumbnailImageUrl ?? "")")
            self?.data.value = [detail]
        }
    }
}

extension PopularMovieDetailViewModel {
    enum Constants: String {
        case movieDetails = "Movie details"
        case overview = "Overview:"
        case releaseDate = "Release date:"
        case popuarityScore = "Popularity score:"
        case runTime = "Run time: %d Min"
        
        var value: String {
            return self.rawValue
        }
    }
}
