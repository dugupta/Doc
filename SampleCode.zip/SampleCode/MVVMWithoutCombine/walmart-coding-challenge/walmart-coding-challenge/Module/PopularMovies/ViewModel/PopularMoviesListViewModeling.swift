//
//  PopularMoviesListViewModeling.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation

protocol PopularMoviesListViewModeling {
    ///ViewModel data
    associatedtype Item
    var data: DynamicValue<[Item]> { get }
    
    // MARK: Init & Api
    init(_ dataManager: PopularMoviesDataManaging)
    func fetchPopularMoviesList()
    func fetchGenres()
    
    // MARK: Controller related properties
    var screenTitle: String? { get }
    
    // MARK: Table View Data Source
    var numberOfRows: Int { get }
    func itemAt(_ indexPath: Int) -> Item
    var moviesList: [Item] { get }
    func movieIdAt(_ indexPath: Int) -> String?
}

