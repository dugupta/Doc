//
//  PopularMovieViewModeling.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/8/20.
//

import Foundation
import UIKit

class PopularMovieViewModel: Hashable, PopularMovieViewModeling {
   
    typealias Item = PopularMoviesResponse.Movie
    private var item: Item
    
    var image: UIImage?
    let imageUrl: URL!
    let identifier = UUID()
    
    required init(_ item: Item) {
        self.item = item
        self.image = nil
        
        if let url = item.posterImageUrl  {
            self.imageUrl = URL(string: "\(BaseUrl.fetchImage.url)\(url)")
        } else {
            self.imageUrl = URL(string: "")
        }
    }
    
    var rawItem: Item {
        return item
    }
    
    var title: String? {
        return item.title
    }
    
    var genre: String? {
        guard let genres = item.genreIds else { return nil }
        return "\(Genre.object.genreStringFrom(genres) ?? "")"
    }
    
    var releaseYear: String? {
        if let releaseDate = item.releaseDate {
            return "\(Constant.releaseDate.value) \(releaseDate)"
        }
        return nil
    }
    
    var popularityScore: String? {
        if let score = item.popularity {
            return "\(Constant.popularityScore.value) \(score)"
        }
        return nil
    }
   
    func hash(into hasher: inout Hasher) {
        hasher.combine(identifier)
    }
    
    static func == (lhs: PopularMovieViewModel, rhs: PopularMovieViewModel) -> Bool {
        return lhs.identifier == rhs.identifier
    }
}

extension PopularMovieViewModel {
    enum Constant: String {
        case releaseDate = "Release date:"
        case popularityScore = "Popularity score:"
        
        var value: String {
            return rawValue
        }
    }
}
