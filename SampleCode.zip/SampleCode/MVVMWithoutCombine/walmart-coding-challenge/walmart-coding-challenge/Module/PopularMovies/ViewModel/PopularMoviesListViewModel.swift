//
//  PopularMoviesViewModel.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//


class PopularMoviesListViewModel: PopularMoviesListViewModeling {
    
    typealias Item = PopularMovieViewModel
    var data: DynamicValue<[PopularMovieViewModel]> = DynamicValue([])
    
    private var dataManager: PopularMoviesDataManaging
    required init(_ dataManager: PopularMoviesDataManaging = PopularMoviesDataManager()) {
        self.dataManager = dataManager
        self.fetchGenres()
        self.fetchPopularMoviesList()
    }
    
    lazy var screenTitle: String? = {
        return "Popular movies"
    }()
}

// MARK: Table View Data Source
extension PopularMoviesListViewModel {
    var numberOfRows: Int {
        return data.value.count
    }
    
    func itemAt(_ indexPath: Int) -> PopularMovieViewModel {
        return data.value[indexPath]
    }
    
    var moviesList: [PopularMovieViewModel]  {
        return self.data.value
    }
    
    func movieIdAt(_ indexPath: Int) -> String? {
        if let id = data.value[indexPath].rawItem.movieId {
            return "\(id)"
        }
        return nil
    }
}

// MARK: - APi calls
extension PopularMoviesListViewModel {
    
    func fetchPopularMoviesList() {
        dataManager.moviesList { [weak self] (status, list) in
            Log.debug("************list Response***************\n\(String(describing: list))")
            self?.data.value += (list?.results?.map({ PopularMovieViewModel($0) }) ?? [])
        }
    }
    
    func fetchGenres() {
        dataManager.fetchGenres { (status, response) in
            guard .success == status else { return }
            Log.debug("************Genres Response***************\n\(String(describing: response))")
            Genre.object.genreResponse = response
        }
    }
}
