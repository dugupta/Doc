//
//  PopularMoviesDataManager.swift
//  walmart-coding-challenge
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation

protocol PopularMoviesDataManaging {
    init(_ networkManager: NetworkManaging)
    // MARK: - Populare Movie List
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    mutating func moviesList(_  callBack: @escaping (RequestStatus, PopularMoviesResponse?) -> Void)
    // MARK: - Genre
    /// - Note: Response Object must confirm to Codable Protocol
    /// - Parameters:
    ///   - callBack: Take a status and Response Object
    func fetchGenres(_  callBack: @escaping (RequestStatus, GenreResponse?) -> Void)
}

class PopularMoviesDataManager: PopularMoviesDataManaging {
    
    enum EndPoint {
        case moviesList
        case genre
        var url: String {
            switch self {
            case .moviesList:
                return "\(BaseUrl.polularMovies.url)movie/popular?"
            case .genre:
                return "\(BaseUrl.polularMovies.url)genre/movie/list?"
            }
        }
    }
    
    private var networkManager: NetworkManaging
    private var page: Int = 1
    private var isApiInprocess = false
    
    required init(_ networkManager: NetworkManaging = NetworkManager()) {
        self.networkManager = networkManager
    }
    
    func remoteList(_ callBack: @escaping (RequestStatus, PopularMoviesResponse?) -> Void) {
        networkManager.request(url: EndPoint.moviesList.url, params: ["page" : "\(page)"], callBack: callBack)
    }
    
     func moviesList(_ callBack: @escaping (RequestStatus, PopularMoviesResponse?) -> Void) {
        guard !isApiInprocess else { return }
        isApiInprocess = true
        Log.debug("************* Request Start ****************")
        Log.debug("Requesting data for page number \(page)")
        remoteList { (status, response) in
            self.isApiInprocess = false
            Log.debug("************* Request End ****************")
            Log.debug("Received data for page number \(self.page)")
            if .success == status {
                self.page += 1
            }
            callBack(status, response)
        }
    }
    
    func fetchGenres(_  callBack: @escaping (RequestStatus, GenreResponse?) -> Void) {
        networkManager.request(url: EndPoint.genre.url, params: nil, callBack: callBack)
    }
}
