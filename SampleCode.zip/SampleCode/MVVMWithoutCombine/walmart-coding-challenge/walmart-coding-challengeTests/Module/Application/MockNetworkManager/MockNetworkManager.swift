//
//  MockNetworkManager.swift
//  walmart-coding-challengeTests
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
@testable import walmart_coding_challenge

extension Bundle {
    static var current: Bundle {
        class __ { }
        return Bundle(for: __.self)
    }
}

struct MockNetworkManager: NetworkManaging {
    
    private func jsonData(_ file: String) -> Data? {
        let bundle = Bundle.current
        guard let path = bundle.path(forResource: file, ofType: "json") else { return nil }
        return try? Data(contentsOf: URL(fileURLWithPath: path), options: .uncachedRead)
    }
    
    func request<T>(url: String, params: [String : String]? = nil, callBack: @escaping (RequestStatus, T?) -> Void) where T : Decodable {
        if let data = jsonData(url) {
            let decoder = JSONDecoder()
            let jsonData = try? decoder.decode(T.self, from: data)
            callBack(.success, jsonData)
        } else {
            callBack(RequestStatus.failure(.badResponse), nil)
        }
    }
}
