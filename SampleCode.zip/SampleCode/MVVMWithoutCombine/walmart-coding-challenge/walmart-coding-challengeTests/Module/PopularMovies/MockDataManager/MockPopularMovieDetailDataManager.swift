//
//  MockPopularMovieDetailDataManager.swift
//  wallmart-coding-challengeTests
//
//  Created by Durgesh Lal on 12/9/20.
//

import Foundation
@testable import walmart_coding_challenge

struct MockPopularMovieDetailDataManager: PopularMovieDetailDataManaging {
 
    private var movieId: String
    private var networkManager: NetworkManaging
    
    init(_ movieId: String, networkManager: NetworkManaging = MockNetworkManager()) {
        self.movieId = movieId
        self.networkManager = networkManager
    }
    
    func moviesDetail(_ callBack: @escaping (RequestStatus, PopularMoviesDetailResponse?) -> Void) {
        networkManager.request(url: "MovieDetail", params: nil, callBack: callBack)
    }
}
