//
//  MockPopularMoviesDataManager.swift
//  walmart-coding-challengeTests
//
//  Created by Durgesh Lal on 12/7/20.
//

import Foundation
@testable import walmart_coding_challenge

struct MockPopularMoviesDataManager: PopularMoviesDataManaging {
    
    private var networkManager: NetworkManaging
    
    init(_ networkManager: NetworkManaging = MockNetworkManager()) {
        self.networkManager = networkManager
    }
    
    func moviesList(_ callBack: @escaping (RequestStatus, PopularMoviesResponse?) -> Void) {
        networkManager.request(url: "MoviesList", params: nil, callBack: callBack)
    }
    
    func fetchGenres(_ callBack: @escaping (RequestStatus, GenreResponse?) -> Void) {
        networkManager.request(url: "Genres", params: nil, callBack: callBack)
    }
}
