//
//  PopularMovieViewModelTest.swift
//  walmart-coding-challengeTests
//
//  Created by Durgesh Lal on 12/8/20.
//

import XCTest
@testable import walmart_coding_challenge

class PopularMovieViewModelTest: XCTestCase {

    private var viewModel: PopularMovieViewModel!
    
    override func setUpWithError() throws {
        let object = PopularMoviesResponse.Movie(releaseDate: "2020-08-14", popularity: 637.303, genreIds:  [16, 14, 12, 35, 10751], title: "The SpongeBob Movie: Sponge on the Run", posterImageUrl: "/jlJ8nDhMhCYJuzOw3f52CP1W8MW.jpg", thumbnailImageUrl: "/54yOImQgj8i85u9hxxnaIQBRUuo.jpg", overview:  "When his best friend Gary is suddenly snatched away, SpongeBob takes Patrick on a madcap mission far beyond Bikini Bottom to save their pink-shelled pal.", movieId: 76383)
        viewModel = PopularMovieViewModel(object)
        XCTAssertEqual(viewModel.rawItem.title, object.title)
        XCTAssertEqual(viewModel.rawItem.overview, object.overview)
        XCTAssertEqual(viewModel.rawItem.popularity, object.popularity)
        XCTAssertEqual(viewModel.rawItem.genreIds, object.genreIds)
        XCTAssertEqual(viewModel.rawItem.movieId, object.movieId)
    }
    
    func testTitle() {
        XCTAssertEqual(viewModel.title, "The SpongeBob Movie: Sponge on the Run")
    }
    func testGeners() {
        XCTAssertEqual(viewModel.genre, "Genre: Adventure, Animation, Comedy, Family, Fantasy")
    }
    
    func testReleaseYear() {
        XCTAssertEqual(viewModel.releaseYear, "Release date: 2020-08-14")
    }
    
    func testPopularityScale() {
        XCTAssertEqual(viewModel.popularityScore, "Popularity score: 637.303")
    }

    override func tearDownWithError() throws {
        viewModel = nil
    }

}
