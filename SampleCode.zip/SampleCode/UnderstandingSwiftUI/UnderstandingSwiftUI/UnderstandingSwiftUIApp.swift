//
//  UnderstandingSwiftUIApp.swift
//  UnderstandingSwiftUI
//
//  Created by Durgesh Lal on 3/21/22.
//

import SwiftUI

@main
struct UnderstandingSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
