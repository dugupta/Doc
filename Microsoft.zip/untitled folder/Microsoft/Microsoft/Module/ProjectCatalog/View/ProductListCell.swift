//
//  ProductListCell.swift
//  Wayfair
//
//  Created by Durgesh Lal on 4/15/22.
//

import UIKit

final class ProductListCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var tagline: UILabel!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var date: UILabel!

    private func applyTheme() {
        name.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        tagline.font = UIFont.systemFont(ofSize: 14)
        rating.font = UIFont.systemFont(ofSize: 12)
        date.font = UIFont.systemFont(ofSize: 12)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        applyTheme()
    }
    
    func updateCellWith(_ data: ProductItemViewModel) {
        name.text = data.name
        tagline.text = data.tagline
        rating.text = data.rating
        date.text = data.date
    }
    
    override func prepareForReuse() {
        name.text = nil
        tagline.text = nil
        rating.text = nil
        date.text = nil
    }
}

