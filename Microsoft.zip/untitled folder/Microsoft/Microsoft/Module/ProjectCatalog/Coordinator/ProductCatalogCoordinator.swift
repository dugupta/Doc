//
//  ProductCatalogCoordinator.swift
//  Wayfair
//
//  Created by Durgesh Lal on 4/15/22.
//

import Foundation
import UIKit

final class ProductCatalogCoordinator: Coordinator {
    
    internal var children: [Coordinator] = []
    internal var navigationController: UINavigationController
    required init(_ navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let storyboard = UIStoryboard(name: "ProductListViewController", bundle: nil)
        let controller = storyboard.instantiateViewController(
            identifier: "ProductListViewController",
            creator: { coder in
                let dataManager = ProductListDataManager(NetworkManager())
                let viewModel = ProductListViewModel(dataManager, formatManager: FormatManager())
                
                return ProductListViewController(viewModel, coder: coder)
            }
        )
        navigationController.pushViewController(controller, animated: false)
    }
}

