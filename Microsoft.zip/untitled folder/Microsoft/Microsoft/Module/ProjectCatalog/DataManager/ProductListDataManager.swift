//
//  ProductListDataManager.swift
//  Wayfair
//
//  Created by Durgesh Lal on 4/15/22.
//

import Foundation

protocol ProductListDataManaging {
    func fetchPrpductList(_ completion: @escaping (Result<[ProductItem], Failure>) -> Void)
}

struct ProductListDataManager: ProductListDataManaging {
    private static let prductListUrl = "https://api.wayfair.io/interview-sandbox/android/json-to-list/products.v1.json"
    private let networkManager: NetworkManaging
    
    init(_ networkManger: NetworkManaging) {
        self.networkManager = networkManger
    }
    
    func fetchPrpductList(_ completion: @escaping (Result<[ProductItem], Failure>) -> Void) {
        networkManager.request(url: ProductListDataManager.prductListUrl, params: nil, callBack: completion)
    }
}

