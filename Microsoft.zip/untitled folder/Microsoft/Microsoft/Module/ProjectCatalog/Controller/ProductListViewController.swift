//
//  ProductListViewController.swift
//  Wayfair
//
//  Created by Durgesh Lal on 4/15/22.
//

import UIKit

final class ProductListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    private let viewModel: ProductListViewModeling
    
    init?(_ viewModel: ProductListViewModeling, coder: NSCoder) {
        self.viewModel = viewModel
        super.init(coder: coder)
    }
    
    @available(*, unavailable, renamed: "init(viewModel:coder:)")     required init?(coder: NSCoder) {
        fatalError("Invalid way of decoding this class")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Product list"
        viewModel.fetchProductList { [weak self] success in
            guard let self = self else { return }
            if success {
                self.reloadData()
            } else {
                self.presentError()
            }
        }
    }
}

extension ProductListViewController {
    
    private func presentError() {
        let alert = UIAlertController(title: "Error", message: viewModel.errorMessage, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    private func reloadData() {
        tableView.reloadData()
    }
}

extension ProductListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ProductListCell") as? ProductListCell {
            let item = viewModel.itemAtIndex(indexPath.row)
            let data = ProductItemViewModel(item, formatManager: viewModel.formatManager)
            cell.updateCellWith(data)
            return cell
        }
        return UITableViewCell()
    }
}

extension ProductListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}

