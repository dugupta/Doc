//
//  ProductListViewModel.swift
//  Wayfair
//
//  Created by Durgesh Lal on 4/15/22.
//

import Foundation

protocol DepedencyInjection {
    var formatManager: FormatManaging { get }
}

protocol ErrorRepesentable {
    var errorMessage: String? { get }
}

protocol ProductListViewModeling: DepedencyInjection, ErrorRepesentable {
    var numberOfRows: Int { get }
    func itemAtIndex(_ index: Int) -> ProductItem
    func fetchProductList(_ completion: @escaping (Bool) -> Void)
}

final class ProductListViewModel: ProductListViewModeling {
    private var networkErrorMessage: String? = "Error while fetching product list!"
    private let dataManager: ProductListDataManaging
    internal let formatManager: FormatManaging
    
    private var list: [ProductItem] = []
    init(_ dataManager: ProductListDataManaging, formatManager: FormatManaging) {
        self.dataManager = dataManager
        self.formatManager = formatManager
    }
}

extension ProductListViewModel {
    var numberOfRows: Int { list.count }
    
    func itemAtIndex(_ index: Int) -> ProductItem {
        list[index]
    }
}

extension ProductListViewModel {
    private func failure(_ error: Failure, self: ProductListViewModel, completion: @escaping (Bool) -> Void) {
        print("Wayfair: Error \(error)")
        switch error {
        case .badRespons(let networkError):
            self.networkErrorMessage = networkError
        default:
            break
        }
        completion(false)
    }
    
    func fetchProductList(_ completion: @escaping (Bool) -> Void) {
        dataManager.fetchPrpductList() { [weak self] response in
            guard let self = self else { return }
            switch response {
            case .failure(let error):
                self.failure(error, self: self, completion: completion)
            case .success(let data):
                print("Wayfair: data \(data)")
                self.list = data
                completion(true)
            }
        }
    }
}

extension ProductListViewModel {
    
    var errorMessage: String? {
        networkErrorMessage
    }
}

