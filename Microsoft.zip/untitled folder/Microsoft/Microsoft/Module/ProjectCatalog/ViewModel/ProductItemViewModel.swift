//
//  ProductItemViewModel.swift
//  Wayfair
//
//  Created by Durgesh Lal on 4/15/22.
//

import Foundation

struct ProductItemViewModel {
    private let item: ProductItem
    private let formatManager: FormatManaging
    init(_ item: ProductItem, formatManager: FormatManaging) {
        self.item = item
        self.formatManager = formatManager
    }
    
    var name: String? {
        item.name
    }
    
    var tagline: String? {
        item.tagline
    }
    
    var date: String? {
        item.date
    }
    
    var rating: String? {
        if let rating = item.rating {
            return formatManager.roundToNearestHalf(rating)
        }
        return nil
    }
}

