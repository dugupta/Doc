//
//  MicrosoftUITests.swift
//  MicrosoftUITests
//
//  Created by Durgesh Lal on 09/27/22.
//

import XCTest

class MicrosoftUITests: XCTestCase { }
