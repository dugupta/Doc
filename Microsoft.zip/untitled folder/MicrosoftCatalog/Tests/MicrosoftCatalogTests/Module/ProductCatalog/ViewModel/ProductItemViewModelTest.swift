//
//  ProductItemViewModel.swift
//  MicrosoftTests
//
//  Created by Durgesh Lal on 09/27/22.
//

import XCTest
@testable import MicrosoftCatalog

class ProductItemViewModelTest: XCTestCase {
    
    var viewModel: ProductItemViewModel!
   
    override func setUp() async throws {
        let item = ProductItem(name: "Yellow Chair", tagline: "Great if you like yellow!", rating: 3, date: "1-15-2018")
        viewModel = ProductItemViewModel(item, formatManager: MockFormatManager(), dateManager: MockDateManager())
    }
    
    override func tearDown() async throws {
        viewModel = nil
    }
   
    func testName() {
        XCTAssertEqual(viewModel.name, "Yellow Chair")
    }
    
    func testTagline() {
        XCTAssertEqual(viewModel.tagline, "Great if you like yellow!")
    }
    
    func testRating() {
        XCTAssertEqual(viewModel.rating, "3.0")
    }
    
    func testDate() {
        XCTAssertEqual(viewModel.date, "January 15, 2018")
    }

}
