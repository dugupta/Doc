//
//  ProductListViewModelTest.swift
//  MicrosoftTests
//
//  Created by Durgesh Lal on 09/27/22.
//

import XCTest
import MicrosoftApis
import Combine

@testable import MicrosoftCatalog

class ProductListViewModelTest: XCTestCase {

    func testNumberOfRows() {
        let dataManager = MockProductListDataManager(MockNetworkManager())
        let viewModel = ProductListViewModel(dataManager, formatManager: MockFormatManager(), dateManager: MockDateManager())
        viewModel.fetchProductList { success in
            XCTAssertEqual(viewModel.numberOfRows, 5)
        }
    }
    
    func testItemAtIndexZero() {
        let dataManager = MockProductListDataManager(MockNetworkManager())
        let viewModel = ProductListViewModel(dataManager, formatManager: MockFormatManager(), dateManager: MockDateManager())
        
        viewModel.fetchProductList { success in
            XCTAssertEqual(viewModel.itemAtIndex(0).name, "Yellow Chair")
            XCTAssertEqual(viewModel.itemAtIndex(0).tagline, "Great if you like yellow!")
            XCTAssertEqual(viewModel.itemAtIndex(0).rating, 3)
            XCTAssertEqual(viewModel.itemAtIndex(0).date, "1-15-2018")
        }
    }
    
    func testNumberOfRowsCombine() {
        let dataManager = MockProductListDataManager(MockNetworkManager())
        let viewModel = ProductListViewModel(dataManager, formatManager: MockFormatManager(), dateManager: MockDateManager())
        viewModel.fetchProductList()
        let _: AnyCancellable? = viewModel.publisher.sink(receiveValue: { (callback) in
            if callback.completed {
                XCTAssertEqual(viewModel.numberOfRows, 5)
            }
        })
    }
    
    func testItemAtIndexZeroCombine() {
        let dataManager = MockProductListDataManager(MockNetworkManager())
        let viewModel = ProductListViewModel(dataManager, formatManager: MockFormatManager(), dateManager: MockDateManager())
        viewModel.fetchProductList()
        let _: AnyCancellable? = viewModel.publisher.sink(receiveValue: { (callback) in
            print("Durgesh : After api call")
            if callback.completed {
                XCTAssertEqual(viewModel.itemAtIndex(0).name, "Yellow Chair")
                  XCTAssertEqual(viewModel.itemAtIndex(0).tagline, "Great if you like yellow!")
                  XCTAssertEqual(viewModel.itemAtIndex(0).rating, 3)
                  XCTAssertEqual(viewModel.itemAtIndex(0).date, "1-15-2018")
            }
        })
    }
    
    func testNumberOfRowsAsyncAwait() {
        let dataManager = MockProductListDataManager(MockNetworkManager())
        let viewModel = ProductListViewModel(dataManager, formatManager: MockFormatManager(), dateManager: MockDateManager())
        
        Task {
            do {
                try await viewModel.fetchProductList()
                XCTAssertEqual(viewModel.numberOfRows, 5)
            } catch(let error) {
                print("Error is \(error)")
            }
        }
        
    }
    
    func testItemAtIndexZeroAsyncAwait() {
        let dataManager = MockProductListDataManager(MockNetworkManager())
        let viewModel = ProductListViewModel(dataManager, formatManager: MockFormatManager(), dateManager: MockDateManager())
        Task {
            do {
                try await viewModel.fetchProductList()
                XCTAssertEqual(viewModel.itemAtIndex(0).name, "Yellow Chair")
                XCTAssertEqual(viewModel.itemAtIndex(0).tagline, "Great if you like yellow!")
                XCTAssertEqual(viewModel.itemAtIndex(0).rating, 3)
                XCTAssertEqual(viewModel.itemAtIndex(0).date, "1-15-2018")
            } catch(let error) {
                print("Error is \(error)")
            }
        }
    }
}

