//
//  MockDataManager.swift
//  MicrosoftTests
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
import MicrosoftApis
import Combine

@testable import MicrosoftCatalog

struct MockProductListDataManager: ProductListDataManaging {
    
    func fetchProduct(_ completion: @escaping (Result<ProductList, Failure>) -> Void) {
        
    }
    
   
    private let networkManager: NetworkManaging
    
    init(_ networkManger: NetworkManaging) {
        self.networkManager = networkManger
    }
    
    func fetchProductList(_ completion: @escaping (Result<[ProductItem], Failure>) -> Void) {
        networkManager.request(url: "ProductList", params: nil, callBack: completion)
    }
    
    
    func fetchProductList() -> AnyPublisher<[ProductItem], Failure> {
        networkManager.request(url: "ProductList", params: nil)
    }
    
    
    func fetchProductList() async throws -> [ProductItem] {
        return try await networkManager.request(url: "ProductList", params: nil)
    }
}

