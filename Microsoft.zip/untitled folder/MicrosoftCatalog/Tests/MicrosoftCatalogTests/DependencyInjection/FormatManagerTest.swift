//
//  FormatManagerTest.swift
//  MicrosoftTests
//
//  Created by Durgesh Lal on 09/27/22.
//

import XCTest
import MicrosoftApis
@testable import MicrosoftCatalog

class FormatManagerTest: XCTestCase {

    func testRating() {
        let formatManager = MockFormatManager()
        XCTAssertEqual(formatManager.roundToNearestHalf(2.4), "2.5")
        XCTAssertEqual(formatManager.roundToNearestHalf(0.4), "0.5")
        XCTAssertEqual(formatManager.roundToNearestHalf(3.8), "4.0")
    }
}

struct MockFormatManager: FormatManaging {
    func roundToNearestHalf<T: CustomStringConvertible>(_ value: T) -> String {
        let n = 1 / 0.5
        guard let value = Double(value.description) else { return "" }
        let numberToRound = value * n
        return "\(numberToRound.rounded() / n)"
    }
}

class MockDateManager: DateManaging {
    lazy var formatter: DateFormatter = {
        let format = DateFormatter()
        format.dateStyle = .short
        return format
    }()
    
    func formatDate(_ date: String?, format from: DateFormatter.Style, format to: DateFormatter.Style) -> String {
        guard let date = date else { return "" }
        formatter.dateStyle = from
        guard let input = formatter.date(from: date) else { return "" }
        formatter.dateStyle = to
        return formatter.string(from: input)
    }
}
