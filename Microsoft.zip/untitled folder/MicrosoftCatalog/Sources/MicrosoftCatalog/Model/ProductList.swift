//
//  ProductList.swift
//  Microsoft
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation

/*
 [
   {
     "name" : "Yellow Chair",
     "tagline" : "Great if you like yellow!",
     "rating" : 3,
     "date" : "1-15-2018"
   },
   {
     "name" : "Blue Table",
     "tagline" : "Interesting choice for interesting people.",
     "rating" : 5,
     "date" : "1-14-2018"
   },
   {
     "name" : "Pink Lamp",
     "tagline" : "Very bold!",
     "rating" : 2,
     "date" : "1-13-2018"
   },
   {
     "name" : "Red Stand",
     "tagline" : "Stylish and chic.",
     "rating" : 4,
     "date" : "1-12-2018"
   },
   {
     "name" : "Wood Desk",
     "tagline" : "Timeless and classic.",
     "rating" : 1,
     "date" : "1-11-2018"
   }
 ]
 */

struct ProductItem: Codable, Hashable {
    let name: String?
    let tagline: String?
    let rating: Double?
    let date: String?
}


struct ProductList: Codable, Hashable {
    var items: [ProductItem]?
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        items = try container.decode([ProductItem].self)
    }
}

