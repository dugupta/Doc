//
//  ProductListViewController.swift
//  Microsoft
//
//  Created by Durgesh Lal on 09/27/22.
//

import UIKit
import Combine

final class ProductListViewController<T: ProductListViewModeling>: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    private let viewModel: T
    private var viewModelSubscription: AnyCancellable? = nil
    
    init?(_ viewModel: T, coder: NSCoder) {
        self.viewModel = viewModel
        super.init(coder: coder)
    }
    
    @available(*, unavailable, renamed: "init(viewModel:coder:)")     required init?(coder: NSCoder) {
        fatalError("Invalid way of decoding this class")
    }
    
    private func withClosure() {
        viewModel.fetchProductList { [weak self] success in
            guard let self = self else { return }
            if success {
                self.reloadData()
            } else {
                self.presentError()
            }
        }
    }
    
    private func withAsynAwait() {
        Task {
            do {
                try await viewModel.fetchProductList()
                self.reloadData()
            } catch(let error) {
                print("Error is \(error)")
                self.presentError()
            }
        }
    }
    
    private func withCombine() {
        viewModelSubscription = viewModel.publisher.sink(receiveValue: { (callback) in
            print(callback)
            self.reloadData()
        })
        
        viewModel.fetchProductList()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Product list"
        withClosure()
        //withAsynAwait()
        //withCombine()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ProductListCell") as? ProductListCell {
            let item = viewModel.itemAtIndex(indexPath.row)
            let data = ProductItemViewModel(item, formatManager: viewModel.formatManager, dateManager: viewModel.dateManager)
            cell.updateCellWith(data)
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}

extension ProductListViewController {
    
    private func presentError() {
        let alert = UIAlertController(title: "Error", message: viewModel.errorMessage, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    private func reloadData() {
        tableView.reloadData()
    }
}

