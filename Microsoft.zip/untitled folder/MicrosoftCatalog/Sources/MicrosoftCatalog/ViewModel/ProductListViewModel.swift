//
//  ProductListViewModel.swift
//  Microsoft
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
import MicrosoftApis
import Combine

protocol DepedencyInjection {
    var formatManager: FormatManaging { get }
    var dateManager: DateManaging { get }
}

protocol ErrorRepesentable {
    var errorMessage: String? { get }
}

struct CallBack {
    let completed: Bool
}

protocol ProductListViewModeling: DepedencyInjection, ErrorRepesentable {
    var numberOfRows: Int { get }
    func itemAtIndex(_ index: Int) -> ProductItem
    func fetchProductList(_ completion: @escaping (Bool) -> Void)
    func fetchProductList() async throws
    func fetchProductList()
    
    var publisher: AnyPublisher<CallBack, Never> { get }
}

final class ProductListViewModel: ProductListViewModeling, ObservableObject {
    
    private var subscriptions: Set<AnyCancellable> = []
    private var networkErrorMessage: String? = "Error while fetching product list!"
    private let dataManager: ProductListDataManaging
    internal let formatManager: FormatManaging
    internal var dateManager: DateManaging
    private var subject = CurrentValueSubject<CallBack, Never>(CallBack(completed: false))
    
    var publisher: AnyPublisher<CallBack, Never> {
        return subject.eraseToAnyPublisher()
    }
    
    private var list: [ProductItem] = []
    
    //@Published var productItemViewModels: [ProductItemViewModel] = []
    //var cancellable: AnyCancellable?
    
    init(_ dataManager: ProductListDataManaging, formatManager: FormatManaging, dateManager: DateManaging) {
        self.dataManager = dataManager
        self.formatManager = formatManager
        self.dateManager = dateManager
    }
}

extension ProductListViewModel {
    var numberOfRows: Int { list.count }
    
    func itemAtIndex(_ index: Int) -> ProductItem {
        list[index]
    }
}

extension ProductListViewModel {
    private func failure(_ error: Failure, self: ProductListViewModel, completion: @escaping (Bool) -> Void) {
        print("Microsoft: Error \(error)")
        switch error {
        case .badResponse(let networkError):
            self.networkErrorMessage = networkError
        default:
            break
        }
        completion(false)
    }
    
    private func withClosure(_ completion: @escaping (Bool) -> Void) {
        
        dataManager.fetchProduct { [weak self] response in
            guard let self = self else { return }
            switch response {
            case .failure(let error):
                self.failure(error, self: self, completion: completion)
            case .success(let data):
                print("Microsoft: data \(data)")
                self.list = data.items ?? []
                completion(true)
            }
        }
        
        /*
        dataManager.fetchProductList() { [weak self] response in
            guard let self = self else { return }
            switch response {
            case .failure(let error):
                self.failure(error, self: self, completion: completion)
            case .success(let data):
                print("Microsoft: data \(data)")
                self.list = data
                completion(true)
            }
        }
        */
    }
   
    func fetchProductList(_ completion: @escaping (Bool) -> Void) {
        withClosure(completion)
    }
}

extension ProductListViewModel {
    func fetchProductList() async throws {
        let model = try await dataManager.fetchProductList()
        list = model
    }
}

extension ProductListViewModel {
    func fetchProductList() {
        dataManager.fetchProductList()
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion{
                case .finished: break
                case .failure(let error):
                    print("Error: \(error)")
                }
            } receiveValue: { response in
                self.list = response
                self.subject.value = CallBack(completed: true)
                // For Swift UI
                //self.productItemViewModels = response.map { ProductItemViewModel($0, formatManager: self.formatManager, dateManager: self.dateManager) }
            }
            .store(in: &subscriptions)
    }
}

extension ProductListViewModel {
    
    var errorMessage: String? {
        networkErrorMessage
    }
}

