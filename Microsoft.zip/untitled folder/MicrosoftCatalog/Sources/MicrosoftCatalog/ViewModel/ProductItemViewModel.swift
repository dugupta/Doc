//
//  ProductItemViewModel.swift
//  Microsoft
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
import MicrosoftApis

struct ProductItemViewModel {
   
    private let item: ProductItem
    private let formatManager: FormatManaging
    private let dateManager: DateManaging
    
    init(_ item: ProductItem, formatManager: FormatManaging, dateManager: DateManaging) {
        self.item = item
        self.formatManager = formatManager
        self.dateManager = dateManager
    }
    
    var name: String? {
        item.name
    }
    
    var tagline: String? {
        item.tagline
    }
    
    var date: String? {
        dateManager.formatDate(item.date)
    }
    
    var rating: String? {
        if let rating = item.rating {
            return formatManager.roundToNearestHalf(rating)
        }
        return nil
    }
}

