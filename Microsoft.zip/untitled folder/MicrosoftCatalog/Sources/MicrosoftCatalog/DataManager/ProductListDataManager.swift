//
//  ProductListDataManager.swift
//  Microsoft
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
import MicrosoftApis
import Combine

protocol ProductListDataManaging {
    func fetchProduct(_ completion: @escaping (Result<ProductList, Failure>) -> Void)
    
    func fetchProductList(_ completion: @escaping (Result<[ProductItem], Failure>) -> Void)
    // Asyn await api
    func fetchProductList() async throws -> [ProductItem]
    // Combine api
    func fetchProductList() -> AnyPublisher<[ProductItem], Failure>
}

struct ProductListDataManager: ProductListDataManaging {
    private static let prductListUrl = "interview-sandbox/android/json-to-list/products.v1.json"
    private let networkManager: NetworkManaging
    
    init(_ networkManger: NetworkManaging) {
        self.networkManager = networkManger
    }
    
    func fetchProductList(_ completion: @escaping (Result<[ProductItem], Failure>) -> Void) {
        networkManager.request(url: ProductListDataManager.prductListUrl, params: nil, callBack: completion)
    }
    
    func fetchProductList() async throws -> [ProductItem] {
        return try await networkManager.request(url: ProductListDataManager.prductListUrl, params: nil)
    }
    
    func fetchProductList() -> AnyPublisher<[ProductItem], Failure> {
        return networkManager.request(url: ProductListDataManager.prductListUrl, params: nil)
    }
    
    func fetchProduct(_ completion: @escaping (Result<ProductList, Failure>) -> Void) {
        networkManager.request(url: ProductListDataManager.prductListUrl, params: nil, callBack: completion)
    }
}

