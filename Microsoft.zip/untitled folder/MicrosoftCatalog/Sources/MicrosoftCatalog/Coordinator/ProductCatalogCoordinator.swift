//
//  ProductCatalogCoordinator.swift
//  Microsoft
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
import UIKit
import MicrosoftApis

final public class ProductCatalogCoordinator: Coordinator {
    var coordinator2: ProductCatalogSwiftUICoordinator!
    public var children: [Coordinator] = []
    public var navigationController: UINavigationController
    private var networkManager: NetworkManaging
    private var formatManager: FormatManaging
    private var dateManager: DateManaging
    public required init(_ navigationController: UINavigationController, container: ServiceResolving) {
        self.navigationController = navigationController
        self.networkManager = container.resolve()
        self.formatManager = container.resolve()
        self.dateManager = container.resolve()
    }
    
    public func start() {
        let storyboard = UIStoryboard(name: "ProductListViewController", bundle:  Bundle.module)
        if #available(iOS 13.0, *) {
            let controller = storyboard.instantiateViewController(
                identifier: "ProductListViewController",
                creator: { [weak self] coder in
                    guard let self = self else { return UIViewController() }
                    let dataManager = ProductListDataManager(self.networkManager)
                    let viewModel = ProductListViewModel(dataManager, formatManager: self.formatManager, dateManager: self.dateManager)
                    
                    return ProductListViewController(viewModel, coder: coder)
                }
            )
            navigationController.pushViewController(controller, animated: false)
        } else {
            // Fallback on earlier versions
            
        }
    }
}


import Foundation
import UIKit
import MicrosoftApis
import SwiftUI

final public class ProductCatalogSwiftUICoordinator: Coordinator {
    
    public var children: [Coordinator] = []
    public var navigationController: UINavigationController
    private var networkManager: NetworkManaging
    private var formatManager: FormatManaging
    private var dateManager: DateManaging
    public required init(_ navigationController: UINavigationController, container: ServiceResolving) {
        self.navigationController = navigationController
        self.networkManager = container.resolve()
        self.formatManager = container.resolve()
        self.dateManager = container.resolve()
    }
    
    public func start() {
        let controller = UIHostingController(rootView: ProductListView(ProductListViewModel(ProductListDataManager(networkManager), formatManager: formatManager, dateManager: dateManager)))
        navigationController.pushViewController(controller, animated: false)
    }
}


struct ProductListView: View {
    
    @ObservedObject private var viewModel: ProductListViewModel
    
    init(_ viewModel: ProductListViewModel) {
        self.viewModel = viewModel
    }
    
    var body: some View {
        NavigationView {
//            List(viewModel.productItemViewModels, id: \.self) { productItemViewModel in
//                ProductItemView(productItemViewModel)
//            }.onAppear {
//                viewModel.fetchProductList()
//            }
//            .navigationTitle("Product list")
        }
    }
}

struct ProductItemView: View {
    
    private var viewModel:ProductItemViewModel
    
    init(_ viewModel: ProductItemViewModel) {
        self.viewModel = viewModel
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
//            Text("\(viewModel.name)")
//            Text("\(viewModel.tagline)")
//            Text("\(viewModel.rating)")
//            Text("\(viewModel.date)")
        }
    }
}

