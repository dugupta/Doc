//
//  UITableView+Extension.swift
//  
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
extension UITableView {
    
    func register<T: UITableViewCell> (_: T.Type) where T: ViewReusable & ViewLoadable {
        let nib = UINib(nibName: T.NibName, bundle: nil)
        register(nib, forCellReuseIdentifier: T.reuseIdentifier)
    }
}

extension UITableView {
    
    func dequeueReusableCell<T: UITableViewCell>(forIndexPath indexPath: IndexPath) -> T where T: ViewReusable {
        guard let cell = dequeueReusableCell(withIdentifier: T.reuseIdentifier, for: indexPath as IndexPath) as? T else {
            fatalError("Could not dequeue cell with identifier: \(T.reuseIdentifier)")
        }
        return cell
    }
}

protocol ViewReusable: AnyObject {}
extension ViewReusable where Self: UIView {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}

protocol ViewLoadable: AnyObject { }
extension ViewLoadable where Self: UIView {
    static var NibName: String {
        return String(describing: self)
    }
}

protocol FromNib: ViewReusable, ViewLoadable { }
