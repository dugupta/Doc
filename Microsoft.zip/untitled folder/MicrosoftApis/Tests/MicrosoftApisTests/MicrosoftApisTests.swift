import XCTest
@testable import MicrosoftApis

final class MicrosoftApisTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        //XCTAssertEqual(MicrosoftApis().text, "Hello, World!")
    }
}
