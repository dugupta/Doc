//
//  ApplicationBootstrap.swift
//  
//
//  Created by Durgesh Lal on 09/27/22.
//

import Foundation
import MicrosoftApis

public class ApplicationBootstrap {
    public static func createApplicationBootstrap() -> ServiceResolving{
        let container: ServiceResolving = Container()
        container.register(NetworkManaging.self) { _ in NetworkManager(EnumEnvironment.prod) }
        container.register(FormatManaging.self) { _ in FormatManager() }
        container.register(DateManaging.self) { _ in DateManager() }
        return container
    }
}
