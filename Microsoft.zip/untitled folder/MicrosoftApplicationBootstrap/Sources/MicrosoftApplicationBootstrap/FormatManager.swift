//
//  FormatManager.swift
//  
//
//  Created by Durgesh Lal on 09/27/22.
//

import MicrosoftApis

public struct FormatManager: FormatManaging {
    public init() {  }
    
    public func roundToNearestHalf<T: CustomStringConvertible>(_ value: T) -> String {
        let n = 1 / 0.5
        guard let value = Double(value.description) else { return "" }
        let numberToRound = value * n
        return "\(numberToRound.rounded() / n)"
    }
}

