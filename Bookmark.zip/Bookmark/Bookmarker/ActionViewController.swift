//
//  ActionViewController.swift
//  Bookmarker
//
//  Created by Joyce Echessa on 3/9/15.
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import UIKit
import MobileCoreServices
import BookmarkKit

class ActionViewController: UIViewController {

    @IBOutlet weak var bookmarkTitle: UITextField!
    
    var bookmarkURL: URL!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let extensionItem = extensionContext?.inputItems.first as? NSExtensionItem
        guard let itemProvider = extensionItem?.attachments?.first else {
            print("Not a valid itemProvider")
            return
        }
        let propertyList = String(kUTTypePropertyList)
        if itemProvider.hasItemConformingToTypeIdentifier(propertyList) {
            itemProvider.loadItem(forTypeIdentifier: propertyList, options: nil) { (item, error) in
                guard let dictionary = item as? NSDictionary else {
                    print("Cant convert in Dictionary")
                    return
                }
                OperationQueue.main.addOperation {
                    let results = dictionary[NSExtensionJavaScriptPreprocessingResultsKey] as! NSDictionary
                    let urlString = results["currentUrl"] as? String
                    self.bookmarkURL = URL(string: urlString!)
                }
            }
        } else {
            print("error")
        }
    }

    @IBAction func done() {
        var statusMessage: NSString
        
        if (bookmarkTitle.text == nil) {
            statusMessage = "Cannot save bookmark without a title"
        } else {
            let bookmark = Bookmark(url: bookmarkURL, title: bookmarkTitle.text ?? "")
            let bookmarkService = BookmarkService.sharedService
            bookmarkService.addBookmark(bookmark: bookmark)
            bookmarkService.saveBookmarks()
            statusMessage = "Saved successfully"
        }
        
        let extensionItem = NSExtensionItem()
        let statusDictionary = [NSExtensionJavaScriptFinalizeArgumentKey : [ "statusMessage" : statusMessage ]]
        let one = NSItemProvider(item: statusDictionary as NSSecureCoding?, typeIdentifier: String(kUTTypePropertyList))
        extensionItem.attachments = [one]
        self.extensionContext!.completeRequest(returningItems: [], completionHandler: nil)
    }

}
