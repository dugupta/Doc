//
//  ActionRequestHandler.swift
//  Capitalize
//
//  Created by Joyce Echessa on 3/12/15.
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import UIKit
import MobileCoreServices

class ActionRequestHandler: NSObject, NSExtensionRequestHandling {
   
    var extensionContext: NSExtensionContext?
    
    func beginRequest(with context: NSExtensionContext) {
        self.extensionContext = context
        
        for item in context.inputItems {
            guard let inputItem = item as? NSExtensionItem  else {
                print("Not a valid NSExtensionItem")
                return
            }
            
            for provider in inputItem.attachments ?? [] {
                if provider.hasItemConformingToTypeIdentifier(String(kUTTypePropertyList)) {
                    provider.loadItem(forTypeIdentifier: String(kUTTypePropertyList), options: nil) { (result, error) in
                        if let dictionary = result as? NSDictionary {
                            if let value: [String : String] = dictionary[NSExtensionJavaScriptPreprocessingResultsKey] as? [String : String] {
                                self.itemLoadCompletedWithPreprocessingResults(javaScriptPreprocessingResults: value)
                            }
                        }
                    }
                }
            }
        }
    }
    
    func itemLoadCompletedWithPreprocessingResults(javaScriptPreprocessingResults: [String: String]) {
        let pageContent: String = javaScriptPreprocessingResults["content"] ?? ""
        let capitalizedContent = pageContent.uppercased()
        self.doneWithResults(resultsForJavaScriptFinalizeArg: ["content": capitalizedContent])
    }
    
    func doneWithResults(resultsForJavaScriptFinalizeArg: [String: String]) {
        self.extensionContext!.completeRequest(returningItems: [], completionHandler: nil)
        let resultsDictionary = [NSExtensionJavaScriptFinalizeArgumentKey: resultsForJavaScriptFinalizeArg]
        let resultsProvider: NSItemProvider = NSItemProvider(item: resultsDictionary as NSSecureCoding?, typeIdentifier: String(kUTTypePropertyList))
        let resultsItem = NSExtensionItem()
        resultsItem.attachments = [resultsProvider]
        self.extensionContext!.completeRequest(returningItems: [resultsItem]) { (success) in
            print("Updated Succesfully \(success)")
        }
    }

}
