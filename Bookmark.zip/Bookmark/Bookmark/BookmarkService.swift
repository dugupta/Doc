//
//  BookmarkService.swift
//  Bookmark
//
//  Created by Joyce Echessa on 3/8/15.
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import Foundation

public class BookmarkService {
    
    public lazy var bookmarks: [Bookmark] = BookmarkService.sharedService.loadBookmarks()
    
    public class var sharedService: BookmarkService {
        struct Singleton {
            static let instance = BookmarkService()
        }
        return Singleton.instance
    }
    
    init() {
        let queue = OperationQueue.main
        let notificationCenter = NotificationCenter.default
        
        notificationCenter.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: queue) { _ in
            self.saveBookmarks()
        }
        
        notificationCenter.addObserver(forName: UIApplication.willEnterForegroundNotification, object: nil, queue: queue) { _ in
            self.bookmarks = self.loadBookmarks()
        }
    }
    
    public func loadBookmarks() -> [Bookmark] {
        var loadedBookmarks: [Bookmark] = []
        if (FileManager.default.fileExists(atPath: getFileUrl().path)) {
            let bookmarksData = try? Data(contentsOf: getFileUrl(), options: .uncachedRead)
            do {
                if #available(iOSApplicationExtension 11.0, *) {
                    if #available(iOSApplicationExtension 14.0, *) {
                        if let unarchivedBookmarks: [Bookmark] = try NSKeyedUnarchiver.unarchivedArrayOfObjects(ofClass: Bookmark.self, from: bookmarksData!) {
                            loadedBookmarks = unarchivedBookmarks
                        }
                    } else {
                        // Fallback on earlier versions
                    }
                }
            } catch {
                print("Couldn't read file.")
            }
            
            
        }
        
        return loadedBookmarks
    }
    
    func getFileUrl() -> URL {
        if let containerUrl = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: "group.com.appcoda.Bookmark") {
            return containerUrl.appendingPathComponent("AppcodaBookmarkService.dat")
        } else {
            fatalError("Error obtaining shared container URL. Check your App Group configuration.")
        }
    }
    
    public func saveBookmarks() {
        let bookmarksData = NSKeyedArchiver.archivedData(withRootObject: bookmarks)
        try? bookmarksData.write(to: getFileUrl(), options: NSData.WritingOptions.atomicWrite)
    }
    
    public func addBookmark(bookmark: Bookmark) {
        bookmarks.insert(bookmark, at: 0)
    }
    
}
