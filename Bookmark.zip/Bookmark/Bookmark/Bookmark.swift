//
//  Bookmark.swift
//  Bookmark
//
//  Created by Joyce Echessa on 3/8/15.
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import UIKit

public class Bookmark: NSObject, NSCoding, NSSecureCoding {
    public static var supportsSecureCoding: Bool = true
    
    public func encode(with coder: NSCoder) {
        coder.encode(title, forKey: "title")
        coder.encode(url, forKey: "url")
    }
    
    public let url: URL?
    public let title: String?
    
    public init(url: URL, title: String) {
        self.url = url
        self.title = title
        super.init()
    }
    
    public required init(coder aDecoder: NSCoder) {
        title = aDecoder.decodeObject(forKey: "title") as? String
        url = aDecoder.decodeObject(forKey: "url") as? URL
    }
 }

