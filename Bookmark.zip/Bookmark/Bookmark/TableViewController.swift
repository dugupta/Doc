//
//  TableViewController.swift
//  Bookmark
//
//  Created by Joyce Echessa on 3/8/15.
//  Copyright (c) 2015 Appcoda. All rights reserved.
//

import UIKit
import BookmarkKit

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
   
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return BookmarkService.sharedService.bookmarks.count;
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let bookmark = BookmarkService.sharedService.bookmarks[indexPath.row]
        let cell: UITableViewCell! = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell.textLabel?.text = bookmark.title
        return cell
    }
    
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "openURL") {
            let indexPath: NSIndexPath = tableView.indexPathForSelectedRow! as NSIndexPath
            let bookmark = BookmarkService.sharedService.bookmarks[indexPath.row]
            
            let destViewController = segue.destination as! ViewController
            destViewController.url = bookmark.url as URL?
        }
    }
}
