# LemonadeStandLocations

Contains the locations of Swify Lemonade stands.
