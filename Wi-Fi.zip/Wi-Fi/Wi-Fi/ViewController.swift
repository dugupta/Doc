//
//  ViewController.swift
//  Wi-Fi
//
//  Created by Durgesh Lal on 8/5/20.
//  Copyright © 2020 Durgesh Lal. All rights reserved.
//

import UIKit
import CoreLocation
import SystemConfiguration.CaptiveNetwork

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        
        let ssid = self.getAllWiFiNameList()
        print("SSID: \(ssid)")
    }
    
    func getAllWiFiNameList() -> String? {
        var ssid: String?
        if let interfaces = CNCopySupportedInterfaces() as NSArray? {
            for interface in interfaces {
                if let interfaceInfo = CNCopyCurrentNetworkInfo(interface as! CFString) as NSDictionary? {
                    ssid = interfaceInfo[kCNNetworkInfoKeySSID as String] as? String
                    break
                }
            }
        }
        return ssid
    }
}

